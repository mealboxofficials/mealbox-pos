# Changelog — MealBox POS

All notable changes and stabilization updates to MealBox POS are documented in this file.

---

## [1.5.0] - 2026-08-01 (Phase 2 - Task 4: Production Inventory & Recipe Engine)

### Completed & Verified
- **Production Inventory & Recipe Management Engine:**
  - Implemented **Raw Material Management**: full CRUD tracking for raw ingredients with category classification, base units (`Kg`, `Gram`, `Litre`, `ml`, `Piece`, `Packet`, etc.), current stock, reorder levels, cost prices, default supplier mapping, and real-time stock valuation.
  - Implemented **Recipe Management & Ingredient Mapping**: mapped menu items to multi-ingredient recipes with yield quantities, preparation notes, and automatic unit conversion (`convertUnitQuantity`).
  - Implemented **Automatic Stock Deduction & Restoration**: POS order creation/edition deducts stock via item deltas (`processOrderInventoryDeduction`), and order voids/cancellations automatically restore exact stock (`processOrderInventoryRestoration`) without double deduction.
  - Implemented **Stock In & Purchase Entries**: record supplier purchase invoices, track payment modes (`cash`, `upi`, `card`, `credit`), auto-update supplier balance due, and receive delivered raw materials.
  - Implemented **Supplier & Vendor Management**: manage supplier contacts, track credit balance dues, and record vendor payments.
  - Implemented **Waste & Spoilage Management**: log kitchen prep waste, expired materials, spilled goods, or customer returns with reason classification and loss valuation.
  - Implemented **Physical Stock Audit & Count**: conduct physical kitchen stock counts, auto-calculate variances and variance values, and perform 1-click stock reconciliation adjustments.
  - Implemented **Food Cost % & Costing Calculations**: automatic dish recipe cost calculation, menu item cost calculation, food cost % calculation (`(Recipe Cost / Sell Price) * 100`), and color-coded profitability threshold alerts.
  - Implemented **Inventory Audit Trail & Reports**: immutable stock movement ledger (`StockMovementLog`), Low Stock Alerts, Daily Consumption Reports, and Inventory Valuation Reports.
  - Implemented **Modular Sub-tab Dashboard UI**: created `RawMaterialsTab`, `RecipesTab`, `PurchaseTab`, `SupplierTab`, `WasteTab`, `StockAuditTab`, `AuditTrailTab`, and `InventoryReportsTab` integrated into `InventoryManagement.tsx`.

---

## [1.4.0] - 2026-08-01 (Phase 2 - Task 3: Complete Table Lifecycle Workflow)

### Completed & Verified
- **Table Lifecycle & Floor Management Engine:**
  - Implemented complete Table Lifecycle State Machine with real-time status transitions (`vacant` / `empty`, `occupied`, `billing`, `settled`, `cleaning`, `reserved`, `locked`).
  - **Transfer Table Workflow:** Implemented `transferTable(fromTableId, toTableId)` to seamlessly move active orders, items, waiter assignment, guest count, and timer references to any vacant table while resetting source table state and logging audit history.
  - **Merge Tables Workflow:** Implemented `mergeTables(fromTableId, toTableId)` to merge items from source order into destination order, recalculate subtotals, void source table order, mark source table vacant, and log audit trail.
  - **Table Split Workflow:** Implemented `splitTable(fromTableId, toTableId, itemsToMove)` with item quantity steppers to move selected line item quantities to a target vacant table; includes automatic fallback to full table transfer if all items are selected.
  - **Table Reservation Management:** Implemented `reserveTable(tableId, reservationDetails)` with customer name, mobile, time, guest count, and note; added `seatReservedTable(tableId)` to convert reserved status to occupied and open order cart, and `cancelReservation(tableId)` to release table.
  - **Table Lock/Unlock Security:** Implemented `lockTable(tableId, reason)` and `unlockTable(tableId)` with custom lock reasons and staff badges to prevent order entry on maintenance or restricted tables.
  - **Waiter & Guest Count Management:** Implemented `changeTableWaiter` and `changeTableGuestCount` for rapid table re-assignment and pax updates.
  - **Real-Time Audit Trail:** Implemented `addTableHistoryLog` and `tableHistoryLogs` state tracking all table actions with timestamps and staff user attribution for full operational accountability.
  - **UI & Grid Enhancements:** Enhanced `TableLifecycleModal.tsx` and `OrderFlow.tsx` with section/floor filters, status filter chips, real-time live elapsed timers (`formatLiveTimer`), status color highlights, and responsive quick action cards.

---

## [1.3.0] - 2026-08-01 (Phase 2 - Task 2: Complete KOT Workflow)

### Completed & Verified
- **Kitchen Order Ticket (KOT) Workflow:**
  - Implemented New Order KOT generation featuring automatic sequential KOT Token numbers (`KOT Ticket #101 (TOKEN #1)`).
  - Implemented Running Order & Additional KOT printing: newly added items or increased quantities are tagged `isNew: true` so only additional items/quantities print on subsequent KOT tokens.
  - Implemented VOID KOT ticket generation: automatically detects when printed KOT items are removed or decreased in quantity during order editing, generating a red-badged VOID KOT (`*** CANCELLED / VOID ITEMS ***`) to notify kitchen staff to stop preparation.
  - Implemented Duplicate/Reprint KOT feature: allows reprinting tickets with clear `*** REPRINT KOT (DUPLICATE COPY) ***` badges.
  - Implemented Kitchen Section Routing (`ROUTING: AC SECTION KITCHEN`) and thermal printer 80mm ESC/POS layout formatting.
  - Verified bilingual Hindi (`nameHi`) primary and English (`nameEn`) secondary item displays, Waiter name, Table number / Order Mode, Guest Count, Special Item Notes, and KOT Timestamps.
  - Verified real-time state synchronization with Kitchen Display System (KDS).

---

## [1.2.0] - 2026-08-01 (Phase 2 - Task 1: Complete POS Billing Workflow)

### Completed & Verified
- **POS Billing & Order Execution:**
  - Verified all order modes (`dine_in`, `takeaway`, `delivery`, `reservation`, `free`) with section-specific price overrides and instant mode switching.
  - Verified table selection, occupied table timer indicators, live billing loading (single bill per table rule), waiter assignment, and guest count tracking.
  - Verified customer lookup auto-suggest, attachment of pending dues, application of advance credit balance, and advance deposit entry.
  - Refined item addition and quantity modification logic (`handleAddItem` & `handleUpdateQty`) so running order additions on printed KOT items generate clean unprinted line items tagged `isNew: true` for KOT printing and inventory stock deduction.
  - Verified off-menu custom item addition, special item instructions/notes, expandable cart drawer, and 3-button bottom bar (SAVE, KOT, BILL).

---

## [1.1.0] - 2026-08-01 (Stability & Verification Release)

### Fixed
- **Runtime Crashes & Exceptions:**
  - Resolved `addStaffMember` missing function crash in `StaffManagement.tsx` by implementing the handler in `AppContext.tsx` and auto-provisioning corresponding PIN-secured user accounts.
  - Resolved `TypeError: Illegal constructor` in `Header.tsx` by restoring the missing `Lock` icon import from `lucide-react`.
  - Fixed copy-paste ternary condition in `importDatabase()` in `AppContext.tsx`.

- **Financial & Accounting Calculations:**
  - Updated `processBillPayment()` in `AppContext.tsx` to recalculate discount percentages, discount amounts, and final totals factoring in attached dues, applied credit, and advance deposits.
  - Included split payment cash portions (`paymentMode === 'split'`) in `DayOpenCloseModal.tsx` cash drawer expected totals and `ReportsAnalytics.tsx` cash sales metrics.
  - Updated `EditOrderModal` in `ReportsAnalytics.tsx` to deduct advance deposits from `finalTotal` and display advance deposit rows in order summaries.

- **Inventory Tracking:**
  - Prevented duplicate inventory stock deductions when editing existing orders by checking item delta flags (`isNew: true`) in `saveOrder()`.

- **State & Memory Optimization:**
  - Added timer reference cleanup in `BillModal.tsx` (`verifyUpiStatus`) to prevent React state update warnings on unmounted modal components.
  - Replaced fixed array-length order numbering with dynamic max-order-id increment logic to prevent duplicate order numbers.
  - Purged unused `lucide-react` imports across 11 component files.

### Verified
- Executed full lint check (`tsc --noEmit`) — 0 errors.
- Executed production build (`npm run build`) — succeeded cleanly.
- Audited all 16 core system modules across 10 stability verification criteria.
