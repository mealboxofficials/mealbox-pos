import {
  Section,
  Table,
  MenuItem,
  Customer,
  Staff,
  InventoryItem,
  User,
  RawMaterial,
  Recipe,
  Supplier,
  PurchaseEntry,
  StockMovementLog,
  WasteEntry,
} from '../types';

export const INITIAL_SECTIONS: Section[] = [
  {
    id: 'sec-mealbox',
    name: 'MealBox Main',
    color: 'orange',
    upiId: '8877044088@upi',
    tablePrefix: 'T-',
    tableCount: 8,
  },
  {
    id: 'sec-mbrestaurant',
    name: 'MB Restaurant',
    color: 'emerald',
    upiId: '8877044088@upi',
    tablePrefix: 'MB-',
    tableCount: 10,
  },
  {
    id: 'sec-cabin',
    name: 'MealBox Cabin',
    color: 'purple',
    upiId: '8877044088@upi',
    tablePrefix: 'Cabin-',
    tableCount: 6,
  },
  {
    id: 'sec-achall',
    name: 'AC Hall',
    color: 'sky',
    upiId: '8877044088@upi',
    tablePrefix: 'AC-',
    tableCount: 8,
  },
];

export const INITIAL_TABLES: Table[] = [
  // Mealbox section tables
  { id: 'tbl-m1', sectionId: 'sec-mealbox', name: 'T-1', status: 'empty' },
  { id: 'tbl-m2', sectionId: 'sec-mealbox', name: 'T-2', status: 'empty' },
  { id: 'tbl-m3', sectionId: 'sec-mealbox', name: 'T-3', status: 'empty' },
  { id: 'tbl-m4', sectionId: 'sec-mealbox', name: 'T-4', status: 'empty' },
  { id: 'tbl-m5', sectionId: 'sec-mealbox', name: 'T-5', status: 'empty' },
  { id: 'tbl-m6', sectionId: 'sec-mealbox', name: 'T-6', status: 'empty' },
  { id: 'tbl-m7', sectionId: 'sec-mealbox', name: 'T-7', status: 'empty' },
  { id: 'tbl-m8', sectionId: 'sec-mealbox', name: 'T-8', status: 'empty' },

  // MB Restaurant section tables
  { id: 'tbl-r1', sectionId: 'sec-mbrestaurant', name: 'MB-1', status: 'empty' },
  { id: 'tbl-r2', sectionId: 'sec-mbrestaurant', name: 'MB-2', status: 'empty' },
  { id: 'tbl-r3', sectionId: 'sec-mbrestaurant', name: 'MB-3', status: 'empty' },
  { id: 'tbl-r4', sectionId: 'sec-mbrestaurant', name: 'MB-4', status: 'empty' },
  { id: 'tbl-r5', sectionId: 'sec-mbrestaurant', name: 'MB-5', status: 'empty' },
  { id: 'tbl-r6', sectionId: 'sec-mbrestaurant', name: 'MB-6', status: 'empty' },

  // Cabin section tables
  { id: 'tbl-c1', sectionId: 'sec-cabin', name: 'Cabin 1', status: 'empty' },
  { id: 'tbl-c2', sectionId: 'sec-cabin', name: 'Cabin 2', status: 'empty' },
  { id: 'tbl-c3', sectionId: 'sec-cabin', name: 'Cabin 3', status: 'empty' },

  // AC Hall
  { id: 'tbl-a1', sectionId: 'sec-achall', name: 'AC-1', status: 'empty' },
  { id: 'tbl-a2', sectionId: 'sec-achall', name: 'AC-2', status: 'empty' },
  { id: 'tbl-a3', sectionId: 'sec-achall', name: 'AC-3', status: 'empty' },
];

const sp = (price: number) => ({
  'sec-mealbox': price,
  'sec-mbrestaurant': price,
  'sec-cabin': price + 10,
  'sec-achall': price + 10,
});

export const INITIAL_MENU: MenuItem[] = [
  // --- VEG STARTER ---
  { id: 'item-vs-1', nameEn: 'French Fry', nameHi: 'फ्रेंच फ्राइ', price: 199, sectionPrices: sp(199), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-2', nameEn: 'Chilli Potato', nameHi: 'चीली पोटैटो', price: 249, sectionPrices: sp(249), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-3', nameEn: 'Honey Chilli Potato', nameHi: 'हनी चीली पोटैटो', price: 249, sectionPrices: sp(249), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-4', nameEn: 'Veg Lollipop (6P)', nameHi: 'वेज लॉलीपॉप (6P)', price: 279, sectionPrices: sp(279), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-5', nameEn: 'Paneer Lollipop (6P)', nameHi: 'पनीर लॉलीपॉप (6P)', price: 299, sectionPrices: sp(299), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-6', nameEn: 'Paneer Pakoda (6P)', nameHi: 'पनीर पकोड़ा (6P)', price: 199, sectionPrices: sp(199), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-7', nameEn: 'Paneer Chilli Dry (8P)', nameHi: 'पनीर चीली ड्राई (8P)', price: 249, sectionPrices: sp(249), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-8', nameEn: 'Mushroom Chilli Dry', nameHi: 'मशरुम चीली ड्राई', price: 299, sectionPrices: sp(299), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-9', nameEn: 'Sweet Corn Chilli', nameHi: 'स्वीट कॉर्न चीली', price: 299, sectionPrices: sp(299), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-10', nameEn: 'Baby Corn Chilli', nameHi: 'बेबी कॉर्न चीली', price: 299, sectionPrices: sp(299), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-11', nameEn: 'Dragon Paneer (8P)', nameHi: 'ड्रैगन पनीर (8P)', price: 299, sectionPrices: sp(299), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-12', nameEn: 'Paneer 65 (8P)', nameHi: 'पनीर 65 (8P)', price: 299, sectionPrices: sp(299), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-13', nameEn: 'Mushroom 65', nameHi: 'मशरुम 65', price: 329, sectionPrices: sp(329), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-14', nameEn: 'Dragon Mushroom', nameHi: 'ड्रैगन मशरूम', price: 329, sectionPrices: sp(329), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-15', nameEn: 'Zafrani Paneer Tikka (8P)', nameHi: 'जाफरानी पनीर टिक्का (8P)', price: 329, sectionPrices: sp(329), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-16', nameEn: 'Paneer Malai Tikka (8P)', nameHi: 'पनीर मलाई टिक्का (8P)', price: 349, sectionPrices: sp(349), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-17', nameEn: 'Mushroom Tikka', nameHi: 'मशरुम टिक्का', price: 329, sectionPrices: sp(329), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-vs-18', nameEn: 'Mushroom Malai Tikka', nameHi: 'मशरुम मलाई टिक्का', price: 349, sectionPrices: sp(349), category: 'Veg Starter', kotPrint: true, discountable: true, active: true },

  // --- NON-VEG STARTER ---
  { id: 'item-nvs-1', nameEn: 'Egg Pakoda (4P)', nameHi: 'एग पकोड़ा (4P)', price: 199, sectionPrices: sp(199), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-2', nameEn: 'Chicken Chilli Dry (8P)', nameHi: 'चिकन चीली ड्राई (8P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-3', nameEn: 'Chicken Lollipop (6P)', nameHi: 'चिकन लॉलीपॉप (6P)', price: 329, sectionPrices: sp(329), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-4', nameEn: 'Dragon Chicken (8P)', nameHi: 'ड्रैगन चिकन (8P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-5', nameEn: 'Chicken 65 (8P)', nameHi: 'चिकन 65 (8P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-6', nameEn: 'Chicken Tikka (8P)', nameHi: 'चिकन टिक्का (8P)', price: 329, sectionPrices: sp(329), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-7', nameEn: 'Chicken Malai Tikka (8P)', nameHi: 'चिकन मलाई टिक्का (8P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-8', nameEn: 'Tandoori Chicken', nameHi: 'तंदूरी चिकन', price: 499, sectionPrices: sp(499), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvs-9', nameEn: 'Chicken Seek Kabab (8P)', nameHi: 'चिकन सीक कबाब (8P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Starter', kotPrint: true, discountable: true, active: true },

  // --- VEG MAIN COURSE ---
  { id: 'item-vmc-1', nameEn: 'Mix Veg', nameHi: 'मिक्स वेज', price: 229, sectionPrices: sp(229), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-2', nameEn: 'Matar Paneer', nameHi: 'मटर पनीर', price: 249, sectionPrices: sp(249), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-3', nameEn: 'Veg Classic Manchurian (4P)', nameHi: 'वेज क्लासिक मंचूरियन (4P)', price: 129, sectionPrices: sp(129), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-4', nameEn: 'Veg Classic Manchurian (8P)', nameHi: 'वेज क्लासिक मंचूरियन (8P)', price: 199, sectionPrices: sp(199), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-5', nameEn: 'Paneer Manchurian (8P)', nameHi: 'पनीर मंचूरियन (8P)', price: 249, sectionPrices: sp(249), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-6', nameEn: 'Paneer Chilli Gravy (4P)', nameHi: 'पनीर चीली ग्रेवी (4P)', price: 149, sectionPrices: sp(149), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-7', nameEn: 'Paneer Chilli Gravy (8P)', nameHi: 'पनीर चीली ग्रेवी (8P)', price: 249, sectionPrices: sp(249), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-8', nameEn: 'Mushroom Chilli (4P)', nameHi: 'मशरुम चीली (4P)', price: 199, sectionPrices: sp(199), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-9', nameEn: 'Mushroom Chilli (8P)', nameHi: 'मशरुम चीली (8P)', price: 299, sectionPrices: sp(299), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-10', nameEn: 'Kadhayi Paneer (4P)', nameHi: 'कढ़ाई पनीर (4P)', price: 179, sectionPrices: sp(179), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-11', nameEn: 'Kadhayi Paneer (8P)', nameHi: 'कढ़ाई पनीर (8P)', price: 279, sectionPrices: sp(279), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-12', nameEn: 'Paneer Masala (4P)', nameHi: 'पनीर मसाला (4P)', price: 179, sectionPrices: sp(179), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-13', nameEn: 'Paneer Masala (8P)', nameHi: 'पनीर मसाला (8P)', price: 279, sectionPrices: sp(279), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-14', nameEn: 'Paneer Do Pyaza (4P)', nameHi: 'पनीर दो प्याजा (4P)', price: 179, sectionPrices: sp(179), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-15', nameEn: 'Paneer Do Pyaza (8P)', nameHi: 'पनीर दो प्याजा (8P)', price: 279, sectionPrices: sp(279), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-16', nameEn: 'Paneer Butter Masala (4P)', nameHi: 'पनीर बटर मसाला (4P)', price: 199, sectionPrices: sp(199), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-17', nameEn: 'Paneer Butter Masala (8P)', nameHi: 'पनीर बटर मसाला (8P)', price: 299, sectionPrices: sp(299), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-18', nameEn: 'Shahi Paneer (8P)', nameHi: 'शाही पनीर (8P)', price: 349, sectionPrices: sp(349), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-19', nameEn: 'Paneer Punjabi (8P)', nameHi: 'पनीर पंजाबी (8P)', price: 349, sectionPrices: sp(349), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-20', nameEn: 'Paneer Kolhapuri (8P)', nameHi: 'पनीर कोल्हापुरी (8P)', price: 349, sectionPrices: sp(349), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-21', nameEn: 'Paneer Lababdaar (8P)', nameHi: 'पनीर लबाबदार (8P)', price: 349, sectionPrices: sp(349), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-22', nameEn: 'Kadhayi Mushroom', nameHi: 'कढ़ाई मशरूम', price: 299, sectionPrices: sp(299), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-23', nameEn: 'Mushroom Masala', nameHi: 'मशरूम मसाला', price: 299, sectionPrices: sp(299), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-24', nameEn: 'Mushroom Do Pyaja', nameHi: 'मशरुम दो प्याजा', price: 299, sectionPrices: sp(299), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-25', nameEn: 'Mushroom Butter Masala', nameHi: 'मशरूम बटर मसाला', price: 319, sectionPrices: sp(319), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-26', nameEn: 'Mushroom Punjabi', nameHi: 'मशरूम पंजाबी', price: 349, sectionPrices: sp(349), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-27', nameEn: 'Mushroom Kolhapuri', nameHi: 'मशरूम कोल्हापुरी', price: 349, sectionPrices: sp(349), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-vmc-28', nameEn: 'Mushroom Lababdaar', nameHi: 'मशरूम लबाबदार', price: 349, sectionPrices: sp(349), category: 'Veg Main Course', kotPrint: true, discountable: true, active: true },

  // --- NON-VEG MAIN COURSE ---
  { id: 'item-nvmc-1', nameEn: 'Egg Bhurji', nameHi: 'एग भुर्जी', price: 149, sectionPrices: sp(149), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-2', nameEn: 'Egg Curry (4P)', nameHi: 'एग कड़ी (4P)', price: 199, sectionPrices: sp(199), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-3', nameEn: 'Egg Masala (4P)', nameHi: 'एग मसाला (4P)', price: 199, sectionPrices: sp(199), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-4', nameEn: 'Chicken Chilli Gravy (4P)', nameHi: 'चिकन चीली ग्रेवी (4P)', price: 199, sectionPrices: sp(199), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-5', nameEn: 'Chicken Chilli Gravy (8P)', nameHi: 'चिकन चीली ग्रेवी (8P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-6', nameEn: 'Chicken Manchurian (8P)', nameHi: 'चिकन मंचूरियन (8P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-7', nameEn: 'Schezwan Chicken (8P)', nameHi: 'सेजवान चिकन (8P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-8', nameEn: 'Chicken Curry (2P)', nameHi: 'चिकन कड़ी (2P)', price: 199, sectionPrices: sp(199), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-9', nameEn: 'Chicken Curry (4P)', nameHi: 'चिकन कड़ी (4P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-10', nameEn: 'Chicken Kadhayi (2P)', nameHi: 'चिकन कढ़ाई (2P)', price: 199, sectionPrices: sp(199), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-11', nameEn: 'Chicken Kadhayi (4P)', nameHi: 'चिकन कढ़ाई (4P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-12', nameEn: 'Chicken Do Pyaza (2P)', nameHi: 'चिकन दो प्याजा (2P)', price: 199, sectionPrices: sp(199), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-13', nameEn: 'Chicken Do Pyaza (4P)', nameHi: 'चिकन दो प्याजा (4P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-14', nameEn: 'Chicken Masala (2P)', nameHi: 'चिकन मसाला (2P)', price: 229, sectionPrices: sp(229), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-15', nameEn: 'Chicken Masala (4P)', nameHi: 'चिकन मसाला (4P)', price: 329, sectionPrices: sp(329), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-16', nameEn: 'Chicken Butter Masala (2P)', nameHi: 'बटर चिकन मसाला (2P)', price: 249, sectionPrices: sp(249), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-17', nameEn: 'Chicken Butter Masala (4P)', nameHi: 'बटर चिकन मसाला (4P)', price: 339, sectionPrices: sp(339), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-18', nameEn: 'Chicken Rara (4P)', nameHi: 'चिकन रारा (4P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-19', nameEn: 'Chicken Korma (4P)', nameHi: 'चिकन कोरमा (4P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-20', nameEn: 'Chicken Kolhapuri (4P)', nameHi: 'चिकन कोल्हापुरी (4P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-21', nameEn: 'Chicken Shere Punjab (4P)', nameHi: 'चिकन शेरे पंजाब (4P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-22', nameEn: 'Chicken Lababdaar (4P)', nameHi: 'चिकन लबाबदार (4P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-23', nameEn: 'Chicken Dehati (8P)', nameHi: 'चिकन देहाती (8P)', price: 399, sectionPrices: sp(399), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-24', nameEn: 'Mutton Masala (2P)', nameHi: 'मटन मसाला (2P)', price: 299, sectionPrices: sp(299), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },
  { id: 'item-nvmc-25', nameEn: 'Mutton Masala (4P)', nameHi: 'मटन मसाला (4P)', price: 349, sectionPrices: sp(349), category: 'Non-Veg Main Course', kotPrint: true, discountable: true, active: true },

  // --- BREAD ---
  { id: 'item-brd-1', nameEn: 'Tawa Roti Plain', nameHi: 'तवा रोटी प्लेन', price: 10, sectionPrices: sp(10), category: 'Bread', kotPrint: true, discountable: true, active: true },
  { id: 'item-brd-2', nameEn: 'Tawa Roti Butter', nameHi: 'तवा रोटी बटर', price: 15, sectionPrices: sp(15), category: 'Bread', kotPrint: true, discountable: true, active: true },
  { id: 'item-brd-3', nameEn: 'Tandoori Roti Plain', nameHi: 'तंदूरी रोटी प्लेन', price: 25, sectionPrices: sp(25), category: 'Bread', kotPrint: true, discountable: true, active: true },
  { id: 'item-brd-4', nameEn: 'Tandoori Roti Butter', nameHi: 'तंदूरी रोटी बटर', price: 30, sectionPrices: sp(30), category: 'Bread', kotPrint: true, discountable: true, active: true },
  { id: 'item-brd-5', nameEn: 'Naan / Butter', nameHi: 'नान/बटर', price: 40, sectionPrices: sp(40), category: 'Bread', kotPrint: true, discountable: true, active: true },
  { id: 'item-brd-6', nameEn: 'Lachchha Paratha', nameHi: 'लच्छा पराठा', price: 49, sectionPrices: sp(49), category: 'Bread', kotPrint: true, discountable: true, active: true },
  { id: 'item-brd-7', nameEn: 'Garlic Naan', nameHi: 'गार्लिक नान', price: 59, sectionPrices: sp(59), category: 'Bread', kotPrint: true, discountable: true, active: true },
  { id: 'item-brd-8', nameEn: 'Paneer Stuffed Naan', nameHi: 'स्टफ्ड नान', price: 79, sectionPrices: sp(79), category: 'Bread', kotPrint: true, discountable: true, active: true },

  // --- DAAL ---
  { id: 'item-dal-1', nameEn: 'Daal Fry', nameHi: 'दाल फ्राई', price: 129, sectionPrices: sp(129), category: 'Daal', kotPrint: true, discountable: true, active: true },
  { id: 'item-dal-2', nameEn: 'Daal Tadka', nameHi: 'दाल तड़का', price: 129, sectionPrices: sp(129), category: 'Daal', kotPrint: true, discountable: true, active: true },

  // --- RICE ---
  { id: 'item-ric-1', nameEn: 'Jeera Rice', nameHi: 'जीरा राइस', price: 99, sectionPrices: sp(99), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-2', nameEn: 'Plain Rice', nameHi: 'प्लेन राइस', price: 99, sectionPrices: sp(99), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-3', nameEn: 'Veg Awadhi Pulav', nameHi: 'वेज अवधी पुलाव', price: 199, sectionPrices: sp(199), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-4', nameEn: 'Paneer Pulav', nameHi: 'पनीर पुलाव', price: 199, sectionPrices: sp(199), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-5', nameEn: 'Chicken Pulav', nameHi: 'चिकन पुलाव', price: 199, sectionPrices: sp(199), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-6', nameEn: 'Veg Biryani', nameHi: 'वेज बिरयानी', price: 199, sectionPrices: sp(199), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-7', nameEn: 'Paneer Biryani', nameHi: 'पनीर बिरयानी', price: 199, sectionPrices: sp(199), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-8', nameEn: 'Egg Biryani', nameHi: 'एग बिरयानी', price: 199, sectionPrices: sp(199), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-9', nameEn: 'Chicken Dum Biryani', nameHi: 'चिकन दम बिरयानी', price: 249, sectionPrices: sp(249), category: 'Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-ric-10', nameEn: 'Chicken Hyderabadi Biryani', nameHi: 'चिकन हैदराबादी बिरयानी', price: 299, sectionPrices: sp(299), category: 'Rice', kotPrint: true, discountable: true, active: true },

  // --- NOODLES / CHOWMIN ---
  { id: 'item-ndl-1', nameEn: 'Veg Noodles', nameHi: 'वेज नूडल्स', price: 129, sectionPrices: sp(129), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-2', nameEn: 'Schezwan Noodles', nameHi: 'सेजवान नूडल्स', price: 149, sectionPrices: sp(149), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-3', nameEn: 'Paneer Noodles', nameHi: 'पनीर नूडल्स', price: 149, sectionPrices: sp(149), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-4', nameEn: 'Veg Hakka Noodles', nameHi: 'वेज हक्का नूडल्स', price: 149, sectionPrices: sp(149), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-5', nameEn: 'Singapuri Chaumin', nameHi: 'सिंगापुरी चाउमीन', price: 199, sectionPrices: sp(199), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-6', nameEn: 'Egg Noodles', nameHi: 'एग नूडल्स', price: 199, sectionPrices: sp(199), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-7', nameEn: 'Chicken Noodles', nameHi: 'चिकन नूडल्स', price: 229, sectionPrices: sp(229), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-8', nameEn: 'Chicken Schezwan Noodle', nameHi: 'चिकन सेजवान नूडल', price: 229, sectionPrices: sp(229), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },
  { id: 'item-ndl-9', nameEn: 'Chicken Hakka Noodles', nameHi: 'चिकन हक्का नूडल्स', price: 229, sectionPrices: sp(229), category: 'Noodles/Chowmin', kotPrint: true, discountable: true, active: true },

  // --- CHINESE RICE ---
  { id: 'item-cnr-1', nameEn: 'Veg Fried Rice', nameHi: 'वेज फ्राइड राइस', price: 179, sectionPrices: sp(179), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-2', nameEn: 'Schezwan Fried Rice', nameHi: 'सेजवान फ्राइड राइस', price: 179, sectionPrices: sp(179), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-3', nameEn: 'Veg Chilli Garlic Rice', nameHi: 'वेज चीली गार्लिक राइस', price: 199, sectionPrices: sp(199), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-4', nameEn: 'Paneer Fried Rice', nameHi: 'पनीर फ्राइड राइस', price: 199, sectionPrices: sp(199), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-5', nameEn: 'Mushroom Fried Rice', nameHi: 'मशरुम फ्राइड राइस', price: 199, sectionPrices: sp(199), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-6', nameEn: 'Sweet Corn Fried Rice', nameHi: 'स्वीट कॉर्न फ्राइड राइस', price: 199, sectionPrices: sp(199), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-7', nameEn: 'Egg Fried Rice', nameHi: 'एग फ्राइड राइस', price: 199, sectionPrices: sp(199), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-8', nameEn: 'Chicken Fried Rice', nameHi: 'चिकन फ्राइड राइस', price: 229, sectionPrices: sp(229), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-9', nameEn: 'Schezwan Chicken Fried Rice', nameHi: 'सेजवान चिकन फ्राइड राइस', price: 229, sectionPrices: sp(229), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-10', nameEn: 'Chicken Chilli Garlic Fried Rice', nameHi: 'चिकन चीली गार्लिक राइस', price: 229, sectionPrices: sp(229), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },
  { id: 'item-cnr-11', nameEn: 'Non Veg Mixed Fried Rice', nameHi: 'नॉन वेज मिक्स्ड फ्राइड राइस', price: 249, sectionPrices: sp(249), category: 'Chinese Rice', kotPrint: true, discountable: true, active: true },

  // --- SOUP ---
  { id: 'item-sop-1', nameEn: 'Veg Hot & Sour Soup', nameHi: 'वेज हॉट एंड सॉर सूप', price: 129, sectionPrices: sp(129), category: 'Soup', kotPrint: true, discountable: true, active: true },
  { id: 'item-sop-2', nameEn: 'Veg Lemon Coriander Soup', nameHi: 'वेज लेमन कोरियंडर सूप', price: 129, sectionPrices: sp(129), category: 'Soup', kotPrint: true, discountable: true, active: true },
  { id: 'item-sop-3', nameEn: 'Veg Manchow Soup', nameHi: 'वेज मंचो सूप', price: 149, sectionPrices: sp(149), category: 'Soup', kotPrint: true, discountable: true, active: true },
  { id: 'item-sop-4', nameEn: 'Mushroom Soup', nameHi: 'मशरुम सूप', price: 149, sectionPrices: sp(149), category: 'Soup', kotPrint: true, discountable: true, active: true },
  { id: 'item-sop-5', nameEn: 'Sweet Corn Soup', nameHi: 'स्वीट कॉर्न सूप', price: 149, sectionPrices: sp(149), category: 'Soup', kotPrint: true, discountable: true, active: true },
  { id: 'item-sop-6', nameEn: 'Chicken Hot & Sour Soup', nameHi: 'चिकन हॉट एंड सॉर सूप', price: 179, sectionPrices: sp(179), category: 'Soup', kotPrint: true, discountable: true, active: true },
  { id: 'item-sop-7', nameEn: 'Chicken Lemon Coriander Soup', nameHi: 'चिकन लेमन कोरियंडर सूप', price: 179, sectionPrices: sp(179), category: 'Soup', kotPrint: true, discountable: true, active: true },
  { id: 'item-sop-8', nameEn: 'Chicken Manchow Soup', nameHi: 'चिकन मंचो सूप', price: 199, sectionPrices: sp(199), category: 'Soup', kotPrint: true, discountable: true, active: true },

  // --- MISCELLANEOUS ---
  { id: 'item-msc-1', nameEn: 'Onion Salad', nameHi: 'अनियन सलाद', price: 20, sectionPrices: sp(20), category: 'Miscellaneous', kotPrint: true, discountable: true, active: true },
  { id: 'item-msc-2', nameEn: 'Salad', nameHi: 'सलाद', price: 49, sectionPrices: sp(49), category: 'Miscellaneous', kotPrint: true, discountable: true, active: true },
  { id: 'item-msc-3', nameEn: 'Raita', nameHi: 'रायता', price: 49, sectionPrices: sp(49), category: 'Miscellaneous', kotPrint: true, discountable: true, active: true },
  { id: 'item-msc-4', nameEn: 'Papad (1P)', nameHi: 'पापड़ (1P)', price: 20, sectionPrices: sp(20), category: 'Miscellaneous', kotPrint: true, discountable: true, active: true },

  // --- DESSERTS ---
  { id: 'item-des-1', nameEn: 'Ice Cream Vanilla (2 Scoop)', nameHi: 'वनीला (2 Scoop)', price: 79, sectionPrices: sp(79), category: 'Desserts', kotPrint: false, discountable: false, active: true },
  { id: 'item-des-2', nameEn: 'Ice Cream Chocolate (2 Scoop)', nameHi: 'चॉकलेट (2 Scoop)', price: 89, sectionPrices: sp(89), category: 'Desserts', kotPrint: false, discountable: false, active: true },
  { id: 'item-des-3', nameEn: 'Ice Cream Butter scotch (2 Scoop)', nameHi: 'बटरस्कॉच (2 Scoop)', price: 99, sectionPrices: sp(99), category: 'Desserts', kotPrint: false, discountable: false, active: true },

  // --- TEA / COFFEE ---
  { id: 'item-tc-1', nameEn: 'Tea / Herbal Tea / Green Tea', nameHi: 'चाय / हर्बल टी / ग्रीन टी', price: 40, sectionPrices: sp(40), category: 'Tea/Coffee', kotPrint: true, discountable: true, active: true },
  { id: 'item-tc-2', nameEn: 'Coffee', nameHi: 'कॉफी', price: 49, sectionPrices: sp(49), category: 'Tea/Coffee', kotPrint: true, discountable: true, active: true },
  { id: 'item-tc-3', nameEn: 'Cold Coffee', nameHi: 'कोल्ड कॉफी', price: 129, sectionPrices: sp(129), category: 'Tea/Coffee', kotPrint: true, discountable: true, active: true },
  { id: 'item-tc-4', nameEn: 'Cold Coffee with Ice Cream', nameHi: 'कोल्ड कॉफी विथ आइसक्रीम', price: 179, sectionPrices: sp(179), category: 'Tea/Coffee', kotPrint: true, discountable: true, active: true },

  // --- MOCKTAIL ---
  { id: 'item-mck-1', nameEn: 'Soft Drink', nameHi: 'सॉफ्ट ड्रिंक', price: 25, sectionPrices: sp(25), category: 'Mocktail', kotPrint: false, discountable: false, active: true },
  { id: 'item-mck-2', nameEn: 'Mango Drink', nameHi: 'मैंगो ड्रिंक', price: 30, sectionPrices: sp(30), category: 'Mocktail', kotPrint: false, discountable: false, active: true },
  { id: 'item-mck-3', nameEn: 'Masala Cold Drink', nameHi: 'मसाला कोल्ड ड्रिंक', price: 40, sectionPrices: sp(40), category: 'Mocktail', kotPrint: false, discountable: false, active: true },
  { id: 'item-mck-4', nameEn: 'Masala Soda', nameHi: 'मसाला सोडा', price: 40, sectionPrices: sp(40), category: 'Mocktail', kotPrint: false, discountable: false, active: true },
  { id: 'item-mck-5', nameEn: 'Green Apple Mojito', nameHi: 'ग्रीन एप्पल मोहितो', price: 129, sectionPrices: sp(129), category: 'Mocktail', kotPrint: true, discountable: true, active: true },
  { id: 'item-mck-6', nameEn: 'Blue Lagoon Mojito', nameHi: 'ब्लू लगून मोहितो', price: 129, sectionPrices: sp(129), category: 'Mocktail', kotPrint: true, discountable: true, active: true },
  { id: 'item-mck-7', nameEn: 'Green Mint Mojito', nameHi: 'ग्रीन मिंट मोहितो', price: 129, sectionPrices: sp(129), category: 'Mocktail', kotPrint: true, discountable: true, active: true },

  // --- SHAKE ---
  { id: 'item-shk-1', nameEn: 'Vanilla Shake', nameHi: 'वनीला शेक', price: 179, sectionPrices: sp(179), category: 'Shake', kotPrint: true, discountable: true, active: true },
  { id: 'item-shk-2', nameEn: 'Chocolate Shake', nameHi: 'चॉकलेट शेक', price: 179, sectionPrices: sp(179), category: 'Shake', kotPrint: true, discountable: true, active: true },
  { id: 'item-shk-3', nameEn: 'Butterscotch Shake', nameHi: 'बटरस्कॉच शेक', price: 199, sectionPrices: sp(199), category: 'Shake', kotPrint: true, discountable: true, active: true },
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    name: 'Rajesh Kumar',
    mobile: '9876543210',
    whatsapp: '9876543210',
    address: 'Patory Bazar, Samastipur',
    dues: 250,
    advance: 0,
    totalOrders: 12,
    totalSpent: 3450,
    createdAt: '2026-06-10T10:00:00Z',
    lastVisit: '2026-07-28T14:30:00Z',
  },
  {
    id: 'cust-2',
    name: 'Suman Sharma',
    mobile: '8877044088',
    whatsapp: '8877044088',
    address: 'Cinema Chauk, Samastipur',
    dues: 0,
    advance: 150,
    totalOrders: 8,
    totalSpent: 2100,
    createdAt: '2026-06-15T11:20:00Z',
    lastVisit: '2026-07-29T19:10:00Z',
  },
];

export const INITIAL_STAFF: Staff[] = [
  {
    id: 'staff-1',
    name: 'Ramesh (Captain)',
    mobile: '9800011122',
    role: 'waiter',
    salary: 15000,
    advanceTotal: 2000,
    duesTotal: 13000,
    joinDate: '2025-01-10',
    assignedSections: ['sec-mealbox', 'sec-mbrestaurant', 'sec-cabin', 'sec-achall'],
  },
  {
    id: 'staff-2',
    name: 'Suresh (Waiter)',
    mobile: '9800011133',
    role: 'waiter',
    salary: 12000,
    advanceTotal: 1000,
    duesTotal: 11000,
    joinDate: '2025-03-15',
    assignedSections: ['sec-mealbox', 'sec-mbrestaurant'],
  },
  {
    id: 'staff-3',
    name: 'Prakash (Cashier)',
    mobile: '9800011144',
    role: 'cashier',
    salary: 18000,
    advanceTotal: 0,
    duesTotal: 18000,
    joinDate: '2024-11-01',
    assignedSections: ['sec-mealbox', 'sec-mbrestaurant', 'sec-cabin', 'sec-achall'],
  },
  {
    id: 'staff-4',
    name: 'Manoj (Chef/Kitchen)',
    mobile: '9800011155',
    role: 'kitchen',
    salary: 22000,
    advanceTotal: 3000,
    duesTotal: 19000,
    joinDate: '2024-08-01',
    assignedSections: ['sec-mealbox', 'sec-mbrestaurant', 'sec-cabin', 'sec-achall'],
  },
];

export const SYSTEM_USERS: User[] = [
  { id: 'usr-admin', name: 'MealBox Owner', role: 'owner', mobile: '8877044088', pin: '1234', assignedSections: ['sec-mealbox', 'sec-mbrestaurant', 'sec-cabin', 'sec-achall'] },
  { id: 'usr-manager', name: 'Manager Vikas', role: 'manager', mobile: '8888888888', pin: '9999', assignedSections: ['sec-mealbox', 'sec-mbrestaurant', 'sec-cabin', 'sec-achall'] },
  { id: 'usr-cashier', name: 'Cashier Prakash', role: 'cashier', mobile: '9800011144', pin: '1111', assignedSections: ['sec-mealbox', 'sec-mbrestaurant', 'sec-cabin', 'sec-achall'] },
  { id: 'usr-waiter', name: 'Waiter Ramesh', role: 'waiter', mobile: '9800011122', pin: '2222', assignedSections: ['sec-mealbox', 'sec-mbrestaurant'] },
  { id: 'usr-kitchen', name: 'Kitchen Staff', role: 'kitchen', mobile: '9800011155', pin: '3333', assignedSections: ['sec-mealbox', 'sec-mbrestaurant', 'sec-cabin', 'sec-achall'] },
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: 'inv-1',
    itemName: 'Water Bottle 1L',
    openingStock: 100,
    quantityIn: 50,
    quantityOut: 20,
    stock: 130,
    costPrice: 12,
    sellPrice: 20,
    unit: 'Bottle',
    lowStockThreshold: 20,
  },
  {
    id: 'inv-2',
    itemName: 'Soft Drink 300ml',
    openingStock: 60,
    quantityIn: 40,
    quantityOut: 15,
    stock: 85,
    costPrice: 15,
    sellPrice: 25,
    unit: 'Can/Bottle',
    lowStockThreshold: 15,
  },
  {
    id: 'inv-3',
    itemName: 'Vanilla Ice Cream Cup',
    openingStock: 40,
    quantityIn: 30,
    quantityOut: 10,
    stock: 60,
    costPrice: 40,
    sellPrice: 79,
    unit: 'Cup',
    lowStockThreshold: 10,
  },
  {
    id: 'inv-4',
    itemName: 'Takeaway Packing Box',
    openingStock: 500,
    quantityIn: 200,
    quantityOut: 45,
    stock: 655,
    costPrice: 4,
    sellPrice: 10,
    unit: 'Pcs',
    lowStockThreshold: 50,
  },
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-1',
    name: 'Samastipur Wholesale Traders',
    contactPerson: 'Vikram Singh',
    mobile: '9835012345',
    email: 'vikram@samastipurtraders.com',
    gstin: '10AAACR1234P1Z5',
    address: 'Station Road, Samastipur, Bihar',
    balanceDue: 4500,
    paymentTerms: '15 Days Credit',
    createdAt: '2026-07-01',
  },
  {
    id: 'sup-2',
    name: 'Dairy Fresh Supplies',
    contactPerson: 'Rajesh Kumar',
    mobile: '9835067890',
    email: 'dairyfresh@gmail.com',
    gstin: '10BBACR5678Q1Z2',
    address: 'Dairy Complex, Muzaffarpur',
    balanceDue: 0,
    paymentTerms: 'Weekly Cash',
    createdAt: '2026-07-05',
  },
  {
    id: 'sup-3',
    name: 'Royal Meat & Poultry',
    contactPerson: 'Mohd. Salim',
    mobile: '9835099887',
    address: 'Marris Market, Samastipur',
    balanceDue: 1200,
    paymentTerms: 'Pay on Delivery',
    createdAt: '2026-07-10',
  },
];

export const INITIAL_RAW_MATERIALS: RawMaterial[] = [
  {
    id: 'raw-1',
    name: 'Fresh Paneer',
    category: 'Dairy',
    unit: 'kg',
    currentStock: 18.5,
    lowStockThreshold: 5.0,
    unitCostPrice: 320, // ₹320 / kg
    supplierId: 'sup-2',
    supplierName: 'Dairy Fresh Supplies',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-2',
    name: 'Fresh Chicken (Bone-in/Boneless)',
    category: 'Meat & Poultry',
    unit: 'kg',
    currentStock: 25.0,
    lowStockThreshold: 8.0,
    unitCostPrice: 220, // ₹220 / kg
    supplierId: 'sup-3',
    supplierName: 'Royal Meat & Poultry',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-3',
    name: 'Butter (Amul)',
    category: 'Dairy',
    unit: 'kg',
    currentStock: 6.2,
    lowStockThreshold: 2.0,
    unitCostPrice: 480, // ₹480 / kg
    supplierId: 'sup-2',
    supplierName: 'Dairy Fresh Supplies',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-4',
    name: 'Fresh Cream',
    category: 'Dairy',
    unit: 'litre',
    currentStock: 4.5,
    lowStockThreshold: 2.0,
    unitCostPrice: 210, // ₹210 / litre
    supplierId: 'sup-2',
    supplierName: 'Dairy Fresh Supplies',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-5',
    name: 'Basmati Rice',
    category: 'Grains & Pulses',
    unit: 'kg',
    currentStock: 45.0,
    lowStockThreshold: 15.0,
    unitCostPrice: 95, // ₹95 / kg
    supplierId: 'sup-1',
    supplierName: 'Samastipur Wholesale Traders',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-6',
    name: 'Potato (AlOO)',
    category: 'Vegetables & Produce',
    unit: 'kg',
    currentStock: 30.0,
    lowStockThreshold: 10.0,
    unitCostPrice: 25, // ₹25 / kg
    supplierId: 'sup-1',
    supplierName: 'Samastipur Wholesale Traders',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-7',
    name: 'Tomato Puree / Fresh Tomatoes',
    category: 'Vegetables & Produce',
    unit: 'kg',
    currentStock: 12.0,
    lowStockThreshold: 4.0,
    unitCostPrice: 40, // ₹40 / kg
    supplierId: 'sup-1',
    supplierName: 'Samastipur Wholesale Traders',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-8',
    name: 'Refined Cooking Oil',
    category: 'Spices & Condiments',
    unit: 'litre',
    currentStock: 28.0,
    lowStockThreshold: 10.0,
    unitCostPrice: 135, // ₹135 / litre
    supplierId: 'sup-1',
    supplierName: 'Samastipur Wholesale Traders',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-9',
    name: 'Fresh Eggs',
    category: 'Dairy',
    unit: 'piece',
    currentStock: 120,
    lowStockThreshold: 30,
    unitCostPrice: 6.5, // ₹6.5 per egg
    supplierId: 'sup-3',
    supplierName: 'Royal Meat & Poultry',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
  {
    id: 'raw-10',
    name: 'Whole Wheat Flour (Atta / Maida)',
    category: 'Grains & Pulses',
    unit: 'kg',
    currentStock: 35.0,
    lowStockThreshold: 10.0,
    unitCostPrice: 38, // ₹38 / kg
    supplierId: 'sup-1',
    supplierName: 'Samastipur Wholesale Traders',
    updatedAt: '2026-08-01T10:00:00.000Z',
  },
];

export const INITIAL_RECIPES: Recipe[] = [
  {
    id: 'rec-1',
    menuItemId: 'item-vs-1', // French Fry
    menuItemName: 'French Fry',
    yieldServings: 1,
    totalCost: 18.5,
    updatedAt: '2026-08-01T10:00:00.000Z',
    ingredients: [
      { rawMaterialId: 'raw-6', quantity: 250, unit: 'g' }, // 250g Potatoes (₹6.25)
      { rawMaterialId: 'raw-8', quantity: 50, unit: 'ml' }, // 50ml Oil (₹6.75)
    ],
  },
  {
    id: 'rec-2',
    menuItemId: 'item-vmc-17', // Paneer Butter Masala (8P)
    menuItemName: 'Paneer Butter Masala (8P)',
    yieldServings: 1,
    totalCost: 96.5,
    updatedAt: '2026-08-01T10:00:00.000Z',
    ingredients: [
      { rawMaterialId: 'raw-1', quantity: 220, unit: 'g' }, // 220g Paneer (₹70.4)
      { rawMaterialId: 'raw-3', quantity: 30, unit: 'g' },  // 30g Butter (₹14.4)
      { rawMaterialId: 'raw-4', quantity: 40, unit: 'ml' }, // 40ml Cream (₹8.4)
      { rawMaterialId: 'raw-7', quantity: 80, unit: 'g' },  // 80g Tomato Puree (₹3.2)
    ],
  },
  {
    id: 'rec-3',
    menuItemId: 'item-nvmc-9', // Chicken Curry (4P)
    menuItemName: 'Chicken Curry (4P)',
    yieldServings: 1,
    totalCost: 112.0,
    updatedAt: '2026-08-01T10:00:00.000Z',
    ingredients: [
      { rawMaterialId: 'raw-2', quantity: 400, unit: 'g' }, // 400g Chicken (₹88.0)
      { rawMaterialId: 'raw-8', quantity: 60, unit: 'ml' }, // 60ml Oil (₹8.1)
      { rawMaterialId: 'raw-7', quantity: 150, unit: 'g' }, // 150g Tomato/Onion Gravy (₹6.0)
    ],
  },
  {
    id: 'rec-4',
    menuItemId: 'item-nvmc-2', // Egg Curry (4P)
    menuItemName: 'Egg Curry (4P)',
    yieldServings: 1,
    totalCost: 48.0,
    updatedAt: '2026-08-01T10:00:00.000Z',
    ingredients: [
      { rawMaterialId: 'raw-9', quantity: 4, unit: 'piece' }, // 4 Eggs (₹26.0)
      { rawMaterialId: 'raw-8', quantity: 40, unit: 'ml' },   // 40ml Oil (₹5.4)
      { rawMaterialId: 'raw-7', quantity: 100, unit: 'g' },   // 100g Gravy (₹4.0)
    ],
  },
];

export const INITIAL_PURCHASE_ENTRIES: PurchaseEntry[] = [
  {
    id: 'pur-101',
    purchaseNumber: 'PO-2026-001',
    supplierId: 'sup-2',
    supplierName: 'Dairy Fresh Supplies',
    invoiceNumber: 'INV-DF-8812',
    invoiceDate: '2026-08-01',
    totalAmount: 6400,
    paidAmount: 6400,
    paymentMode: 'online',
    createdAt: '2026-08-01T09:30:00.000Z',
    createdBy: 'Manager Vikas',
    items: [
      {
        rawMaterialId: 'raw-1',
        rawMaterialName: 'Fresh Paneer',
        quantity: 15,
        unit: 'kg',
        unitCostPrice: 320,
        totalCost: 4800,
        batchNumber: 'LOT-PN-20260801',
        expiryDate: '2026-08-05',
      },
      {
        rawMaterialId: 'raw-4',
        rawMaterialName: 'Fresh Cream',
        quantity: 8,
        unit: 'litre',
        unitCostPrice: 200,
        totalCost: 1600,
        batchNumber: 'LOT-CR-20260801',
        expiryDate: '2026-08-10',
      },
    ],
  },
];

export const INITIAL_STOCK_LOGS: StockMovementLog[] = [
  {
    id: 'log-1',
    rawMaterialId: 'raw-1',
    rawMaterialName: 'Fresh Paneer',
    type: 'purchase_in',
    quantity: 15,
    unit: 'kg',
    previousStock: 3.5,
    newStock: 18.5,
    unitCostPrice: 320,
    totalCost: 4800,
    referenceId: 'PO-2026-001',
    notes: 'Received fresh morning supply',
    timestamp: '2026-08-01T09:30:00.000Z',
    createdBy: 'Manager Vikas',
  },
  {
    id: 'log-2',
    rawMaterialId: 'raw-2',
    rawMaterialName: 'Fresh Chicken',
    type: 'purchase_in',
    quantity: 25,
    unit: 'kg',
    previousStock: 0,
    newStock: 25.0,
    unitCostPrice: 220,
    totalCost: 5500,
    referenceId: 'PO-2026-002',
    notes: 'Daily poultry stock inward',
    timestamp: '2026-08-01T09:45:00.000Z',
    createdBy: 'MealBox Owner',
  },
];

export const INITIAL_WASTE_ENTRIES: WasteEntry[] = [
  {
    id: 'wst-1',
    type: 'raw_material',
    referenceId: 'raw-1',
    name: 'Fresh Paneer',
    quantity: 0.5,
    unit: 'kg',
    reason: 'Spoiled',
    estimatedCost: 160,
    notes: 'Trimming loss / outer layer oxidized',
    createdAt: '2026-08-01T11:00:00.000Z',
    createdBy: 'Manoj (Chef)',
  },
];

