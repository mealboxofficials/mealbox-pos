import { RESTAURANT_CONFIG } from '../data/restaurantConfig';

/**
 * Downloads data as a CSV file compatible with Excel.
 */
export function exportToCsv(
  filename: string,
  headers: string[],
  rows: (string | number | boolean | null | undefined)[][]
): void {
  const sanitize = (val: any): string => {
    if (val === null || val === undefined) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const headerRow = headers.map(sanitize).join(',');
  const dataRows = rows.map((row) => row.map(sanitize).join(','));
  const csvContent = [headerRow, ...dataRows].join('\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Triggers browser print window with a styled printable report layout.
 */
export function printReport(
  reportTitle: string,
  dateFilterText: string,
  tableHeaders: string[],
  tableRows: (string | number)[][],
  summaryCards?: { label: string; value: string }[]
): void {
  const printWindow = window.open('', '_blank', 'width=900,height=700');
  if (!printWindow) return;

  const now = new Date().toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const summaryHtml = summaryCards && summaryCards.length > 0
    ? `<div style="display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap;">
        ${summaryCards
          .map(
            (card) => `
          <div style="flex: 1; min-width: 130px; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; background-color: #f8fafc;">
            <div style="font-size: 10px; text-transform: uppercase; color: #64748b; font-weight: bold;">${card.label}</div>
            <div style="font-size: 16px; font-weight: 900; color: #0f172a; margin-top: 4px;">${card.value}</div>
          </div>
        `
          )
          .join('')}
      </div>`
    : '';

  const headersHtml = tableHeaders.map((h) => `<th style="padding: 8px; border: 1px solid #cbd5e1; background-color: #f1f5f9; text-align: left; font-size: 11px;">${h}</th>`).join('');

  const rowsHtml = tableRows
    .map(
      (row) =>
        `<tr>${row
          .map(
            (cell) =>
              `<td style="padding: 8px; border: 1px solid #cbd5e1; font-size: 11px; font-family: monospace;">${cell}</td>`
          )
          .join('')}</tr>`
    )
    .join('');

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <title>${reportTitle} - ${RESTAURANT_CONFIG.name}</title>
        <style>
          body { font-family: system-ui, -apple-system, sans-serif; padding: 20px; color: #0f172a; }
          .header { text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 16px; }
          .title { font-size: 20px; font-weight: 900; margin: 4px 0; color: #d97706; }
          .sub { font-size: 12px; color: #475569; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          .footer { margin-top: 24px; font-size: 10px; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 8px; }
          @media print {
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div style="font-size: 16px; font-weight: 800;">${RESTAURANT_CONFIG.name}</div>
          <div class="sub">${RESTAURANT_CONFIG.address} | Ph: ${RESTAURANT_CONFIG.contactPhone}</div>
          <div class="title">${reportTitle}</div>
          <div class="sub">Period: ${dateFilterText} | Generated: ${now}</div>
        </div>

        ${summaryHtml}

        <table>
          <thead>
            <tr>${headersHtml}</tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <div class="footer">
          MealBox POS Operational Analytics Report &bull; Confidential &bull; Generated automatically
        </div>

        <script>
          window.onload = function() {
            window.print();
          };
        </script>
      </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
}
