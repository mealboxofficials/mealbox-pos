import { InventoryUnit, RawMaterial, RecipeIngredient } from '../types';

/**
 * Converts a quantity from one unit to another base unit.
 * Mass: kg / Kg <-> g / Gram (1 kg = 1000 g)
 * Volume: litre / Litre <-> ml (1 litre = 1000 ml)
 * Count: dozen -> piece (1 dozen = 12 pieces)
 */
export function convertUnitQuantity(
  quantity: number,
  fromUnit: InventoryUnit,
  toUnit: InventoryUnit
): number {
  const normFrom = (fromUnit || '').toString().toLowerCase();
  const normTo = (toUnit || '').toString().toLowerCase();

  if (normFrom === normTo) return quantity;

  // Mass conversions
  if ((normFrom === 'kg' || normFrom === 'kilogram') && (normTo === 'g' || normTo === 'gram'))
    return quantity * 1000;
  if ((normFrom === 'g' || normFrom === 'gram') && (normTo === 'kg' || normTo === 'kilogram'))
    return quantity / 1000;

  // Volume conversions
  if ((normFrom === 'litre' || normFrom === 'liter' || normFrom === 'l') && normTo === 'ml')
    return quantity * 1000;
  if (normFrom === 'ml' && (normTo === 'litre' || normTo === 'liter' || normTo === 'l'))
    return quantity / 1000;

  // Count conversions
  if (normFrom === 'dozen' && (normTo === 'piece' || normTo === 'pc')) return quantity * 12;
  if ((normFrom === 'piece' || normFrom === 'pc') && normTo === 'dozen') return quantity / 12;

  // Default fallback if incompatible custom units
  return quantity;
}

/**
 * Calculates the total raw material cost for an ingredient in a recipe.
 * Accepts either (ingredient, rawMaterial) OR (ingredient, unitCostPrice, unit).
 */
export function calculateIngredientCost(
  ingredient: RecipeIngredient,
  rawMaterialOrCost: RawMaterial | number,
  unit?: InventoryUnit
): number {
  if (!ingredient) return 0;

  if (typeof rawMaterialOrCost === 'number') {
    const rawUnit = unit || ingredient.unit;
    const qtyInRawMaterialUnit = convertUnitQuantity(
      ingredient.quantity,
      ingredient.unit,
      rawUnit
    );
    return qtyInRawMaterialUnit * rawMaterialOrCost;
  }

  const rawMaterial = rawMaterialOrCost;
  if (!rawMaterial) return 0;

  const qtyInRawMaterialUnit = convertUnitQuantity(
    ingredient.quantity,
    ingredient.unit,
    rawMaterial.unit
  );

  return qtyInRawMaterialUnit * rawMaterial.unitCostPrice;
}

/**
 * Calculates total recipe cost for a dish.
 */
export function calculateRecipeTotalCost(
  ingredients: RecipeIngredient[],
  rawMaterialsMap: Map<string, RawMaterial> | Record<string, RawMaterial>
): number {
  if (!ingredients || !Array.isArray(ingredients)) return 0;
  return ingredients.reduce((sum, ing) => {
    const rawMat =
      rawMaterialsMap instanceof Map
        ? rawMaterialsMap.get(ing.rawMaterialId)
        : rawMaterialsMap[ing.rawMaterialId];
    if (!rawMat) return sum;
    return sum + calculateIngredientCost(ing, rawMat);
  }, 0);
}

/**
 * Calculates Food Cost %: (Raw Material Cost / Selling Price) * 100
 */
export function calculateFoodCostPercentage(
  costPrice: number,
  sellingPrice: number
): number {
  if (!sellingPrice || sellingPrice <= 0) return 0;
  return Number(((costPrice / sellingPrice) * 100).toFixed(1));
}

/**
 * Returns Tailwind style badge classes based on Food Cost % threshold
 */
export function getFoodCostColor(foodCostPct: number): string {
  if (foodCostPct <= 30) {
    return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
  } else if (foodCostPct <= 38) {
    return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
  } else {
    return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
  }
}
