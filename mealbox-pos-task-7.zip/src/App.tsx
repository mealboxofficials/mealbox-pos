import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { ToastContainer } from './components/ToastContainer';
import { OrderFlow } from './components/POS/OrderFlow';
import { KitchenDisplay } from './components/Kitchen/KitchenDisplay';
import { CustomerManagement } from './components/CRM/CustomerManagement';
import { ReportsAnalytics } from './components/Reports/ReportsAnalytics';
import { ExpenseManagement } from './components/Expenses/ExpenseManagement';
import { StaffManagement } from './components/Staff/StaffManagement';
import { InventoryManagement } from './components/Inventory/InventoryManagement';
import { MenuManagement } from './components/MenuAdmin/MenuManagement';
import { CustomerMenuApp } from './components/QROrdering/CustomerMenuApp';
import { DayOpenCloseModal } from './components/DayManagement/DayOpenCloseModal';
import { PinLockModal } from './components/Auth/PinLockModal';
import { X, DollarSign } from 'lucide-react';

function MainLayout() {
  const [activeTab, setActiveTab] = useState<string>('pos');
  const [showDayModal, setShowDayModal] = useState(false);
  const [showWalkInModal, setShowWalkInModal] = useState(false);
  const [qrParamTableId, setQrParamTableId] = useState<string | undefined>(undefined);

  const { addWalkInAdvance, isLocked } = useApp();

  // Parse URL query parameter for QR Table scan
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const qrTable = params.get('qrTable');
    if (qrTable) {
      setQrParamTableId(qrTable);
      setActiveTab('qr_customer');
    }
  }, []);

  // Walk in advance modal state
  const [advMobile, setAdvMobile] = useState('');
  const [advName, setAdvName] = useState('');
  const [advAmount, setAdvAmount] = useState('');

  const handleWalkInAdvanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!advMobile || !advAmount) return;
    addWalkInAdvance(advMobile, advName, Number(advAmount) || 0);
    setAdvMobile('');
    setAdvName('');
    setAdvAmount('');
    setShowWalkInModal(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-amber-500 selection:text-slate-950 flex flex-col">
      {/* Top Navbar Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDayModal={() => setShowDayModal(true)}
        onOpenWalkInAdvanceModal={() => setShowWalkInModal(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 overflow-x-hidden">
        {activeTab === 'pos' && <OrderFlow />}
        {activeTab === 'kitchen' && <KitchenDisplay />}
        {activeTab === 'history' && <ReportsAnalytics />}
        {activeTab === 'crm' && <CustomerManagement />}
        {activeTab === 'reports' && <ReportsAnalytics />}
        {activeTab === 'expenses' && <ExpenseManagement />}
        {activeTab === 'staff' && <StaffManagement />}
        {activeTab === 'inventory' && <InventoryManagement />}
        {activeTab === 'menu' && <MenuManagement />}
        {activeTab === 'qr_customer' && (
          <CustomerMenuApp
            initialTableId={qrParamTableId}
            onBackToPos={() => setActiveTab('pos')}
          />
        )}
      </main>

      {/* Terminal Lock Overlay */}
      {isLocked && <PinLockModal />}

      {/* Floating Action Notifications */}
      <ToastContainer />

      {/* Day Open / Day Close Modal */}
      {showDayModal && (
        <DayOpenCloseModal onClose={() => setShowDayModal(false)} />
      )}

      {/* Quick Walk-in Advance Payment Modal */}
      {showWalkInModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleWalkInAdvanceSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <DollarSign className="w-5 h-5" />
                <h3 className="text-slate-100 text-base">Record Walk-in Advance Credit</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowWalkInModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Customer pays money before placing an order. Saved as credit in customer account for future bills.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Customer Mobile *</label>
                <input
                  type="text"
                  required
                  placeholder="10-digit mobile number"
                  value={advMobile}
                  onChange={(e) => setAdvMobile(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Customer Name</label>
                <input
                  type="text"
                  placeholder="Full name"
                  value={advName}
                  onChange={(e) => setAdvName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Advance Amount Received (₹) *</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 500"
                  value={advAmount}
                  onChange={(e) => setAdvAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 text-lg font-bold text-emerald-400"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowWalkInModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs shadow-lg"
              >
                Save Advance Credit
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
