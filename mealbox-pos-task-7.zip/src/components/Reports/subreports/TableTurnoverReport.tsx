import React, { useState } from 'react';
import { Order, Section } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Utensils, Download, Printer, Search } from 'lucide-react';

interface TableTurnoverReportProps {
  orders: Order[];
  sections: Section[];
  dateFilterText: string;
}

export const TableTurnoverReport: React.FC<TableTurnoverReportProps> = ({
  orders,
  sections,
  dateFilterText,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Filter dine-in settled orders
  const dineInOrders = orders.filter((o) => o.mode === 'dine_in' && o.status === 'settled');

  const tableMap: Record<
    string,
    {
      tableName: string;
      sectionName: string;
      turnoverCount: number;
      guestsTotal: number;
      revenue: number;
    }
  > = {};

  dineInOrders.forEach((o) => {
    const key = `${o.sectionName}_${o.tableName || 'Counter'}`;
    if (!tableMap[key]) {
      tableMap[key] = {
        tableName: o.tableName || 'Counter / Unassigned',
        sectionName: o.sectionName || 'Main Dining',
        turnoverCount: 0,
        guestsTotal: 0,
        revenue: 0,
      };
    }

    tableMap[key].turnoverCount += 1;
    tableMap[key].guestsTotal += o.guestCount || 2;
    tableMap[key].revenue += o.finalTotal;
  });

  const tableList = Object.values(tableMap).sort((a, b) => b.revenue - a.revenue);
  const totalDineInRevenue = tableList.reduce((s, t) => s + t.revenue, 0);

  const filteredList = tableList.filter(
    (t) =>
      t.tableName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.sectionName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleExportCsv = () => {
    const headers = ['Table Name', 'Section', 'Turnover Count (Bills)', 'Total Guests Served', 'Total Revenue (₹)', 'RevPASH / Avg per Turnover (₹)'];
    const rows = tableList.map((t) => [
      t.tableName,
      t.sectionName,
      t.turnoverCount,
      t.guestsTotal,
      t.revenue,
      t.turnoverCount > 0 ? Math.round(t.revenue / t.turnoverCount) : 0,
    ]);
    exportToCsv('Table_Turnover_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Table', 'Section', 'Turnovers', 'Guests', 'Revenue', 'Avg / Table'];
    const rows = tableList.map((t) => [
      t.tableName,
      t.sectionName,
      t.turnoverCount,
      t.guestsTotal,
      `₹${t.revenue}`,
      `₹${t.turnoverCount > 0 ? Math.round(t.revenue / t.turnoverCount) : 0}`,
    ]);
    printReport('Table Turnover & Occupancy Analytics Report', dateFilterText, headers, rows, [
      { label: 'Dine-In Revenue', value: `₹${totalDineInRevenue}` },
      { label: 'Total Turnovers', value: tableList.reduce((s, t) => s + t.turnoverCount, 0).toString() },
      { label: 'Total Guests Served', value: tableList.reduce((s, t) => s + t.guestsTotal, 0).toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Utensils className="w-5 h-5 text-amber-400" />
            Table Turnover & Occupancy Report
          </h3>
          <p className="text-xs text-slate-400">Analyze table utilization, seating efficiency, and revenue per table</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Table or Section..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Table Name</th>
              <th className="p-3">Dining Section</th>
              <th className="p-3 text-center">Turnover Count</th>
              <th className="p-3 text-center">Total Guests Served</th>
              <th className="p-3 text-right">Avg Revenue per Seating</th>
              <th className="p-3 text-right">Total Revenue Generated (₹)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-6 text-center text-slate-500 font-bold">
                  No table turnover data found for selected period
                </td>
              </tr>
            ) : (
              filteredList.map((t, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-black text-amber-300">{t.tableName}</td>
                  <td className="p-3 text-slate-400">{t.sectionName}</td>
                  <td className="p-3 text-center font-bold text-slate-100">{t.turnoverCount}</td>
                  <td className="p-3 text-center text-slate-300 font-semibold">{t.guestsTotal}</td>
                  <td className="p-3 text-right font-bold text-emerald-400">
                    ₹{t.turnoverCount > 0 ? Math.round(t.revenue / t.turnoverCount) : 0}
                  </td>
                  <td className="p-3 text-right font-black text-amber-400">₹{t.revenue}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
