import React, { useState } from 'react';
import { MenuItem, Recipe, RawMaterial } from '../../../types';
import { calculateRecipeTotalCost, calculateFoodCostPercentage, getFoodCostColor } from '../../../utils/inventoryEngine';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { TrendingUp, Download, Printer, Search, AlertCircle } from 'lucide-react';

interface FoodCostReportProps {
  menuItems: MenuItem[];
  recipes: Recipe[];
  rawMaterials: RawMaterial[];
  dateFilterText: string;
}

export const FoodCostReport: React.FC<FoodCostReportProps> = ({
  menuItems,
  recipes,
  rawMaterials,
  dateFilterText,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const rawMap = new Map<string, RawMaterial>(rawMaterials.map((r) => [r.id, r]));

  const recipeMap: Record<string, Recipe> = {};
  recipes.forEach((r) => {
    recipeMap[r.menuItemId] = r;
  });

  const dishCostList = menuItems.map((item) => {
    const rec = recipeMap[item.id];
    const costPrice = rec ? calculateRecipeTotalCost(rec.ingredients, rawMap) : 0;
    const foodCostPct = calculateFoodCostPercentage(costPrice, item.price);
    const profitMargin = item.price - costPrice;

    return {
      id: item.id,
      nameEn: item.nameEn,
      category: item.category,
      price: item.price,
      costPrice,
      foodCostPct,
      profitMargin,
      hasRecipe: !!rec && rec.ingredients.length > 0,
    };
  }).sort((a, b) => b.foodCostPct - a.foodCostPct);

  const filteredList = dishCostList.filter((d) =>
    d.nameEn.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const avgFoodCost =
    dishCostList.length > 0
      ? Number(
          (dishCostList.reduce((s, d) => s + d.foodCostPct, 0) / dishCostList.length).toFixed(1)
        )
      : 0;

  const highFoodCostDishes = dishCostList.filter((d) => d.foodCostPct > 35);

  const handleExportCsv = () => {
    const headers = ['Dish Name', 'Category', 'Selling Price (₹)', 'Recipe Cost (₹)', 'Food Cost %', 'Profit Margin (₹)', 'Status'];
    const rows = dishCostList.map((d) => [
      d.nameEn,
      d.category,
      d.price,
      d.costPrice.toFixed(2),
      `${d.foodCostPct}%`,
      d.profitMargin.toFixed(2),
      d.foodCostPct > 35 ? 'HIGH COST (>35%)' : d.foodCostPct >= 28 ? 'MODERATE' : 'IDEAL (<28%)',
    ]);
    exportToCsv('Food_Cost_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Dish Name', 'Category', 'Sell Price', 'Recipe Cost', 'Food Cost %', 'Margin'];
    const rows = dishCostList.map((d) => [
      d.nameEn,
      d.category,
      `₹${d.price}`,
      `₹${d.costPrice.toFixed(2)}`,
      `${d.foodCostPct}%`,
      `₹${d.profitMargin.toFixed(2)}`,
    ]);
    printReport('Food Cost & Dish Margin Analysis Report', dateFilterText, headers, rows, [
      { label: 'Average Menu Food Cost %', value: `${avgFoodCost}%` },
      { label: 'High Food Cost Dishes (>35%)', value: highFoodCostDishes.length.toString() },
      { label: 'Total Menu Items Analyzed', value: menuItems.length.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-amber-400" />
            Food Cost % & Profitability Margin Report
          </h3>
          <p className="text-xs text-slate-400">Target vs actual food cost %, theoretical recipe margins, and high-cost dish warnings</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Overview Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Average Menu Food Cost %</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{avgFoodCost}%</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Industry ideal target: 28% - 32%</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-500/30">
          <div className="text-[10px] uppercase font-bold text-rose-400">High Food Cost Warning Dishes (&gt;35%)</div>
          <div className="text-2xl font-black text-rose-400 mt-1">{highFoodCostDishes.length} Items</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Requires recipe audit or price review</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30">
          <div className="text-[10px] uppercase font-bold text-emerald-400">Ideal Margin Dishes (&lt;30%)</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">
            {dishCostList.filter((d) => d.foodCostPct <= 30 && d.hasRecipe).length} Items
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">High profitability stars</div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search dish name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Dish Name</th>
              <th className="p-3">Category</th>
              <th className="p-3 text-right">Selling Price (₹)</th>
              <th className="p-3 text-right">Recipe Raw Cost (₹)</th>
              <th className="p-3 text-center">Food Cost %</th>
              <th className="p-3 text-right">Profit Margin per Dish</th>
              <th className="p-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-6 text-center text-slate-500 font-bold">
                  No food cost data found
                </td>
              </tr>
            ) : (
              filteredList.map((d) => (
                <tr key={d.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-extrabold text-slate-100">{d.nameEn}</td>
                  <td className="p-3 text-slate-400">{d.category}</td>
                  <td className="p-3 text-right font-bold text-slate-100">₹{d.price}</td>
                  <td className="p-3 text-right font-bold text-amber-300">
                    {d.hasRecipe ? `₹${d.costPrice.toFixed(2)}` : 'No Recipe'}
                  </td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-black border ${getFoodCostColor(
                        d.foodCostPct
                      )}`}
                    >
                      {d.foodCostPct}%
                    </span>
                  </td>
                  <td className="p-3 text-right font-black text-emerald-400">
                    ₹{d.profitMargin.toFixed(2)}
                  </td>
                  <td className="p-3 text-center">
                    {d.foodCostPct > 35 ? (
                      <span className="text-[10px] font-bold text-rose-400 flex items-center justify-center gap-1">
                        <AlertCircle className="w-3 h-3 text-rose-400" />
                        <span>High Cost</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-400">Good Margin</span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
