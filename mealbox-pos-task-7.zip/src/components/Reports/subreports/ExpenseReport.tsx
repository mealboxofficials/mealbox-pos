import React, { useState } from 'react';
import { Expense } from '../../../types';
import { SimpleDonutChart } from '../ReportCharts';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { DollarSign, Download, Printer, Search } from 'lucide-react';

interface ExpenseReportProps {
  expenses: Expense[];
  dateFilterText: string;
}

export const ExpenseReport: React.FC<ExpenseReportProps> = ({ expenses, dateFilterText }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['Goods', 'Vendor', 'Staff', 'Rent', 'Electricity', 'Other'];

  const categoryMap: Record<string, number> = {};
  categories.forEach((cat) => (categoryMap[cat] = 0));

  expenses.forEach((e) => {
    if (categoryMap[e.category] !== undefined) {
      categoryMap[e.category] += e.amount;
    } else {
      categoryMap['Other'] += e.amount;
    }
  });

  const totalExpense = expenses.reduce((s, e) => s + e.amount, 0);

  const filteredExpenses = expenses.filter((e) => {
    const matchesCategory = selectedCategory === 'all' || e.category === selectedCategory;
    const matchesSearch =
      e.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const chartColors = ['#f43f5e', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#64748b'];

  const donutData = Object.entries(categoryMap)
    .filter(([_, val]) => val > 0)
    .map(([cat, val], idx) => ({
      label: cat,
      value: val,
      color: chartColors[idx % chartColors.length],
    }));

  const handleExportCsv = () => {
    const headers = ['Expense ID', 'Category', 'Description', 'Amount (₹)', 'Payment Mode', 'Date', 'Created By'];
    const rows = filteredExpenses.map((e) => [
      e.id,
      e.category,
      e.description,
      e.amount,
      e.mode.toUpperCase(),
      e.date,
      e.createdBy,
    ]);
    exportToCsv('Expense_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Category', 'Description', 'Amount', 'Payment Mode', 'Date', 'Created By'];
    const rows = filteredExpenses.map((e) => [
      e.category,
      e.description,
      `₹${e.amount}`,
      e.mode.toUpperCase(),
      e.date,
      e.createdBy,
    ]);
    printReport('Operational Expenses Breakdown Report', dateFilterText, headers, rows, [
      { label: 'Total Operational Expenses', value: `₹${totalExpense}` },
      { label: 'Expense Entries', value: expenses.length.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-amber-400" />
            Restaurant Operational Expense Report
          </h3>
          <p className="text-xs text-slate-400">Category-wise operational costs, cash vs online expense vouchers</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Donut Chart */}
      {donutData.length > 0 && (
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-850">
          <SimpleDonutChart data={donutData} totalLabel="Total Expenses" />
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search expense description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-amber-400 text-xs font-bold rounded-xl px-3 py-1.5 focus:outline-none cursor-pointer"
        >
          <option value="all">All Expense Categories</option>
          {categories.map((c, idx) => (
            <option key={idx} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Category</th>
              <th className="p-3">Description</th>
              <th className="p-3">Date</th>
              <th className="p-3 text-center">Payment Mode</th>
              <th className="p-3 text-right">Amount (₹)</th>
              <th className="p-3 text-center">Logged By</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredExpenses.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-6 text-center text-slate-500 font-bold">
                  No operational expenses logged for selected filter
                </td>
              </tr>
            ) : (
              filteredExpenses.map((e) => (
                <tr key={e.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-extrabold text-rose-400">{e.category}</td>
                  <td className="p-3 text-slate-100 font-bold">{e.description}</td>
                  <td className="p-3 text-slate-400">{e.date}</td>
                  <td className="p-3 text-center uppercase">
                    <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-bold">
                      {e.mode}
                    </span>
                  </td>
                  <td className="p-3 text-right font-black text-rose-400">₹{e.amount}</td>
                  <td className="p-3 text-center text-slate-400">{e.createdBy}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
