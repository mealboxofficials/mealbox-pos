import React from 'react';
import { DaySession } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { CalendarCheck, Download, Printer } from 'lucide-react';

interface DayOpenCloseReportProps {
  daySessions: DaySession[];
  dateFilterText: string;
}

export const DayOpenCloseReport: React.FC<DayOpenCloseReportProps> = ({
  daySessions,
  dateFilterText,
}) => {
  const sessionList = [...daySessions].sort(
    (a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime()
  );

  const handleExportCsv = () => {
    const headers = ['Opened At', 'Opened By', 'Closed At', 'Closed By', 'Opening Cash (₹)', 'Cash Sales (₹)', 'Cash Drops (₹)', 'Expected Cash (₹)', 'Actual Closing Cash (₹)', 'Discrepancy (₹)', 'Status'];
    const rows = sessionList.map((s) => [
      new Date(s.openedAt).toLocaleString(),
      s.openedBy,
      s.closedAt ? new Date(s.closedAt).toLocaleString() : 'OPEN SESSION',
      s.closedBy || 'N/A',
      s.openingCash,
      s.cashSales || 0,
      s.cashDrops || 0,
      s.expectedCash || 0,
      s.closingCash || 0,
      s.discrepancy || 0,
      s.isClosed ? 'CLOSED' : 'OPEN',
    ]);
    exportToCsv('Day_Open_Close_Audit_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Opened', 'Closed By', 'Opening', 'Cash Sales', 'Expected', 'Actual', 'Diff'];
    const rows = sessionList.map((s) => [
      new Date(s.openedAt).toLocaleDateString(),
      s.closedBy || 'OPEN',
      `₹${s.openingCash}`,
      `₹${s.cashSales || 0}`,
      `₹${s.expectedCash || 0}`,
      `₹${s.closingCash || 0}`,
      `₹${s.discrepancy || 0}`,
    ]);
    printReport('Day Open / Close Register Audit Log', dateFilterText, headers, rows, [
      { label: 'Total Register Sessions', value: daySessions.length.toString() },
      { label: 'Active Open Sessions', value: daySessions.filter((s) => !s.isClosed).length.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-amber-400" />
            Day Open / Close Register Audit Report
          </h3>
          <p className="text-xs text-slate-400">Daily cash drawer balance checks, opening float, cash drops, and discrepancies</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Opened Time</th>
              <th className="p-3">Opened By</th>
              <th className="p-3">Closed Time</th>
              <th className="p-3 text-right">Opening Float</th>
              <th className="p-3 text-right">Cash Sales</th>
              <th className="p-3 text-right">Cash Drops</th>
              <th className="p-3 text-right">Expected Cash</th>
              <th className="p-3 text-right">Actual Count</th>
              <th className="p-3 text-right">Discrepancy</th>
              <th className="p-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {sessionList.length === 0 ? (
              <tr>
                <td colSpan={10} className="p-6 text-center text-slate-500 font-bold">
                  No day register sessions recorded
                </td>
              </tr>
            ) : (
              sessionList.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-bold text-amber-300">
                    {new Date(s.openedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                  </td>
                  <td className="p-3 text-slate-300">{s.openedBy}</td>
                  <td className="p-3 text-slate-400">
                    {s.closedAt
                      ? new Date(s.closedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })
                      : 'STILL OPEN'}
                  </td>
                  <td className="p-3 text-right font-bold text-slate-200">₹{s.openingCash}</td>
                  <td className="p-3 text-right font-bold text-emerald-400">₹{s.cashSales || 0}</td>
                  <td className="p-3 text-right text-rose-400">₹{s.cashDrops || 0}</td>
                  <td className="p-3 text-right font-black text-slate-100">₹{s.expectedCash || 0}</td>
                  <td className="p-3 text-right font-black text-amber-400">₹{s.closingCash || 0}</td>
                  <td className="p-3 text-right font-black">
                    {s.discrepancy !== undefined && s.discrepancy !== 0 ? (
                      <span className={s.discrepancy < 0 ? 'text-rose-400' : 'text-emerald-400'}>
                        {s.discrepancy > 0 ? `+₹${s.discrepancy}` : `-₹${Math.abs(s.discrepancy)}`}
                      </span>
                    ) : (
                      <span className="text-slate-500">₹0</span>
                    )}
                  </td>
                  <td className="p-3 text-center uppercase">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black ${
                        s.isClosed
                          ? 'bg-slate-800 text-slate-300 border border-slate-700'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {s.isClosed ? 'CLOSED' : 'ACTIVE'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
