import React, { useState } from 'react';
import { Order } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Receipt, Download, Printer, Search, AlertTriangle } from 'lucide-react';

interface KotReportProps {
  orders: Order[];
  dateFilterText: string;
}

export const KotReport: React.FC<KotReportProps> = ({ orders, dateFilterText }) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Collect KOT stats from all orders
  let totalKotsPrinted = 0;
  let totalKotItemsPrinted = 0;
  let voidedKotItemsCount = 0;

  const orderKotList: {
    orderNumber: number;
    tableName: string;
    kotTokenCount: number;
    kotPrintedAt?: string;
    itemsCount: number;
    voidedItemsCount: number;
    voidReason?: string;
    status: string;
  }[] = [];

  orders.forEach((o) => {
    const kotCount = o.kotTokenCount || (o.items.some((i) => i.kotPrinted) ? 1 : 0);
    const printedItems = o.items.filter((i) => i.kotPrinted).reduce((s, i) => s + i.quantity, 0);
    const voidedItems = o.pendingVoidedKotItems
      ? o.pendingVoidedKotItems.reduce((s, i) => s + i.quantity, 0)
      : 0;

    totalKotsPrinted += kotCount;
    totalKotItemsPrinted += printedItems;
    voidedKotItemsCount += voidedItems;

    if (kotCount > 0 || voidedItems > 0) {
      orderKotList.push({
        orderNumber: o.orderNumber,
        tableName: o.tableName || o.mode.replace('_', ' '),
        kotTokenCount: kotCount,
        kotPrintedAt: o.kotPrintedAt || o.createdAt,
        itemsCount: printedItems,
        voidedItemsCount: voidedItems,
        voidReason: o.voidReason,
        status: o.status,
      });
    }
  });

  const filteredList = orderKotList.filter(
    (k) =>
      k.orderNumber.toString().includes(searchQuery) ||
      k.tableName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleExportCsv = () => {
    const headers = ['Order #', 'Table / Mode', 'KOT Tokens Printed', 'Printed At', 'Items Printed (Qty)', 'Voided KOT Items', 'Void Reason', 'Status'];
    const rows = orderKotList.map((k) => [
      `#${k.orderNumber}`,
      k.tableName,
      k.kotTokenCount,
      k.kotPrintedAt ? new Date(k.kotPrintedAt).toLocaleString() : 'N/A',
      k.itemsCount,
      k.voidedItemsCount,
      k.voidReason || 'N/A',
      k.status.toUpperCase(),
    ]);
    exportToCsv('KOT_Kitchen_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Order #', 'Table', 'Tokens', 'Printed At', 'Items Qty', 'Voided Qty', 'Status'];
    const rows = orderKotList.map((k) => [
      `#${k.orderNumber}`,
      k.tableName,
      k.kotTokenCount,
      k.kotPrintedAt ? new Date(k.kotPrintedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A',
      k.itemsCount,
      k.voidedItemsCount,
      k.status.toUpperCase(),
    ]);
    printReport('Kitchen Order Ticket (KOT) Operational Report', dateFilterText, headers, rows, [
      { label: 'Total KOTs Generated', value: totalKotsPrinted.toString() },
      { label: 'Kitchen Items Printed', value: totalKotItemsPrinted.toString() },
      { label: 'Voided KOT Items', value: voidedKotItemsCount.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-amber-400" />
            KOT & Kitchen Production Report
          </h3>
          <p className="text-xs text-slate-400">Kitchen order token history, voided items tracking, and prep logs</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total KOT Tokens Printed</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{totalKotsPrinted}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total Kitchen Dishes Sent</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">{totalKotItemsPrinted} Items</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Voided / Cancelled KOT Items</div>
          <div className="text-2xl font-black text-rose-400 mt-1">{voidedKotItemsCount} Items</div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Order # or Table..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Order #</th>
              <th className="p-3">Table / Mode</th>
              <th className="p-3 text-center">Tokens Printed</th>
              <th className="p-3">Printed Time</th>
              <th className="p-3 text-center">Items (Qty)</th>
              <th className="p-3 text-center">Voided Qty</th>
              <th className="p-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-6 text-center text-slate-500 font-bold">
                  No KOT records found
                </td>
              </tr>
            ) : (
              filteredList.map((k, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-black text-amber-300">#{k.orderNumber}</td>
                  <td className="p-3 font-bold text-slate-200">{k.tableName}</td>
                  <td className="p-3 text-center font-bold text-slate-100">{k.kotTokenCount}</td>
                  <td className="p-3 text-slate-400">
                    {k.kotPrintedAt ? new Date(k.kotPrintedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A'}
                  </td>
                  <td className="p-3 text-center font-bold text-emerald-400">{k.itemsCount}</td>
                  <td className="p-3 text-center font-bold text-rose-400">
                    {k.voidedItemsCount > 0 ? (
                      <span className="bg-rose-500/20 px-2 py-0.5 rounded text-rose-300 border border-rose-500/30">
                        {k.voidedItemsCount}
                      </span>
                    ) : (
                      '0'
                    )}
                  </td>
                  <td className="p-3 text-center uppercase">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                        k.status === 'settled'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : k.status === 'void'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {k.status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
