import React from 'react';
import { Order, Expense, PurchaseEntry } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { ArrowDownRight, ArrowUpRight, DollarSign, Download, Printer } from 'lucide-react';

interface CashFlowReportProps {
  orders: Order[];
  expenses: Expense[];
  purchaseEntries: PurchaseEntry[];
  dateFilterText: string;
}

export const CashFlowReport: React.FC<CashFlowReportProps> = ({
  orders,
  expenses,
  purchaseEntries,
  dateFilterText,
}) => {
  const settledOrders = orders.filter((o) => o.status === 'settled');

  // Cash Inflows
  const cashSales = settledOrders.reduce((sum, o) => {
    if (o.paymentMode === 'cash') return sum + o.finalTotal;
    if (o.paymentMode === 'split' && o.splitDetails) {
      return sum + o.splitDetails.filter((s) => s.method === 'cash').reduce((s, d) => s + d.amount, 0);
    }
    return sum;
  }, 0);

  const onlineSales = settledOrders.reduce((sum, o) => {
    if (o.paymentMode === 'upi' || o.paymentMode === 'card') return sum + o.finalTotal;
    if (o.paymentMode === 'split' && o.splitDetails) {
      return sum + o.splitDetails.filter((s) => s.method === 'upi' || s.method === 'card').reduce((s, d) => s + d.amount, 0);
    }
    return sum;
  }, 0);

  const customerAdvances = settledOrders.reduce((sum, o) => sum + (o.advanceDeposit || 0), 0);

  const totalInflow = cashSales + onlineSales + customerAdvances;

  // Cash Outflows
  const cashExpenses = expenses.reduce((sum, e) => (e.mode === 'cash' ? sum + e.amount : sum), 0);
  const onlineExpenses = expenses.reduce((sum, e) => (e.mode === 'online' ? sum + e.amount : sum), 0);
  const vendorPayments = purchaseEntries.reduce((sum, p) => sum + p.paidAmount, 0);

  const totalOutflow = cashExpenses + onlineExpenses + vendorPayments;
  const netCashFlow = totalInflow - totalOutflow;

  const handleExportCsv = () => {
    const headers = ['Category', 'Type', 'Amount (₹)', 'Description'];
    const rows = [
      ['Cash Sales Inflow', 'INFLOW', cashSales, 'Direct cash collected at POS'],
      ['Online / UPI Sales Inflow', 'INFLOW', onlineSales, 'QR & Card digital sales'],
      ['Customer Advance Deposits', 'INFLOW', customerAdvances, 'Booking / pre-order deposits'],
      ['Cash Expenses Outflow', 'OUTFLOW', cashExpenses, 'Petty cash & operational expenses'],
      ['Online Expenses Outflow', 'OUTFLOW', onlineExpenses, 'Bank transfer operational expenses'],
      ['Vendor & Purchase Payments', 'OUTFLOW', vendorPayments, 'Raw material & stock in payments'],
      ['NET CASH FLOW', netCashFlow >= 0 ? 'NET GAIN' : 'NET DEFICIT', netCashFlow, 'Total Inflow minus Total Outflow'],
    ];
    exportToCsv('Cash_Flow_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Cash Flow Stream', 'Type', 'Amount (₹)'];
    const rows = [
      ['Cash POS Sales', 'INFLOW', `₹${cashSales}`],
      ['Digital / UPI / Card Sales', 'INFLOW', `₹${onlineSales}`],
      ['Customer Advance Deposits', 'INFLOW', `₹${customerAdvances}`],
      ['Cash Expenses', 'OUTFLOW', `-₹${cashExpenses}`],
      ['Online Expenses', 'OUTFLOW', `-₹${onlineExpenses}`],
      ['Vendor / Purchase Payments', 'OUTFLOW', `-₹${vendorPayments}`],
      ['NET CASH FLOW', netCashFlow >= 0 ? 'SURPLUS' : 'DEFICIT', `₹${netCashFlow}`],
    ];
    printReport('Cash Flow Statement & Capital Liquidity Report', dateFilterText, headers, rows, [
      { label: 'Total Cash Inflow', value: `₹${totalInflow}` },
      { label: 'Total Cash Outflow', value: `₹${totalOutflow}` },
      { label: 'Net Cash Flow Position', value: `₹${netCashFlow}` },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-amber-400" />
            Cash Flow Statement & Liquidity Report
          </h3>
          <p className="text-xs text-slate-400">Track liquid cash inflows vs vendor & operational cash outflows</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/30">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase">
            <ArrowDownRight className="w-4 h-4" />
            <span>Total Inflow</span>
          </div>
          <div className="text-2xl font-black text-emerald-400 mt-1">₹{totalInflow}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Sales + UPI + Advances</div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-rose-500/30">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase">
            <ArrowUpRight className="w-4 h-4" />
            <span>Total Outflow</span>
          </div>
          <div className="text-2xl font-black text-rose-400 mt-1">₹{totalOutflow}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Expenses + Vendor Payments</div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-amber-500/30">
          <div className="text-xs uppercase font-bold text-slate-400">Net Cash Position</div>
          <div className={`text-2xl font-black mt-1 ${netCashFlow >= 0 ? 'text-amber-400' : 'text-rose-400'}`}>
            {netCashFlow >= 0 ? `+₹${netCashFlow}` : `-₹${Math.abs(netCashFlow)}`}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Inflow minus Outflow</div>
        </div>
      </div>

      {/* Cash Flow Breakdown Tables */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Inflow Box */}
        <div className="bg-slate-950 border border-emerald-500/30 rounded-xl p-4 space-y-3">
          <div className="font-extrabold text-sm text-emerald-400 uppercase tracking-wider flex items-center justify-between">
            <span>🟢 Cash Inflows</span>
            <span>₹{totalInflow}</span>
          </div>
          <div className="divide-y divide-slate-850 text-xs">
            <div className="py-2 flex justify-between">
              <span className="text-slate-300 font-semibold">Physical Cash POS Sales</span>
              <span className="font-bold text-emerald-400">₹{cashSales}</span>
            </div>
            <div className="py-2 flex justify-between">
              <span className="text-slate-300 font-semibold">Digital UPI & Card Collections</span>
              <span className="font-bold text-emerald-400">₹{onlineSales}</span>
            </div>
            <div className="py-2 flex justify-between">
              <span className="text-slate-300 font-semibold">Customer Advance Deposits</span>
              <span className="font-bold text-emerald-400">₹{customerAdvances}</span>
            </div>
          </div>
        </div>

        {/* Outflow Box */}
        <div className="bg-slate-950 border border-rose-500/30 rounded-xl p-4 space-y-3">
          <div className="font-extrabold text-sm text-rose-400 uppercase tracking-wider flex items-center justify-between">
            <span>🔴 Cash Outflows</span>
            <span>₹{totalOutflow}</span>
          </div>
          <div className="divide-y divide-slate-850 text-xs">
            <div className="py-2 flex justify-between">
              <span className="text-slate-300 font-semibold">Cash Operational Expenses</span>
              <span className="font-bold text-rose-400">₹{cashExpenses}</span>
            </div>
            <div className="py-2 flex justify-between">
              <span className="text-slate-300 font-semibold">Online Operational Expenses</span>
              <span className="font-bold text-rose-400">₹{onlineExpenses}</span>
            </div>
            <div className="py-2 flex justify-between">
              <span className="text-slate-300 font-semibold">Vendor & Raw Material Payments</span>
              <span className="font-bold text-rose-400">₹{vendorPayments}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
