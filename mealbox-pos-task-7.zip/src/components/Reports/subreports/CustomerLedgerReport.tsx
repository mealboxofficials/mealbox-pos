import React, { useState } from 'react';
import { Customer, Order } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { BookOpen, Download, Printer, Search, Phone } from 'lucide-react';

interface CustomerLedgerReportProps {
  customers: Customer[];
  orders: Order[];
  dateFilterText: string;
}

export const CustomerLedgerReport: React.FC<CustomerLedgerReportProps> = ({
  customers,
  orders,
  dateFilterText,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Customers with outstanding dues or credit balance
  const ledgerCustomers = customers.filter(
    (c) => c.dues > 0 || c.advance > 0 || c.totalOrders > 0
  );

  const filteredList = ledgerCustomers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.mobile.includes(searchQuery)
  );

  const totalDues = customers.reduce((s, c) => s + c.dues, 0);
  const totalAdvances = customers.reduce((s, c) => s + c.advance, 0);

  const handleExportCsv = () => {
    const headers = ['Customer Name', 'Mobile', 'Credit Dues Owed (₹)', 'Advance Deposit Balance (₹)', 'Net Balance Status', 'Total Lifetime Spend (₹)'];
    const rows = filteredList.map((c) => [
      c.name,
      c.mobile,
      c.dues,
      c.advance,
      c.dues > 0 ? `DEBTOR (Owes ₹${c.dues})` : c.advance > 0 ? `CREDITOR (Deposit ₹${c.advance})` : 'SETTLED',
      c.totalSpent,
    ]);
    exportToCsv('Customer_Ledger_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Customer Name', 'Mobile', 'Pending Dues', 'Advance Balance', 'Net Status'];
    const rows = filteredList.map((c) => [
      c.name,
      c.mobile,
      `₹${c.dues}`,
      `₹${c.advance}`,
      c.dues > 0 ? `Owes ₹${c.dues}` : c.advance > 0 ? `Deposit ₹${c.advance}` : 'CLEAR',
    ]);
    printReport('Customer Credit & Ledger Statement', dateFilterText, headers, rows, [
      { label: 'Total Pending Dues Owed to Restaurant', value: `₹${totalDues}` },
      { label: 'Total Customer Advance Balances', value: `₹${totalAdvances}` },
      { label: 'Debtor Accounts', value: customers.filter((c) => c.dues > 0).length.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            Customer Credit & Dues Ledger Report
          </h3>
          <p className="text-xs text-slate-400">Track outstanding customer account balances, credit sales, and deposits</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-500/30">
          <div className="text-[10px] uppercase font-bold text-rose-400">Total Outstanding Customer Dues</div>
          <div className="text-2xl font-black text-rose-400 mt-1">₹{totalDues}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{customers.filter((c) => c.dues > 0).length} debtor accounts</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30">
          <div className="text-[10px] uppercase font-bold text-emerald-400">Total Customer Advance Deposits</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">₹{totalAdvances}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{customers.filter((c) => c.advance > 0).length} creditor accounts</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Net Receivable Cash</div>
          <div className={`text-2xl font-black mt-1 ${totalDues - totalAdvances >= 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            ₹{totalDues - totalAdvances}
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Ledger Name or Mobile..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Customer Name</th>
              <th className="p-3">Contact</th>
              <th className="p-3 text-right">Credit Dues (Receivable)</th>
              <th className="p-3 text-right">Advance Deposit (Payable)</th>
              <th className="p-3 text-center">Account Status</th>
              <th className="p-3 text-right">Total Lifetime Sales</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-6 text-center text-slate-500 font-bold">
                  No customer ledger records found
                </td>
              </tr>
            ) : (
              filteredList.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-extrabold text-slate-100">{c.name}</td>
                  <td className="p-3 text-slate-400 font-semibold">{c.mobile}</td>
                  <td className="p-3 text-right font-black text-rose-400">
                    {c.dues > 0 ? `₹${c.dues}` : '₹0'}
                  </td>
                  <td className="p-3 text-right font-black text-emerald-400">
                    {c.advance > 0 ? `₹${c.advance}` : '₹0'}
                  </td>
                  <td className="p-3 text-center uppercase">
                    {c.dues > 0 ? (
                      <span className="bg-rose-500/20 text-rose-400 font-black px-2.5 py-1 rounded-full border border-rose-500/30 text-[10px]">
                        DEBTOR (DUES)
                      </span>
                    ) : c.advance > 0 ? (
                      <span className="bg-emerald-500/20 text-emerald-400 font-black px-2.5 py-1 rounded-full border border-emerald-500/30 text-[10px]">
                        CREDITOR (ADVANCE)
                      </span>
                    ) : (
                      <span className="bg-slate-800 text-slate-400 font-bold px-2.5 py-1 rounded-full text-[10px]">
                        CLEAR
                      </span>
                    )}
                  </td>
                  <td className="p-3 text-right font-bold text-amber-400">₹{c.totalSpent}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
