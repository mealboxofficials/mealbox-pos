import React, { useState } from 'react';
import { Order, MenuItem } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Tag, Download, Printer, Search, TrendingUp } from 'lucide-react';

interface ItemSalesReportProps {
  orders: Order[];
  menuItems: MenuItem[];
  dateFilterText: string;
}

export const ItemSalesReport: React.FC<ItemSalesReportProps> = ({ orders, menuItems, dateFilterText }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('all');

  const settledOrders = orders.filter((o) => o.status === 'settled' && o.mode !== 'free');

  const itemMap: Record<
    string,
    { nameEn: string; category: string; price: number; qty: number; revenue: number }
  > = {};

  settledOrders.forEach((o) => {
    o.items.forEach((it) => {
      const menuObj = menuItems.find((m) => m.id === it.menuItemId || m.nameEn === it.nameEn);
      const cat = menuObj?.category || 'General';
      const key = it.nameEn;

      if (!itemMap[key]) {
        itemMap[key] = {
          nameEn: it.nameEn,
          category: cat,
          price: it.price,
          qty: 0,
          revenue: 0,
        };
      }
      itemMap[key].qty += it.quantity;
      itemMap[key].revenue += it.price * it.quantity;
    });
  });

  const itemList = Object.values(itemMap).sort((a, b) => b.revenue - a.revenue);
  const totalRevenue = itemList.reduce((s, i) => s + i.revenue, 0);

  const categories = Array.from(new Set(itemList.map((i) => i.category)));

  const filteredList = itemList.filter((i) => {
    const matchesCategory = selectedCategoryFilter === 'all' || i.category === selectedCategoryFilter;
    const matchesSearch = i.nameEn.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleExportCsv = () => {
    const headers = ['Item Name', 'Category', 'Unit Price (₹)', 'Quantity Sold', 'Total Revenue (₹)', 'Contribution %'];
    const rows = itemList.map((i) => [
      i.nameEn,
      i.category,
      i.price,
      i.qty,
      i.revenue,
      totalRevenue > 0 ? ((i.revenue / totalRevenue) * 100).toFixed(1) + '%' : '0%',
    ]);
    exportToCsv('Item_Wise_Sales_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Item Name', 'Category', 'Price', 'Qty Sold', 'Revenue', 'Share %'];
    const rows = itemList.map((i) => [
      i.nameEn,
      i.category,
      `₹${i.price}`,
      i.qty,
      `₹${i.revenue}`,
      totalRevenue > 0 ? `${((i.revenue / totalRevenue) * 100).toFixed(1)}%` : '0%',
    ]);
    printReport('Item-Wise Sales Performance', dateFilterText, headers, rows, [
      { label: 'Total Sales', value: `₹${totalRevenue}` },
      { label: 'Top Selling Item', value: itemList[0]?.nameEn || 'N/A' },
      { label: 'Total Items Sold', value: itemList.reduce((s, i) => s + i.qty, 0).toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Tag className="w-5 h-5 text-amber-400" />
            Item-Wise Sales & Dish Popularity
          </h3>
          <p className="text-xs text-slate-400">Detailed dish movement, unit pricing, and revenue rankings</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search dish name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <select
          value={selectedCategoryFilter}
          onChange={(e) => setSelectedCategoryFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 text-amber-400 text-xs font-bold rounded-xl px-3 py-1.5 focus:outline-none cursor-pointer"
        >
          <option value="all">All Categories</option>
          {categories.map((cat, idx) => (
            <option key={idx} value={cat}>
              {cat}
            </option>
          ))}
        </select>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Rank</th>
              <th className="p-3">Dish Name</th>
              <th className="p-3">Category</th>
              <th className="p-3 text-right">Selling Price</th>
              <th className="p-3 text-center">Qty Sold</th>
              <th className="p-3 text-right">Total Revenue (₹)</th>
              <th className="p-3 text-right">Revenue Share</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-6 text-center text-slate-500 font-bold">
                  No items match the filter criteria
                </td>
              </tr>
            ) : (
              filteredList.map((i, idx) => {
                const share = totalRevenue > 0 ? ((i.revenue / totalRevenue) * 100).toFixed(1) : '0';
                return (
                  <tr key={idx} className="hover:bg-slate-800/50 transition">
                    <td className="p-3 font-black text-slate-500">#{idx + 1}</td>
                    <td className="p-3 font-extrabold text-amber-300">{i.nameEn}</td>
                    <td className="p-3 text-slate-400">{i.category}</td>
                    <td className="p-3 text-right">₹{i.price}</td>
                    <td className="p-3 text-center font-bold text-slate-100">{i.qty}</td>
                    <td className="p-3 text-right font-black text-amber-400">₹{i.revenue}</td>
                    <td className="p-3 text-right text-emerald-400 font-bold">{share}%</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
