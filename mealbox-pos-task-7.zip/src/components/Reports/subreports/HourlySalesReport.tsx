import React from 'react';
import { Order } from '../../../types';
import { HourlyHeatmapGrid } from '../ReportCharts';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Clock, Download, Printer } from 'lucide-react';

interface HourlySalesReportProps {
  orders: Order[];
  dateFilterText: string;
}

export const HourlySalesReport: React.FC<HourlySalesReportProps> = ({ orders, dateFilterText }) => {
  const settledOrders = orders.filter((o) => o.status === 'settled' && o.mode !== 'free');

  // Initialize 24 hours
  const hourlyMap = Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    label: `${i.toString().padStart(2, '0')}:00`,
    orderCount: 0,
    revenue: 0,
  }));

  settledOrders.forEach((o) => {
    const hour = new Date(o.createdAt).getHours();
    if (hourlyMap[hour]) {
      hourlyMap[hour].orderCount += 1;
      hourlyMap[hour].revenue += o.finalTotal;
    }
  });

  const peakHour = [...hourlyMap].sort((a, b) => b.revenue - a.revenue)[0];
  const totalRevenue = hourlyMap.reduce((s, h) => s + h.revenue, 0);

  const handleExportCsv = () => {
    const headers = ['Hour', 'Order Count', 'Total Sales (₹)', 'Contribution %'];
    const rows = hourlyMap.map((h) => [
      h.label,
      h.orderCount,
      h.revenue,
      totalRevenue > 0 ? ((h.revenue / totalRevenue) * 100).toFixed(1) + '%' : '0%',
    ]);
    exportToCsv('Hourly_Sales_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Hour', 'Order Count', 'Revenue', 'Share %'];
    const rows = hourlyMap.map((h) => [
      h.label,
      h.orderCount,
      `₹${h.revenue}`,
      totalRevenue > 0 ? `${((h.revenue / totalRevenue) * 100).toFixed(1)}%` : '0%',
    ]);
    printReport('Hourly Sales Report', dateFilterText, headers, rows, [
      { label: 'Total Revenue', value: `₹${totalRevenue}` },
      { label: 'Peak Hour', value: peakHour ? `${peakHour.label} (₹${peakHour.revenue})` : 'N/A' },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-400" />
            Hourly Sales & Peak Hours Report
          </h3>
          <p className="text-xs text-slate-400">Identify rush hours and order volume patterns throughout the day</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Peak Hour Banner */}
      <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded-xl flex items-center justify-between">
        <div>
          <div className="text-xs font-bold text-amber-400 uppercase">🔥 Peak Sales Hour</div>
          <div className="text-lg font-black text-slate-100 mt-0.5">
            {peakHour?.label} ({peakHour?.orderCount} orders)
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs font-bold text-slate-400">Peak Hour Revenue</div>
          <div className="text-xl font-black text-amber-400">₹{peakHour?.revenue}</div>
        </div>
      </div>

      {/* Hourly Heatmap Grid */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-slate-300">24-Hour Intensity Map</div>
        <HourlyHeatmapGrid hourlyData={hourlyMap} />
      </div>

      {/* Hourly Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Hour Window</th>
              <th className="p-3 text-center">Orders Placed</th>
              <th className="p-3 text-right">Revenue (₹)</th>
              <th className="p-3 text-right">Revenue Share</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {hourlyMap.map((h) => {
              const pct = totalRevenue > 0 ? ((h.revenue / totalRevenue) * 100).toFixed(1) : '0';
              return (
                <tr key={h.hour} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-bold text-slate-200">{h.label} - {h.hour === 23 ? '00:00' : `${(h.hour + 1).toString().padStart(2, '0')}:00`}</td>
                  <td className="p-3 text-center font-bold">{h.orderCount}</td>
                  <td className="p-3 text-right font-black text-amber-400">₹{h.revenue}</td>
                  <td className="p-3 text-right text-slate-400 font-bold">{pct}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
