import React from 'react';
import { Order } from '../../../types';
import { SimpleDonutChart } from '../ReportCharts';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { CreditCard, Download, Printer } from 'lucide-react';

interface PaymentModeReportProps {
  orders: Order[];
  dateFilterText: string;
}

export const PaymentModeReport: React.FC<PaymentModeReportProps> = ({ orders, dateFilterText }) => {
  const settledOrders = orders.filter((o) => o.status === 'settled');

  const modeTotals = {
    cash: 0,
    upi: 0,
    card: 0,
    dues: 0,
  };

  const modeCounts = {
    cash: 0,
    upi: 0,
    card: 0,
    dues: 0,
  };

  settledOrders.forEach((o) => {
    if (o.paymentMode === 'cash') {
      modeTotals.cash += o.finalTotal;
      modeCounts.cash += 1;
    } else if (o.paymentMode === 'upi') {
      modeTotals.upi += o.finalTotal;
      modeCounts.upi += 1;
    } else if (o.paymentMode === 'card') {
      modeTotals.card += o.finalTotal;
      modeCounts.card += 1;
    } else if (o.paymentMode === 'dues' || o.paymentMode === 'credit') {
      modeTotals.dues += o.finalTotal;
      modeCounts.dues += 1;
    } else if (o.paymentMode === 'split' && o.splitDetails) {
      o.splitDetails.forEach((s) => {
        if (s.method === 'cash') {
          modeTotals.cash += s.amount;
          modeCounts.cash += 0.5;
        } else if (s.method === 'upi') {
          modeTotals.upi += s.amount;
          modeCounts.upi += 0.5;
        } else if (s.method === 'card') {
          modeTotals.card += s.amount;
          modeCounts.card += 0.5;
        } else {
          modeTotals.dues += s.amount;
          modeCounts.dues += 0.5;
        }
      });
    }
  });

  const totalSettledRevenue =
    modeTotals.cash + modeTotals.upi + modeTotals.card + modeTotals.dues;

  const donutData = [
    { label: 'Cash', value: modeTotals.cash, color: '#10b981' },
    { label: 'UPI / QR', value: modeTotals.upi, color: '#f59e0b' },
    { label: 'Card / POS', value: modeTotals.card, color: '#06b6d4' },
    { label: 'Credit / Dues', value: modeTotals.dues, color: '#a855f7' },
  ].filter((d) => d.value > 0);

  const handleExportCsv = () => {
    const headers = ['Payment Mode', 'Transactions / Orders', 'Total Collected (₹)', 'Revenue Share %'];
    const rows = [
      ['Cash', modeCounts.cash, modeTotals.cash, totalSettledRevenue > 0 ? ((modeTotals.cash / totalSettledRevenue) * 100).toFixed(1) + '%' : '0%'],
      ['UPI / Digital QR', modeCounts.upi, modeTotals.upi, totalSettledRevenue > 0 ? ((modeTotals.upi / totalSettledRevenue) * 100).toFixed(1) + '%' : '0%'],
      ['Card / Swiping Machine', modeCounts.card, modeTotals.card, totalSettledRevenue > 0 ? ((modeTotals.card / totalSettledRevenue) * 100).toFixed(1) + '%' : '0%'],
      ['Credit / Customer Dues', modeCounts.dues, modeTotals.dues, totalSettledRevenue > 0 ? ((modeTotals.dues / totalSettledRevenue) * 100).toFixed(1) + '%' : '0%'],
    ];
    exportToCsv('Payment_Mode_Breakdown_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Payment Mode', 'Orders', 'Amount Collected', 'Share %'];
    const rows = [
      ['Cash', modeCounts.cash, `₹${modeTotals.cash}`, `${totalSettledRevenue > 0 ? ((modeTotals.cash / totalSettledRevenue) * 100).toFixed(1) : '0'}%`],
      ['UPI / QR', modeCounts.upi, `₹${modeTotals.upi}`, `${totalSettledRevenue > 0 ? ((modeTotals.upi / totalSettledRevenue) * 100).toFixed(1) : '0'}%`],
      ['Card', modeCounts.card, `₹${modeTotals.card}`, `${totalSettledRevenue > 0 ? ((modeTotals.card / totalSettledRevenue) * 100).toFixed(1) : '0'}%`],
      ['Credit / Dues', modeCounts.dues, `₹${modeTotals.dues}`, `${totalSettledRevenue > 0 ? ((modeTotals.dues / totalSettledRevenue) * 100).toFixed(1) : '0'}%`],
    ];
    printReport('Payment Mode Reconciliation Report', dateFilterText, headers, rows, [
      { label: 'Total Revenue Settled', value: `₹${totalSettledRevenue}` },
      { label: 'Cash Share %', value: `${totalSettledRevenue > 0 ? ((modeTotals.cash / totalSettledRevenue) * 100).toFixed(1) : '0'}%` },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-400" />
            Payment Mode & Bank Reconciliation Report
          </h3>
          <p className="text-xs text-slate-400">Complete breakdown of Cash, UPI, Card, and Credit ledger payments</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Donut Visual */}
      {donutData.length > 0 && (
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-850">
          <SimpleDonutChart data={donutData} totalLabel="Settled Revenue" />
        </div>
      )}

      {/* Grid Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/30">
          <div className="text-[10px] uppercase font-bold text-emerald-400">💵 Cash Collections</div>
          <div className="text-xl font-black text-emerald-400 mt-1">₹{modeTotals.cash}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{modeCounts.cash} orders</div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-amber-500/30">
          <div className="text-[10px] uppercase font-bold text-amber-400">📱 UPI / Digital QR</div>
          <div className="text-xl font-black text-amber-400 mt-1">₹{modeTotals.upi}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{modeCounts.upi} orders</div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-sky-500/30">
          <div className="text-[10px] uppercase font-bold text-sky-400">💳 Card POS</div>
          <div className="text-xl font-black text-sky-400 mt-1">₹{modeTotals.card}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{modeCounts.card} orders</div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-purple-500/30">
          <div className="text-[10px] uppercase font-bold text-purple-400">📒 Credit / Dues</div>
          <div className="text-xl font-black text-purple-400 mt-1">₹{modeTotals.dues}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{modeCounts.dues} orders</div>
        </div>
      </div>
    </div>
  );
};
