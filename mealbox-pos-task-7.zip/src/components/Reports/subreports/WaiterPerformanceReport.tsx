import React, { useState } from 'react';
import { Order, Staff } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { User, Download, Printer, Search, Award } from 'lucide-react';

interface WaiterPerformanceReportProps {
  orders: Order[];
  staff: Staff[];
  dateFilterText: string;
}

export const WaiterPerformanceReport: React.FC<WaiterPerformanceReportProps> = ({
  orders,
  staff,
  dateFilterText,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const settledOrders = orders.filter((o) => o.status === 'settled');

  const waiterMap: Record<
    string,
    {
      name: string;
      orderCount: number;
      revenue: number;
      discountsGiven: number;
      itemsServed: number;
    }
  > = {};

  settledOrders.forEach((o) => {
    const waiter = o.waiterName || 'Counter / Unassigned';
    if (!waiterMap[waiter]) {
      waiterMap[waiter] = {
        name: waiter,
        orderCount: 0,
        revenue: 0,
        discountsGiven: 0,
        itemsServed: 0,
      };
    }

    waiterMap[waiter].orderCount += 1;
    waiterMap[waiter].revenue += o.finalTotal;
    waiterMap[waiter].discountsGiven += o.discountAmount || 0;
    waiterMap[waiter].itemsServed += o.items.reduce((s, it) => s + it.quantity, 0);
  });

  const waiterList = Object.values(waiterMap).sort((a, b) => b.revenue - a.revenue);
  const totalRevenue = waiterList.reduce((s, w) => s + w.revenue, 0);

  const filteredList = waiterList.filter((w) =>
    w.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const topWaiter = waiterList[0];

  const handleExportCsv = () => {
    const headers = ['Staff Member', 'Orders Handled', 'Items Served', 'Total Revenue (₹)', 'Discounts Given (₹)', 'Avg Order Value (₹)'];
    const rows = waiterList.map((w) => [
      w.name,
      w.orderCount,
      w.itemsServed,
      w.revenue,
      w.discountsGiven,
      w.orderCount > 0 ? Math.round(w.revenue / w.orderCount) : 0,
    ]);
    exportToCsv('Waiter_Performance_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Staff Member', 'Orders', 'Items', 'Revenue', 'Discounts', 'AOV'];
    const rows = waiterList.map((w) => [
      w.name,
      w.orderCount,
      w.itemsServed,
      `₹${w.revenue}`,
      `₹${w.discountsGiven}`,
      `₹${w.orderCount > 0 ? Math.round(w.revenue / w.orderCount) : 0}`,
    ]);
    printReport('Waiter & Service Staff Performance Report', dateFilterText, headers, rows, [
      { label: 'Top Performer', value: topWaiter?.name || 'N/A' },
      { label: 'Total Revenue Handled', value: `₹${totalRevenue}` },
      { label: 'Active Waiters', value: waiterList.length.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <User className="w-5 h-5 text-amber-400" />
            Waiter & Staff Performance Report
          </h3>
          <p className="text-xs text-slate-400">Track service staff productivity, orders taken, and sales contribution</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Top Performer Highlight */}
      {topWaiter && (
        <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500 text-slate-950 rounded-xl font-black">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-400 uppercase">🏆 Top Service Staff</div>
              <div className="text-lg font-black text-slate-100">{topWaiter.name}</div>
              <div className="text-xs text-slate-400">{topWaiter.orderCount} orders &bull; {topWaiter.itemsServed} items served</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs font-bold text-slate-400">Total Sales Handled</div>
            <div className="text-2xl font-black text-amber-400">₹{topWaiter.revenue}</div>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search staff name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Staff Name</th>
              <th className="p-3 text-center">Orders Handled</th>
              <th className="p-3 text-center">Items Served</th>
              <th className="p-3 text-right">Discounts Applied</th>
              <th className="p-3 text-right">Average Order Size</th>
              <th className="p-3 text-right">Total Revenue (₹)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-6 text-center text-slate-500 font-bold">
                  No waiter performance data found
                </td>
              </tr>
            ) : (
              filteredList.map((w, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-bold text-amber-300">{w.name}</td>
                  <td className="p-3 text-center font-bold">{w.orderCount}</td>
                  <td className="p-3 text-center text-slate-400">{w.itemsServed}</td>
                  <td className="p-3 text-right text-rose-400">₹{w.discountsGiven}</td>
                  <td className="p-3 text-right font-bold text-slate-200">
                    ₹{w.orderCount > 0 ? Math.round(w.revenue / w.orderCount) : 0}
                  </td>
                  <td className="p-3 text-right font-black text-amber-400">₹{w.revenue}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
