import React from 'react';
import { Order } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Receipt, Download, Printer } from 'lucide-react';

interface GstTaxReportProps {
  orders: Order[];
  dateFilterText: string;
}

export const GstTaxReport: React.FC<GstTaxReportProps> = ({ orders, dateFilterText }) => {
  const settledOrders = orders.filter((o) => o.status === 'settled');

  // Calculate 5% GST breakdown (CGST 2.5% + SGST 2.5%)
  let totalGrossBill = 0;
  let totalDiscounts = 0;

  settledOrders.forEach((o) => {
    totalGrossBill += o.subtotal || o.finalTotal;
    totalDiscounts += o.discountAmount || 0;
  });

  const netTaxableAmount = Math.max(0, totalGrossBill - totalDiscounts);
  const cgstAmount = Number((netTaxableAmount * 0.025).toFixed(2));
  const sgstAmount = Number((netTaxableAmount * 0.025).toFixed(2));
  const totalGstTax = Number((cgstAmount + sgstAmount).toFixed(2));

  const grandTotalWithTax = netTaxableAmount + totalGstTax;

  const handleExportCsv = () => {
    const headers = ['Order #', 'Date', 'Gross Bill (₹)', 'Discount (₹)', 'Taxable Amount (₹)', 'CGST (2.5%) (₹)', 'SGST (2.5%) (₹)', 'Total GST (₹)', 'Grand Total (₹)'];
    const rows = settledOrders.map((o) => {
      const gross = o.subtotal || o.finalTotal;
      const disc = o.discountAmount || 0;
      const taxable = Math.max(0, gross - disc);
      const cgst = Number((taxable * 0.025).toFixed(2));
      const sgst = Number((taxable * 0.025).toFixed(2));
      const gst = Number((cgst + sgst).toFixed(2));
      return [
        `#${o.orderNumber}`,
        new Date(o.createdAt).toLocaleDateString(),
        gross,
        disc,
        taxable,
        cgst,
        sgst,
        gst,
        o.finalTotal,
      ];
    });
    exportToCsv('GST_Tax_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Order #', 'Date', 'Taxable Value', 'CGST (2.5%)', 'SGST (2.5%)', 'Total GST', 'Bill Total'];
    const rows = settledOrders.map((o) => {
      const gross = o.subtotal || o.finalTotal;
      const disc = o.discountAmount || 0;
      const taxable = Math.max(0, gross - disc);
      const cgst = Number((taxable * 0.025).toFixed(2));
      const sgst = Number((taxable * 0.025).toFixed(2));
      const gst = Number((cgst + sgst).toFixed(2));
      return [
        `#${o.orderNumber}`,
        new Date(o.createdAt).toLocaleDateString(),
        `₹${taxable}`,
        `₹${cgst}`,
        `₹${sgst}`,
        `₹${gst}`,
        `₹${o.finalTotal}`,
      ];
    });
    printReport('GST & Restaurant Tax Audit Statement', dateFilterText, headers, rows, [
      { label: 'Total Net Taxable Sales', value: `₹${netTaxableAmount.toFixed(2)}` },
      { label: 'Central GST (CGST 2.5%)', value: `₹${cgstAmount.toFixed(2)}` },
      { label: 'State GST (SGST 2.5%)', value: `₹${sgstAmount.toFixed(2)}` },
      { label: 'Total GST Collected', value: `₹${totalGstTax.toFixed(2)}` },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-amber-400" />
            GST & Restaurant Tax Filing Report
          </h3>
          <p className="text-xs text-slate-400">CGST (2.5%) and SGST (2.5%) tax audit trail for accounting & tax returns</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Net Taxable Revenue</div>
          <div className="text-xl font-black text-amber-400 mt-1">₹{netTaxableAmount.toFixed(2)}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">CGST (2.5%)</div>
          <div className="text-xl font-black text-slate-100 mt-1">₹{cgstAmount.toFixed(2)}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">SGST (2.5%)</div>
          <div className="text-xl font-black text-slate-100 mt-1">₹{sgstAmount.toFixed(2)}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-500/30">
          <div className="text-[10px] uppercase font-bold text-amber-400">Total GST Collected</div>
          <div className="text-xl font-black text-emerald-400 mt-1">₹{totalGstTax.toFixed(2)}</div>
        </div>
      </div>

      {/* GST Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Order #</th>
              <th className="p-3">Date</th>
              <th className="p-3 text-right">Gross Subtotal</th>
              <th className="p-3 text-right">Discount</th>
              <th className="p-3 text-right">Net Taxable Amount</th>
              <th className="p-3 text-right">CGST (2.5%)</th>
              <th className="p-3 text-right">SGST (2.5%)</th>
              <th className="p-3 text-right">Total Tax (₹)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {settledOrders.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-6 text-center text-slate-500 font-bold">
                  No tax records found for selected period
                </td>
              </tr>
            ) : (
              settledOrders.map((o) => {
                const gross = o.subtotal || o.finalTotal;
                const disc = o.discountAmount || 0;
                const taxable = Math.max(0, gross - disc);
                const cgst = Number((taxable * 0.025).toFixed(2));
                const sgst = Number((taxable * 0.025).toFixed(2));
                const gst = Number((cgst + sgst).toFixed(2));

                return (
                  <tr key={o.id} className="hover:bg-slate-800/50 transition">
                    <td className="p-3 font-black text-amber-300">#{o.orderNumber}</td>
                    <td className="p-3 text-slate-400">{new Date(o.createdAt).toLocaleDateString()}</td>
                    <td className="p-3 text-right font-bold text-slate-200">₹{gross}</td>
                    <td className="p-3 text-right text-rose-400">-₹{disc}</td>
                    <td className="p-3 text-right font-black text-amber-400">₹{taxable}</td>
                    <td className="p-3 text-right text-slate-300">₹{cgst}</td>
                    <td className="p-3 text-right text-slate-300">₹{sgst}</td>
                    <td className="p-3 text-right font-black text-emerald-400">₹{gst}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
