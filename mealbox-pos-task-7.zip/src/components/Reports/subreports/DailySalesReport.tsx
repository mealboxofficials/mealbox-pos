import React, { useState } from 'react';
import { Order } from '../../../types';
import { SimpleBarChart } from '../ReportCharts';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Calendar, Search, Download, Printer, TrendingUp, DollarSign } from 'lucide-react';

interface DailySalesReportProps {
  orders: Order[];
  dateFilterText: string;
}

export const DailySalesReport: React.FC<DailySalesReportProps> = ({ orders, dateFilterText }) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Group settled paid orders by date YYYY-MM-DD
  const settledOrders = orders.filter((o) => o.status === 'settled' && o.mode !== 'free');

  const dailyMap: Record<
    string,
    {
      date: string;
      orderCount: number;
      subtotal: number;
      discount: number;
      tax: number;
      netTotal: number;
      cash: number;
      online: number;
      due: number;
    }
  > = {};

  settledOrders.forEach((o) => {
    const dateStr = new Date(o.createdAt).toISOString().slice(0, 10);
    if (!dailyMap[dateStr]) {
      dailyMap[dateStr] = {
        date: dateStr,
        orderCount: 0,
        subtotal: 0,
        discount: 0,
        tax: 0,
        netTotal: 0,
        cash: 0,
        online: 0,
        due: 0,
      };
    }

    const row = dailyMap[dateStr];
    row.orderCount += 1;
    row.subtotal += o.subtotal || 0;
    row.discount += o.discountAmount || 0;
    row.tax += (o.finalTotal - o.subtotal + o.discountAmount) > 0 ? Number((o.finalTotal * 0.05).toFixed(2)) : 0; // Estimated 5% GST
    row.netTotal += o.finalTotal;

    if (o.paymentMode === 'cash') row.cash += o.finalTotal;
    else if (o.paymentMode === 'upi' || o.paymentMode === 'card') row.online += o.finalTotal;
    else if (o.paymentMode === 'dues' || o.paymentMode === 'credit') row.due += o.finalTotal;
    else if (o.paymentMode === 'split' && o.splitDetails) {
      o.splitDetails.forEach((s) => {
        if (s.method === 'cash') row.cash += s.amount;
        else if (s.method === 'upi' || s.method === 'card') row.online += s.amount;
        else row.due += s.amount;
      });
    }
  });

  const dailyList = Object.values(dailyMap).sort((a, b) => b.date.localeCompare(a.date));

  const filteredList = dailyList.filter((d) => d.date.includes(searchQuery.trim()));

  const totalSales = dailyList.reduce((sum, d) => sum + d.netTotal, 0);
  const totalOrders = dailyList.reduce((sum, d) => sum + d.orderCount, 0);
  const avgOrderVal = totalOrders > 0 ? Math.round(totalSales / totalOrders) : 0;

  // Chart data
  const chartData = dailyList.slice(0, 14).reverse().map((d) => ({
    label: d.date.slice(5),
    value: d.netTotal,
  }));

  const handleExportCsv = () => {
    const headers = ['Date', 'Orders', 'Subtotal (₹)', 'Discount (₹)', 'Net Total (₹)', 'Cash (₹)', 'Online (₹)', 'Credit (₹)', 'AOV (₹)'];
    const rows = dailyList.map((d) => [
      d.date,
      d.orderCount,
      d.subtotal,
      d.discount,
      d.netTotal,
      d.cash,
      d.online,
      d.due,
      d.orderCount > 0 ? Math.round(d.netTotal / d.orderCount) : 0,
    ]);
    exportToCsv('Daily_Sales_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Date', 'Orders', 'Subtotal', 'Discount', 'Net Total', 'Cash', 'Online', 'Credit'];
    const rows = dailyList.map((d) => [
      d.date,
      d.orderCount,
      `₹${d.subtotal}`,
      `₹${d.discount}`,
      `₹${d.netTotal}`,
      `₹${d.cash}`,
      `₹${d.online}`,
      `₹${d.due}`,
    ]);
    printReport('Daily Sales Report', dateFilterText, headers, rows, [
      { label: 'Total Sales', value: `₹${totalSales}` },
      { label: 'Total Orders', value: totalOrders.toString() },
      { label: 'Avg Order Value', value: `₹${avgOrderVal}` },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400" />
            Daily Sales Report
          </h3>
          <p className="text-xs text-slate-400">Day-by-day revenue, volume, and payment mode breakdown</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total Net Sales</div>
          <div className="text-xl font-black text-amber-400 mt-1">₹{totalSales}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total Orders</div>
          <div className="text-xl font-black text-slate-100 mt-1">{totalOrders}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Avg Order Value</div>
          <div className="text-xl font-black text-emerald-400 mt-1">₹{avgOrderVal}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Days Logged</div>
          <div className="text-xl font-black text-sky-400 mt-1">{dailyList.length} Days</div>
        </div>
      </div>

      {/* Daily Sales Chart */}
      {chartData.length > 0 && (
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-2">
          <div className="text-xs font-bold text-slate-300">Daily Sales Trend</div>
          <SimpleBarChart data={chartData} height={160} />
        </div>
      )}

      {/* Filter / Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Date (YYYY-MM-DD)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Date</th>
              <th className="p-3 text-center">Orders</th>
              <th className="p-3 text-right">Subtotal</th>
              <th className="p-3 text-right">Discounts</th>
              <th className="p-3 text-right">Net Sales</th>
              <th className="p-3 text-right">Cash</th>
              <th className="p-3 text-right">Online</th>
              <th className="p-3 text-right">Credit</th>
              <th className="p-3 text-right">AOV</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={9} className="p-6 text-center text-slate-500 font-bold">
                  No sales data found
                </td>
              </tr>
            ) : (
              filteredList.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-bold text-amber-300">{row.date}</td>
                  <td className="p-3 text-center font-bold">{row.orderCount}</td>
                  <td className="p-3 text-right">₹{row.subtotal}</td>
                  <td className="p-3 text-right text-rose-400">-₹{row.discount}</td>
                  <td className="p-3 text-right font-black text-amber-400">₹{row.netTotal}</td>
                  <td className="p-3 text-right text-emerald-400">₹{row.cash}</td>
                  <td className="p-3 text-right text-sky-400">₹{row.online}</td>
                  <td className="p-3 text-right text-purple-400">₹{row.due}</td>
                  <td className="p-3 text-right font-bold">
                    ₹{row.orderCount > 0 ? Math.round(row.netTotal / row.orderCount) : 0}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
