import React, { useState } from 'react';
import { RawMaterial, Recipe, Order } from '../../../types';
import { convertUnitQuantity } from '../../../utils/inventoryEngine';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { PackageCheck, Download, Printer, Search } from 'lucide-react';

interface InventoryConsumptionReportProps {
  rawMaterials: RawMaterial[];
  recipes: Recipe[];
  orders: Order[];
  dateFilterText: string;
}

export const InventoryConsumptionReport: React.FC<InventoryConsumptionReportProps> = ({
  rawMaterials,
  recipes,
  orders,
  dateFilterText,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const settledOrders = orders.filter((o) => o.status === 'settled');

  // Build recipe map
  const recipeMap: Record<string, Recipe> = {};
  recipes.forEach((r) => {
    recipeMap[r.menuItemId] = r;
  });

  const rawMatMap: Record<string, RawMaterial> = {};
  rawMaterials.forEach((m) => {
    rawMatMap[m.id] = m;
  });

  // Calculate consumed raw materials
  const consumptionMap: Record<
    string,
    {
      id: string;
      name: string;
      unit: string;
      unitCost: number;
      consumedQty: number;
      estimatedCost: number;
    }
  > = {};

  settledOrders.forEach((o) => {
    o.items.forEach((it) => {
      const rec = recipeMap[it.menuItemId || ''];
      if (rec && rec.ingredients) {
        rec.ingredients.forEach((ing) => {
          const mat = rawMatMap[ing.rawMaterialId];
          if (mat) {
            if (!consumptionMap[mat.id]) {
              consumptionMap[mat.id] = {
                id: mat.id,
                name: mat.name,
                unit: mat.unit,
                unitCost: mat.unitCostPrice,
                consumedQty: 0,
                estimatedCost: 0,
              };
            }

            const qtyInMatUnit = convertUnitQuantity(ing.quantity, ing.unit, mat.unit);
            const totalQty = qtyInMatUnit * it.quantity;
            consumptionMap[mat.id].consumedQty += totalQty;
            consumptionMap[mat.id].estimatedCost += totalQty * mat.unitCostPrice;
          }
        });
      }
    });
  });

  const consumptionList = Object.values(consumptionMap).sort(
    (a, b) => b.estimatedCost - a.estimatedCost
  );

  const totalConsumptionCost = consumptionList.reduce((s, c) => s + c.estimatedCost, 0);

  const filteredList = consumptionList.filter((c) =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleExportCsv = () => {
    const headers = ['Raw Material Name', 'Unit', 'Unit Cost (₹)', 'Consumed Quantity', 'Total Consumption Value (₹)'];
    const rows = consumptionList.map((c) => [
      c.name,
      c.unit,
      c.unitCost,
      c.consumedQty.toFixed(2),
      c.estimatedCost.toFixed(2),
    ]);
    exportToCsv('Inventory_Consumption_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Raw Material', 'Unit', 'Unit Price', 'Quantity Consumed', 'Total Value'];
    const rows = consumptionList.map((c) => [
      c.name,
      c.unit,
      `₹${c.unitCost}`,
      c.consumedQty.toFixed(2),
      `₹${c.estimatedCost.toFixed(2)}`,
    ]);
    printReport('Inventory & Ingredient Consumption Report', dateFilterText, headers, rows, [
      { label: 'Total Ingredient Cost Used', value: `₹${totalConsumptionCost.toFixed(2)}` },
      { label: 'Raw Materials Consumed', value: consumptionList.length.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <PackageCheck className="w-5 h-5 text-amber-400" />
            Inventory & Ingredient Consumption Report
          </h3>
          <p className="text-xs text-slate-400">Track raw materials consumed by kitchen prep and POS orders based on dish recipes</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Total Metric Card */}
      <div className="bg-slate-950 p-4 rounded-xl border border-amber-500/30 flex justify-between items-center">
        <div>
          <div className="text-xs font-bold text-amber-400 uppercase">Total Consumption Raw Material Value</div>
          <div className="text-2xl font-black text-slate-100 mt-0.5">₹{totalConsumptionCost.toFixed(2)}</div>
        </div>
        <div className="text-right">
          <div className="text-xs font-bold text-slate-400">Distinct Ingredients Used</div>
          <div className="text-xl font-black text-amber-400">{consumptionList.length}</div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Raw Material..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Raw Material</th>
              <th className="p-3 text-center">Unit</th>
              <th className="p-3 text-right">Cost Price / Unit</th>
              <th className="p-3 text-center">Quantity Consumed</th>
              <th className="p-3 text-right">Total Usage Value (₹)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-6 text-center text-slate-500 font-bold">
                  No inventory consumption logged for selected period
                </td>
              </tr>
            ) : (
              filteredList.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-extrabold text-amber-300">{c.name}</td>
                  <td className="p-3 text-center text-slate-400 font-bold">{c.unit}</td>
                  <td className="p-3 text-right text-slate-300">₹{c.unitCost}</td>
                  <td className="p-3 text-center font-black text-slate-100">{c.consumedQty.toFixed(2)} {c.unit}</td>
                  <td className="p-3 text-right font-black text-amber-400">₹{c.estimatedCost.toFixed(2)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
