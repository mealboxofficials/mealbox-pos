import React, { useState } from 'react';
import { Customer, Order } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { UserCheck, Download, Printer, Search, Phone } from 'lucide-react';

interface CustomerReportProps {
  customers: Customer[];
  orders: Order[];
  dateFilterText: string;
}

export const CustomerReport: React.FC<CustomerReportProps> = ({ customers, orders, dateFilterText }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredList = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.mobile.includes(searchQuery)
  );

  const sortedList = [...filteredList].sort((a, b) => b.totalSpent - a.totalSpent);

  const totalSpentAll = customers.reduce((s, c) => s + c.totalSpent, 0);
  const totalOrdersAll = customers.reduce((s, c) => s + c.totalOrders, 0);

  const handleExportCsv = () => {
    const headers = ['Customer Name', 'Mobile', 'Total Visits / Orders', 'Total Spent (₹)', 'Pending Dues (₹)', 'Advance Balance (₹)', 'Last Visit'];
    const rows = sortedList.map((c) => [
      c.name,
      c.mobile,
      c.totalOrders,
      c.totalSpent,
      c.dues,
      c.advance,
      c.lastVisit ? new Date(c.lastVisit).toLocaleDateString() : 'N/A',
    ]);
    exportToCsv('Customer_CRM_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Customer Name', 'Mobile', 'Orders', 'Total Spent', 'Pending Dues', 'Last Visit'];
    const rows = sortedList.map((c) => [
      c.name,
      c.mobile,
      c.totalOrders,
      `₹${c.totalSpent}`,
      `₹${c.dues}`,
      c.lastVisit ? new Date(c.lastVisit).toLocaleDateString() : 'N/A',
    ]);
    printReport('Customer CRM & Spender Analytics', dateFilterText, headers, rows, [
      { label: 'Registered Customers', value: customers.length.toString() },
      { label: 'Total Customer Spend', value: `₹${totalSpentAll}` },
      { label: 'Total CRM Orders', value: totalOrdersAll.toString() },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-amber-400" />
            Customer Analytics & Spender Rankings
          </h3>
          <p className="text-xs text-slate-400">High-value customer insights, visit frequencies, and total revenue</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total Registered Customers</div>
          <div className="text-xl font-black text-amber-400 mt-1">{customers.length}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total Customer Revenue</div>
          <div className="text-xl font-black text-emerald-400 mt-1">₹{totalSpentAll}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total CRM Orders</div>
          <div className="text-xl font-black text-sky-400 mt-1">{totalOrdersAll}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Average Spend / Customer</div>
          <div className="text-xl font-black text-purple-400 mt-1">
            ₹{customers.length > 0 ? Math.round(totalSpentAll / customers.length) : 0}
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Customer Name or Mobile..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Rank</th>
              <th className="p-3">Customer Name</th>
              <th className="p-3">Mobile</th>
              <th className="p-3 text-center">Total Visits</th>
              <th className="p-3 text-right">Credit Dues</th>
              <th className="p-3 text-right">Advance Balance</th>
              <th className="p-3 text-right">Total Spent (₹)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {sortedList.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-6 text-center text-slate-500 font-bold">
                  No customers found matching the search query
                </td>
              </tr>
            ) : (
              sortedList.map((c, idx) => (
                <tr key={c.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-black text-slate-500">#{idx + 1}</td>
                  <td className="p-3 font-extrabold text-amber-300">{c.name}</td>
                  <td className="p-3 font-semibold text-slate-300 flex items-center gap-1">
                    <Phone className="w-3 h-3 text-slate-500" />
                    {c.mobile}
                  </td>
                  <td className="p-3 text-center font-bold text-slate-100">{c.totalOrders}</td>
                  <td className="p-3 text-right font-bold text-rose-400">
                    {c.dues > 0 ? `₹${c.dues}` : '₹0'}
                  </td>
                  <td className="p-3 text-right font-bold text-emerald-400">
                    {c.advance > 0 ? `₹${c.advance}` : '₹0'}
                  </td>
                  <td className="p-3 text-right font-black text-amber-400">₹{c.totalSpent}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
