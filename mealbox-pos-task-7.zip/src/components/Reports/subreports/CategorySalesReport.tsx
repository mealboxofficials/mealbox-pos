import React, { useState } from 'react';
import { Order, MenuItem } from '../../../types';
import { SimpleDonutChart, SimpleBarChart } from '../ReportCharts';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Utensils, Download, Printer, Search } from 'lucide-react';

interface CategorySalesReportProps {
  orders: Order[];
  menuItems: MenuItem[];
  dateFilterText: string;
}

export const CategorySalesReport: React.FC<CategorySalesReportProps> = ({ orders, menuItems, dateFilterText }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const settledOrders = orders.filter((o) => o.status === 'settled' && o.mode !== 'free');

  // Build item to category map
  const itemCategoryMap: Record<string, string> = {};
  menuItems.forEach((m) => {
    itemCategoryMap[m.id] = m.category || 'Uncategorized';
    itemCategoryMap[m.nameEn] = m.category || 'Uncategorized';
  });

  const categoryMap: Record<
    string,
    { category: string; qty: number; revenue: number; itemsCount: Set<string> }
  > = {};

  settledOrders.forEach((o) => {
    o.items.forEach((it) => {
      const cat = itemCategoryMap[it.menuItemId || ''] || itemCategoryMap[it.nameEn] || 'General Food';
      if (!categoryMap[cat]) {
        categoryMap[cat] = { category: cat, qty: 0, revenue: 0, itemsCount: new Set() };
      }
      categoryMap[cat].qty += it.quantity;
      categoryMap[cat].revenue += it.price * it.quantity;
      categoryMap[cat].itemsCount.add(it.nameEn);
    });
  });

  const categoryList = Object.values(categoryMap).sort((a, b) => b.revenue - a.revenue);
  const totalRevenue = categoryList.reduce((s, c) => s + c.revenue, 0);

  const filteredList = categoryList.filter((c) =>
    c.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const chartColors = ['#f59e0b', '#10b981', '#06b6d4', '#8b5cf6', '#ec4899', '#f97316', '#64748b'];

  const donutData = categoryList.slice(0, 6).map((c, idx) => ({
    label: c.category,
    value: c.revenue,
    color: chartColors[idx % chartColors.length],
  }));

  const handleExportCsv = () => {
    const headers = ['Category', 'Dishes Sold (Qty)', 'Unique Dishes', 'Revenue (₹)', 'Sales Share %'];
    const rows = categoryList.map((c) => [
      c.category,
      c.qty,
      c.itemsCount.size,
      c.revenue,
      totalRevenue > 0 ? ((c.revenue / totalRevenue) * 100).toFixed(1) + '%' : '0%',
    ]);
    exportToCsv('Category_Sales_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Category', 'Qty Sold', 'Dishes Count', 'Revenue', 'Share %'];
    const rows = categoryList.map((c) => [
      c.category,
      c.qty,
      c.itemsCount.size,
      `₹${c.revenue}`,
      totalRevenue > 0 ? `${((c.revenue / totalRevenue) * 100).toFixed(1)}%` : '0%',
    ]);
    printReport('Category-Wise Sales Report', dateFilterText, headers, rows, [
      { label: 'Total Category Revenue', value: `₹${totalRevenue}` },
      { label: 'Top Category', value: categoryList[0]?.category || 'N/A' },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Utensils className="w-5 h-5 text-amber-400" />
            Category-Wise Sales Report
          </h3>
          <p className="text-xs text-slate-400">Revenue and volume distribution across food & beverage categories</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Donut Chart Visual */}
      {donutData.length > 0 && (
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-850">
          <SimpleDonutChart data={donutData} totalLabel="Category Sales" />
        </div>
      )}

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Category</th>
              <th className="p-3 text-center">Items Sold (Qty)</th>
              <th className="p-3 text-center">Unique Dishes</th>
              <th className="p-3 text-right">Revenue (₹)</th>
              <th className="p-3 text-right">Revenue Share</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-6 text-center text-slate-500 font-bold">
                  No category data found
                </td>
              </tr>
            ) : (
              filteredList.map((c, idx) => {
                const share = totalRevenue > 0 ? ((c.revenue / totalRevenue) * 100).toFixed(1) : '0';
                return (
                  <tr key={idx} className="hover:bg-slate-800/50 transition">
                    <td className="p-3 font-bold text-amber-300">{c.category}</td>
                    <td className="p-3 text-center font-bold">{c.qty}</td>
                    <td className="p-3 text-center text-slate-400">{c.itemsCount.size}</td>
                    <td className="p-3 text-right font-black text-amber-400">₹{c.revenue}</td>
                    <td className="p-3 text-right text-emerald-400 font-bold">{share}%</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
