import React, { useState } from 'react';
import { PurchaseEntry, Supplier } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { ShoppingCart, Download, Printer, Search } from 'lucide-react';

interface PurchaseReportProps {
  purchaseEntries: PurchaseEntry[];
  suppliers: Supplier[];
  dateFilterText: string;
}

export const PurchaseReport: React.FC<PurchaseReportProps> = ({
  purchaseEntries,
  suppliers,
  dateFilterText,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredList = purchaseEntries.filter(
    (p) =>
      p.purchaseNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.supplierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.invoiceNumber && p.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const totalPurchaseValue = purchaseEntries.reduce((s, p) => s + p.totalAmount, 0);
  const totalPaid = purchaseEntries.reduce((s, p) => s + p.paidAmount, 0);
  const totalDue = purchaseEntries.reduce((s, p) => s + (p.balanceDue || 0), 0);

  const handleExportCsv = () => {
    const headers = ['Purchase #', 'Supplier Name', 'Invoice #', 'Date', 'Items Count', 'Total Amount (₹)', 'Paid Amount (₹)', 'Balance Due (₹)', 'Payment Mode'];
    const rows = filteredList.map((p) => [
      p.purchaseNumber,
      p.supplierName,
      p.invoiceNumber || 'N/A',
      p.date,
      p.items.length,
      p.totalAmount,
      p.paidAmount,
      p.balanceDue || 0,
      p.paymentMode.toUpperCase(),
    ]);
    exportToCsv('Purchase_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Purchase #', 'Supplier Name', 'Date', 'Total Amount', 'Paid', 'Balance Due', 'Payment Mode'];
    const rows = filteredList.map((p) => [
      p.purchaseNumber,
      p.supplierName,
      p.date,
      `₹${p.totalAmount}`,
      `₹${p.paidAmount}`,
      `₹${p.balanceDue || 0}`,
      p.paymentMode.toUpperCase(),
    ]);
    printReport('Supplier Purchase Invoices & Stock In Report', dateFilterText, headers, rows, [
      { label: 'Total Purchases', value: `₹${totalPurchaseValue}` },
      { label: 'Total Paid to Vendors', value: `₹${totalPaid}` },
      { label: 'Total Outstanding Vendor Dues', value: `₹${totalDue}` },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-400" />
            Supplier Purchase Invoices & Stock In Report
          </h3>
          <p className="text-xs text-slate-400">Track raw material purchases, supplier invoices, payments, and credit balances</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Total Purchase Value</div>
          <div className="text-2xl font-black text-amber-400 mt-1">₹{totalPurchaseValue}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30">
          <div className="text-[10px] uppercase font-bold text-emerald-400">Total Paid Amount</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">₹{totalPaid}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-500/30">
          <div className="text-[10px] uppercase font-bold text-rose-400">Total Balance Owed to Vendors</div>
          <div className="text-2xl font-black text-rose-400 mt-1">₹{totalDue}</div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Purchase # or Supplier..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Purchase #</th>
              <th className="p-3">Supplier Name</th>
              <th className="p-3">Invoice #</th>
              <th className="p-3">Date</th>
              <th className="p-3 text-right">Total Amount</th>
              <th className="p-3 text-right">Paid Amount</th>
              <th className="p-3 text-right">Balance Due</th>
              <th className="p-3 text-center">Payment Mode</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-6 text-center text-slate-500 font-bold">
                  No purchase records found
                </td>
              </tr>
            ) : (
              filteredList.map((p) => (
                <tr key={p.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-extrabold text-amber-300">{p.purchaseNumber}</td>
                  <td className="p-3 font-bold text-slate-100">{p.supplierName}</td>
                  <td className="p-3 text-slate-400">{p.invoiceNumber || 'N/A'}</td>
                  <td className="p-3 text-slate-300">{p.date}</td>
                  <td className="p-3 text-right font-black text-slate-100">₹{p.totalAmount}</td>
                  <td className="p-3 text-right font-bold text-emerald-400">₹{p.paidAmount}</td>
                  <td className="p-3 text-right font-bold text-rose-400">
                    {p.balanceDue && p.balanceDue > 0 ? `₹${p.balanceDue}` : '₹0'}
                  </td>
                  <td className="p-3 text-center uppercase">
                    <span className="bg-slate-800 text-amber-300 px-2 py-0.5 rounded text-[10px] font-black border border-slate-700">
                      {p.paymentMode}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
