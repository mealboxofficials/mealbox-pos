import React, { useState } from 'react';
import { Supplier, PurchaseEntry } from '../../../types';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { Building2, Download, Printer, Search, Phone } from 'lucide-react';

interface SupplierLedgerReportProps {
  suppliers: Supplier[];
  purchaseEntries: PurchaseEntry[];
  dateFilterText: string;
}

export const SupplierLedgerReport: React.FC<SupplierLedgerReportProps> = ({
  suppliers,
  purchaseEntries,
  dateFilterText,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const supplierMap: Record<
    string,
    {
      id: string;
      name: string;
      contact: string;
      mobile: string;
      totalInvoices: number;
      totalBilled: number;
      totalPaid: number;
      balanceDue: number;
    }
  > = {};

  suppliers.forEach((s) => {
    supplierMap[s.id] = {
      id: s.id,
      name: s.name,
      contact: s.contactPerson || s.name,
      mobile: s.mobile || s.phone || '',
      totalInvoices: 0,
      totalBilled: 0,
      totalPaid: 0,
      balanceDue: s.balanceDue || 0,
    };
  });

  purchaseEntries.forEach((p) => {
    if (supplierMap[p.supplierId]) {
      supplierMap[p.supplierId].totalInvoices += 1;
      supplierMap[p.supplierId].totalBilled += p.totalAmount;
      supplierMap[p.supplierId].totalPaid += p.paidAmount;
    }
  });

  const supplierList = Object.values(supplierMap).sort((a, b) => b.balanceDue - a.balanceDue);

  const filteredList = supplierList.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.mobile.includes(searchQuery)
  );

  const totalOutstandingDue = supplierList.reduce((sum, s) => sum + s.balanceDue, 0);

  const handleExportCsv = () => {
    const headers = ['Supplier Name', 'Contact Person', 'Mobile', 'Invoices Count', 'Total Billed (₹)', 'Total Paid (₹)', 'Balance Due Owed (₹)'];
    const rows = supplierList.map((s) => [
      s.name,
      s.contact,
      s.mobile,
      s.totalInvoices,
      s.totalBilled,
      s.totalPaid,
      s.balanceDue,
    ]);
    exportToCsv('Supplier_Ledger_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Supplier Name', 'Mobile', 'Invoices', 'Billed', 'Paid', 'Balance Due'];
    const rows = supplierList.map((s) => [
      s.name,
      s.mobile,
      s.totalInvoices,
      `₹${s.totalBilled}`,
      `₹${s.totalPaid}`,
      `₹${s.balanceDue}`,
    ]);
    printReport('Supplier Vendor Account Statement & Ledger Report', dateFilterText, headers, rows, [
      { label: 'Total Vendor Accounts', value: suppliers.length.toString() },
      { label: 'Total Vendor Balance Owed', value: `₹${totalOutstandingDue}` },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-400" />
            Supplier & Vendor Account Ledger Report
          </h3>
          <p className="text-xs text-slate-400">Statement of vendor credit balances, total invoices, and outstanding payables</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Registered Suppliers</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{suppliers.length}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30">
          <div className="text-[10px] uppercase font-bold text-emerald-400">Total Purchase Volume</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">
            ₹{supplierList.reduce((s, x) => s + x.totalBilled, 0)}
          </div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-500/30">
          <div className="text-[10px] uppercase font-bold text-rose-400">Total Vendor Outstanding Payable</div>
          <div className="text-2xl font-black text-rose-400 mt-1">₹{totalOutstandingDue}</div>
        </div>
      </div>

      {/* Search */}
      <div className="flex justify-between items-center">
        <div className="relative w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Supplier Name or Mobile..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase border-b border-slate-800">
            <tr>
              <th className="p-3">Supplier Name</th>
              <th className="p-3">Contact Person</th>
              <th className="p-3 font-semibold">Mobile</th>
              <th className="p-3 text-center">Invoices Logged</th>
              <th className="p-3 text-right">Total Billed</th>
              <th className="p-3 text-right">Total Paid</th>
              <th className="p-3 text-right">Balance Due (Owed)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850 text-slate-200 font-medium">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-6 text-center text-slate-500 font-bold">
                  No supplier ledger records found
                </td>
              </tr>
            ) : (
              filteredList.map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/50 transition">
                  <td className="p-3 font-extrabold text-amber-300">{s.name}</td>
                  <td className="p-3 text-slate-300">{s.contact}</td>
                  <td className="p-3 text-slate-400 font-semibold">{s.mobile}</td>
                  <td className="p-3 text-center font-bold text-slate-100">{s.totalInvoices}</td>
                  <td className="p-3 text-right font-bold text-slate-100">₹{s.totalBilled}</td>
                  <td className="p-3 text-right font-bold text-emerald-400">₹{s.totalPaid}</td>
                  <td className="p-3 text-right font-black text-rose-400">
                    {s.balanceDue > 0 ? `₹${s.balanceDue}` : '₹0'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
