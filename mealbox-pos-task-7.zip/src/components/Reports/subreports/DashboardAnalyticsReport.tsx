import React from 'react';
import { Order, Expense, MenuItem, Recipe, RawMaterial, Staff } from '../../../types';
import { SimpleBarChart, SimpleDonutChart, HourlyHeatmapGrid } from '../ReportCharts';
import { LayoutDashboard, TrendingUp, DollarSign, Utensils, Users, ShoppingBag, Clock, Tag } from 'lucide-react';

interface DashboardAnalyticsReportProps {
  orders: Order[];
  expenses: Expense[];
  menuItems: MenuItem[];
  recipes: Recipe[];
  rawMaterials: RawMaterial[];
  staff: Staff[];
  dateFilterText: string;
  onSelectTab: (tabId: string) => void;
}

export const DashboardAnalyticsReport: React.FC<DashboardAnalyticsReportProps> = ({
  orders,
  expenses,
  menuItems,
  recipes,
  rawMaterials,
  staff,
  dateFilterText,
  onSelectTab,
}) => {
  const settledOrders = orders.filter((o) => o.status === 'settled' && o.mode !== 'free');

  const totalSales = settledOrders.reduce((sum, o) => sum + o.finalTotal, 0);
  const totalOrders = settledOrders.length;
  const avgOrderValue = totalOrders > 0 ? Math.round(totalSales / totalOrders) : 0;

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

  // Hourly Map
  const hourlyMap = Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    label: `${i.toString().padStart(2, '0')}:00`,
    orderCount: 0,
    revenue: 0,
  }));

  settledOrders.forEach((o) => {
    const hr = new Date(o.createdAt).getHours();
    if (hourlyMap[hr]) {
      hourlyMap[hr].orderCount += 1;
      hourlyMap[hr].revenue += o.finalTotal;
    }
  });

  // Category breakdown
  const categoryMap: Record<string, number> = {};
  settledOrders.forEach((o) => {
    o.items.forEach((it) => {
      const cat = it.category || 'Food';
      categoryMap[cat] = (categoryMap[cat] || 0) + it.price * it.quantity;
    });
  });

  const chartColors = ['#f59e0b', '#10b981', '#06b6d4', '#8b5cf6', '#ec4899', '#f97316'];
  const categoryDonutData = Object.entries(categoryMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([cat, val], idx) => ({
      label: cat,
      value: val,
      color: chartColors[idx % chartColors.length],
    }));

  // Order Modes breakdown
  const modeCounts: Record<string, number> = { dine_in: 0, takeaway: 0, delivery: 0 };
  settledOrders.forEach((o) => {
    if (modeCounts[o.mode] !== undefined) modeCounts[o.mode] += 1;
  });

  // Top Items
  const itemMap: Record<string, { name: string; qty: number; revenue: number }> = {};
  settledOrders.forEach((o) => {
    o.items.forEach((it) => {
      if (!itemMap[it.nameEn]) itemMap[it.nameEn] = { name: it.nameEn, qty: 0, revenue: 0 };
      itemMap[it.nameEn].qty += it.quantity;
      itemMap[it.nameEn].revenue += it.price * it.quantity;
    });
  });

  const topItems = Object.values(itemMap).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div
          onClick={() => onSelectTab('daily_sales')}
          className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-4 rounded-2xl cursor-pointer transition"
        >
          <div className="flex justify-between items-center text-slate-400 text-xs font-bold uppercase">
            <span>Total Sales Revenue</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 mt-2">₹{totalSales}</div>
          <div className="text-[10px] text-slate-400 mt-1">{totalOrders} settled orders</div>
        </div>

        <div
          onClick={() => onSelectTab('daily_sales')}
          className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-4 rounded-2xl cursor-pointer transition"
        >
          <div className="flex justify-between items-center text-slate-400 text-xs font-bold uppercase">
            <span>Avg Order Value (AOV)</span>
            <ShoppingBag className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 mt-2">₹{avgOrderValue}</div>
          <div className="text-[10px] text-slate-400 mt-1">Per transaction average</div>
        </div>

        <div
          onClick={() => onSelectTab('expense')}
          className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-4 rounded-2xl cursor-pointer transition"
        >
          <div className="flex justify-between items-center text-slate-400 text-xs font-bold uppercase">
            <span>Total Expenses</span>
            <TrendingUp className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400 mt-2">₹{totalExpenses}</div>
          <div className="text-[10px] text-slate-400 mt-1">{expenses.length} expense vouchers</div>
        </div>

        <div
          onClick={() => onSelectTab('p_n_l')}
          className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-4 rounded-2xl cursor-pointer transition"
        >
          <div className="flex justify-between items-center text-slate-400 text-xs font-bold uppercase">
            <span>Est. Net Margin</span>
            <LayoutDashboard className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-sky-400 mt-2">
            ₹{totalSales - totalExpenses}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Revenue minus Expenses</div>
        </div>
      </div>

      {/* Visual Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Category Revenue Donut */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
          <div className="flex justify-between items-center">
            <h4 className="text-sm font-black text-slate-200 uppercase flex items-center gap-2">
              <Utensils className="w-4 h-4 text-amber-400" />
              Category Sales Distribution
            </h4>
            <button
              onClick={() => onSelectTab('category_sales')}
              className="text-xs font-bold text-amber-400 hover:underline"
            >
              View Report &rarr;
            </button>
          </div>
          <SimpleDonutChart data={categoryDonutData} totalLabel="Category Sales" />
        </div>

        {/* Order Fulfillment Types */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="text-sm font-black text-slate-200 uppercase flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              Order Mode Split
            </h4>
            <button
              onClick={() => onSelectTab('daily_sales')}
              className="text-xs font-bold text-amber-400 hover:underline"
            >
              View Orders &rarr;
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-center">
              <div className="text-xs font-bold text-amber-400 uppercase">Dine-In</div>
              <div className="text-2xl font-black text-slate-100 mt-1">{modeCounts.dine_in}</div>
              <div className="text-[10px] text-slate-500">Orders</div>
            </div>
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-center">
              <div className="text-xs font-bold text-emerald-400 uppercase">Takeaway</div>
              <div className="text-2xl font-black text-slate-100 mt-1">{modeCounts.takeaway}</div>
              <div className="text-[10px] text-slate-500">Orders</div>
            </div>
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-center">
              <div className="text-xs font-bold text-sky-400 uppercase">Delivery</div>
              <div className="text-2xl font-black text-slate-100 mt-1">{modeCounts.delivery}</div>
              <div className="text-[10px] text-slate-500">Orders</div>
            </div>
          </div>

          {/* Top Selling Dishes Ranking */}
          <div className="space-y-2 pt-2">
            <div className="text-xs font-bold text-slate-400 uppercase flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-amber-400" />
              Top 5 Selling Dishes
            </div>
            <div className="divide-y divide-slate-850 text-xs">
              {topItems.map((item, idx) => (
                <div key={idx} className="py-2 flex justify-between items-center">
                  <span className="font-extrabold text-amber-300">
                    #{idx + 1} {item.name}
                  </span>
                  <div className="text-right">
                    <span className="font-bold text-slate-200">₹{item.revenue}</span>
                    <span className="text-slate-500 ml-2">({item.qty} sold)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Hourly Sales Heatmap Grid */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
        <div className="flex justify-between items-center">
          <h4 className="text-sm font-black text-slate-200 uppercase flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            24-Hour Business Intensity Heatmap
          </h4>
          <button
            onClick={() => onSelectTab('hourly_sales')}
            className="text-xs font-bold text-amber-400 hover:underline"
          >
            Hourly Report &rarr;
          </button>
        </div>
        <HourlyHeatmapGrid hourlyData={hourlyMap} />
      </div>
    </div>
  );
};
