import React from 'react';
import { Order, Expense, Recipe, RawMaterial } from '../../../types';
import { calculateRecipeTotalCost } from '../../../utils/inventoryEngine';
import { exportToCsv, printReport } from '../../../utils/reportExporter';
import { TrendingUp, Download, Printer, ShieldCheck } from 'lucide-react';

interface ProfitLossReportProps {
  orders: Order[];
  expenses: Expense[];
  recipes: Recipe[];
  rawMaterials: RawMaterial[];
  dateFilterText: string;
}

export const ProfitLossReport: React.FC<ProfitLossReportProps> = ({
  orders,
  expenses,
  recipes,
  rawMaterials,
  dateFilterText,
}) => {
  const settledOrders = orders.filter((o) => o.status === 'settled');

  // Revenue
  const grossSales = settledOrders.reduce((sum, o) => sum + (o.subtotal || o.finalTotal), 0);
  const totalDiscounts = settledOrders.reduce((sum, o) => sum + (o.discountAmount || 0), 0);
  const netSalesRevenue = Math.max(0, grossSales - totalDiscounts);

  // Cost of Goods Sold (COGS)
  const rawMap = new Map<string, RawMaterial>(rawMaterials.map((r) => [r.id, r]));
  const recipeMap: Record<string, Recipe> = {};
  recipes.forEach((r) => {
    recipeMap[r.menuItemId] = r;
  });

  let estimatedCogs = 0;
  settledOrders.forEach((o) => {
    o.items.forEach((it) => {
      const rec = recipeMap[it.menuItemId || ''];
      if (rec && rec.ingredients) {
        const dishCost = calculateRecipeTotalCost(rec.ingredients, rawMap);
        estimatedCogs += dishCost * it.quantity;
      } else {
        // Fallback default 30% food cost if recipe not configured
        estimatedCogs += it.price * it.quantity * 0.3;
      }
    });
  });

  const grossProfit = netSalesRevenue - estimatedCogs;
  const grossProfitMargin = netSalesRevenue > 0 ? (grossProfit / netSalesRevenue) * 100 : 0;

  // Operating Expenses
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

  // Net Profit
  const netProfit = grossProfit - totalExpenses;
  const netProfitMargin = netSalesRevenue > 0 ? (netProfit / netSalesRevenue) * 100 : 0;

  const handleExportCsv = () => {
    const headers = ['Financial Line Item', 'Amount (₹)', 'Percentage of Net Sales %'];
    const rows = [
      ['Gross POS Sales', grossSales, `${netSalesRevenue > 0 ? ((grossSales / netSalesRevenue) * 100).toFixed(1) : 0}%`],
      ['Less: Customer Discounts', -totalDiscounts, `${netSalesRevenue > 0 ? ((-totalDiscounts / netSalesRevenue) * 100).toFixed(1) : 0}%`],
      ['NET SALES REVENUE', netSalesRevenue, '100.0%'],
      ['Less: Cost of Goods Sold (COGS)', -estimatedCogs, `${netSalesRevenue > 0 ? ((-estimatedCogs / netSalesRevenue) * 100).toFixed(1) : 0}%`],
      ['GROSS PROFIT', grossProfit, `${grossProfitMargin.toFixed(1)}%`],
      ['Less: Operating Expenses', -totalExpenses, `${netSalesRevenue > 0 ? ((-totalExpenses / netSalesRevenue) * 100).toFixed(1) : 0}%`],
      ['NET OPERATING PROFIT / (LOSS)', netProfit, `${netProfitMargin.toFixed(1)}%`],
    ];
    exportToCsv('Profit_Loss_Statement_Report', headers, rows);
  };

  const handlePrint = () => {
    const headers = ['Financial Statement Item', 'Amount (₹)', 'Margin Share'];
    const rows = [
      ['Gross POS Sales', `₹${grossSales}`, ''],
      ['Discounts & Complimentaries', `-₹${totalDiscounts}`, ''],
      ['NET REVENUE', `₹${netSalesRevenue}`, '100%'],
      ['Cost of Goods Sold (Food Cost)', `-₹${estimatedCogs.toFixed(2)}`, `${((estimatedCogs / (netSalesRevenue || 1)) * 100).toFixed(1)}%`],
      ['GROSS PROFIT', `₹${grossProfit.toFixed(2)}`, `${grossProfitMargin.toFixed(1)}%`],
      ['Operating Expenses', `-₹${totalExpenses}`, `${((totalExpenses / (netSalesRevenue || 1)) * 100).toFixed(1)}%`],
      ['NET PROFIT / LOSS', `₹${netProfit.toFixed(2)}`, `${netProfitMargin.toFixed(1)}%`],
    ];
    printReport('Profit & Loss Executive Financial Statement', dateFilterText, headers, rows, [
      { label: 'Net Revenue', value: `₹${netSalesRevenue}` },
      { label: 'Gross Profit Margin', value: `${grossProfitMargin.toFixed(1)}%` },
      { label: 'Net Profit', value: `₹${netProfit.toFixed(2)}` },
      { label: 'Net Profit Margin', value: `${netProfitMargin.toFixed(1)}%` },
    ]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-amber-400" />
            Profit & Loss (P&L) Executive Financial Statement
          </h3>
          <p className="text-xs text-slate-400">Complete net profitability breakdown: Revenue, COGS, Gross Profit, Expenses, Net Profit</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Net Revenue</div>
          <div className="text-xl font-black text-amber-400 mt-1">₹{netSalesRevenue}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">COGS (Raw Food Cost)</div>
          <div className="text-xl font-black text-rose-400 mt-1">₹{estimatedCogs.toFixed(0)}</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
          <div className="text-[10px] uppercase font-bold text-slate-400">Gross Margin %</div>
          <div className="text-xl font-black text-sky-400 mt-1">{grossProfitMargin.toFixed(1)}%</div>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30">
          <div className="text-[10px] uppercase font-bold text-emerald-400">Net Profit</div>
          <div className={`text-xl font-black mt-1 ${netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ₹{netProfit.toFixed(0)}
          </div>
        </div>
      </div>

      {/* P&L Financial Statement Card */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="text-sm font-extrabold text-amber-400 uppercase tracking-wide border-b border-slate-800 pb-2">
          📊 Income Statement Breakdown
        </div>

        <div className="space-y-2 text-xs font-medium">
          <div className="flex justify-between py-1.5">
            <span className="text-slate-300 font-bold">1. Gross POS Sales</span>
            <span className="font-bold text-slate-100">₹{grossSales}</span>
          </div>
          <div className="flex justify-between py-1.5 text-rose-400">
            <span>&nbsp;&nbsp;&nbsp; Less: Customer Discounts</span>
            <span>-₹{totalDiscounts}</span>
          </div>
          <div className="flex justify-between py-2 border-t border-slate-800 font-black text-amber-400 text-sm">
            <span>2. Net Sales Revenue</span>
            <span>₹{netSalesRevenue}</span>
          </div>

          <div className="flex justify-between py-1.5 text-rose-400">
            <span>3. Less: Cost of Goods Sold (Ingredients & Raw Materials)</span>
            <span>-₹{estimatedCogs.toFixed(2)}</span>
          </div>

          <div className="flex justify-between py-2 border-t border-slate-800 font-black text-sky-400 text-sm">
            <span>4. Gross Profit (Revenue minus COGS)</span>
            <span>₹{grossProfit.toFixed(2)} ({grossProfitMargin.toFixed(1)}%)</span>
          </div>

          <div className="flex justify-between py-1.5 text-rose-400">
            <span>5. Less: Operational Expenses (Rent, Salaries, Utilities, Goods)</span>
            <span>-₹{totalExpenses}</span>
          </div>

          <div
            className={`flex justify-between py-3 border-t-2 border-slate-700 font-black text-base rounded-xl px-3 ${
              netProfit >= 0 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
            }`}
          >
            <span>6. NET OPERATING PROFIT / (LOSS)</span>
            <span>
              ₹{netProfit.toFixed(2)} ({netProfitMargin.toFixed(1)}%)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
