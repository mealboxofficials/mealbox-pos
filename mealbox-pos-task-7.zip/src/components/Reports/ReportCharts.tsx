import React from 'react';

interface BarData {
  label: string;
  value: number;
  secondaryValue?: number;
  color?: string;
}

/**
 * Reusable vertical/horizontal Bar Chart component using SVG and Tailwind CSS.
 */
export const SimpleBarChart: React.FC<{
  data: BarData[];
  height?: number;
  valueFormatter?: (val: number) => string;
}> = ({ data, height = 200, valueFormatter = (v) => `₹${v}` }) => {
  if (!data || data.length === 0) {
    return <div className="text-center text-slate-500 py-8 text-xs font-bold">No chart data available</div>;
  }

  const maxValue = Math.max(...data.map((d) => d.value), 1);

  return (
    <div className="space-y-2">
      <div className="flex items-end gap-2 pt-6 pb-2 px-2 border-b border-slate-800 overflow-x-auto min-w-full" style={{ height: `${height}px` }}>
        {data.map((item, idx) => {
          const heightPct = Math.max((item.value / maxValue) * 100, 4);
          const barColor = item.color || 'bg-amber-500 hover:bg-amber-400';

          return (
            <div key={idx} className="flex-1 min-w-[36px] flex flex-col items-center justify-end h-full group relative">
              {/* Tooltip / Value on top */}
              <div className="text-[10px] font-extrabold text-amber-300 opacity-90 group-hover:opacity-100 transition mb-1 text-center truncate w-full">
                {valueFormatter(item.value)}
              </div>

              {/* Bar */}
              <div
                className={`w-full rounded-t-md transition-all duration-300 ${barColor} shadow-md`}
                style={{ height: `${heightPct}%` }}
              />

              {/* Label below */}
              <div className="text-[10px] font-semibold text-slate-400 truncate w-full text-center mt-2 group-hover:text-amber-400">
                {item.label}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/**
 * Donut / Pie Chart for percentage share breakdowns.
 */
export const SimpleDonutChart: React.FC<{
  data: { label: string; value: number; color: string }[];
  totalLabel?: string;
  valueFormatter?: (val: number) => string;
}> = ({ data, totalLabel = 'Total Sales', valueFormatter = (v) => `₹${v}` }) => {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  if (total === 0) {
    return <div className="text-center text-slate-500 py-8 text-xs font-bold">No metric data available</div>;
  }

  let cumulativeAngle = 0;
  const slices = data.map((item) => {
    const percentage = item.value / total;
    const angle = percentage * 360;
    const startAngle = cumulativeAngle;
    cumulativeAngle += angle;

    return {
      ...item,
      percentage: (percentage * 100).toFixed(1),
      startAngle,
      angle,
    };
  });

  // Calculate SVG conic-gradient background
  const gradientStops = slices
    .map((s, idx) => {
      const prevStops = slices
        .slice(0, idx)
        .reduce((sum, item) => sum + item.angle, 0);
      const currentStop = prevStops + s.angle;
      return `${s.color} ${(prevStops / 360) * 100}% ${(currentStop / 360) * 100}%`;
    })
    .join(', ');

  return (
    <div className="flex flex-col sm:flex-row items-center justify-around gap-6 py-2">
      {/* Donut graphic */}
      <div className="relative w-36 h-36 shrink-0 rounded-full flex items-center justify-center shadow-2xl" style={{ background: `conic-gradient(${gradientStops})` }}>
        <div className="w-24 h-24 bg-slate-900 rounded-full flex flex-col items-center justify-center p-2 text-center border border-slate-800">
          <span className="text-[9px] uppercase font-bold text-slate-400">{totalLabel}</span>
          <span className="text-xs font-black text-amber-400 truncate w-full">{valueFormatter(total)}</span>
        </div>
      </div>

      {/* Legend list */}
      <div className="space-y-1.5 w-full max-w-xs text-xs">
        {slices.map((slice, idx) => (
          <div key={idx} className="flex items-center justify-between bg-slate-950/60 p-2 rounded-lg border border-slate-850">
            <div className="flex items-center gap-2 truncate">
              <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: slice.color }} />
              <span className="font-bold text-slate-200 truncate">{slice.label}</span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="font-extrabold text-slate-300">{valueFormatter(slice.value)}</span>
              <span className="text-[10px] bg-slate-800 text-amber-400 font-black px-1.5 py-0.5 rounded">
                {slice.percentage}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

/**
 * Hourly Heatmap Grid component for busy restaurant hours.
 */
export const HourlyHeatmapGrid: React.FC<{
  hourlyData: { hour: number; label: string; orderCount: number; revenue: number }[];
}> = ({ hourlyData }) => {
  const maxRevenue = Math.max(...hourlyData.map((h) => h.revenue), 1);

  return (
    <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-2">
      {hourlyData.map((h) => {
        const intensity = h.revenue / maxRevenue; // 0 to 1
        let bgClass = 'bg-slate-950 text-slate-400 border-slate-800';
        if (intensity > 0.75) {
          bgClass = 'bg-amber-500 text-slate-950 font-black border-amber-400 shadow-lg';
        } else if (intensity > 0.4) {
          bgClass = 'bg-amber-500/40 text-amber-300 font-extrabold border-amber-500/50';
        } else if (intensity > 0.1) {
          bgClass = 'bg-slate-800 text-slate-200 border-slate-700';
        }

        return (
          <div
            key={h.hour}
            className={`p-2.5 rounded-xl border text-center transition flex flex-col justify-between ${bgClass}`}
          >
            <div className="text-[10px] uppercase font-bold tracking-wider">{h.label}</div>
            <div className="text-xs font-black my-1">₹{h.revenue}</div>
            <div className="text-[9px] opacity-80">{h.orderCount} orders</div>
          </div>
        );
      })}
    </div>
  );
};
