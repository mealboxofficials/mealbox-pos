import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Order,
  OrderItem,
  OrderMode,
  Table,
  Customer,
  MenuItem,
  VoidedKotItem,
} from '../../types';
import { KotModal } from '../KOT/KotModal';
import { BillModal } from '../Billing/BillModal';
import { TableLifecycleModal } from '../Tables/TableLifecycleModal';
import {
  Utensils,
  ShoppingBag,
  Truck,
  Calendar,
  Gift,
  Search,
  Plus,
  Minus,
  Trash2,
  ChevronUp,
  ChevronDown,
  Printer,
  CreditCard,
  Save,
  Clock,
  User,
  Phone,
  AlertCircle,
  CheckCircle2,
  PlusCircle,
  X,
  Layers,
  Lock,
  Unlock,
  MoreVertical,
  Filter,
} from 'lucide-react';

export const OrderFlow: React.FC = () => {
  const {
    sections,
    activeSection,
    tables,
    menuItems,
    searchCustomers,
    saveOrder,
    generateKot,
    getOrderForTable,
    getOrderMinutes,
    setTableStatus,
    staff,
    showToast,
  } = useApp();

  // Live 1-second interval ticker for running table timers
  const [liveTick, setLiveTick] = useState<number>(Date.now());

  useEffect(() => {
    const timer = setInterval(() => {
      setLiveTick(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatLiveTimer = (createdAt?: string) => {
    if (!createdAt) return '0m 00s';
    const start = new Date(createdAt).getTime();
    const diffSec = Math.floor((liveTick - start) / 1000);
    if (diffSec <= 0) return '0m 00s';
    const m = Math.floor(diffSec / 60);
    const s = diffSec % 60;
    return `${m}m ${s < 10 ? '0' : ''}${s}s`;
  };

  // Step 1: Selected Order Mode
  const [selectedMode, setSelectedMode] = useState<OrderMode>('dine_in');

  // Advance Deposit Input (e.g. 500)
  const [advanceDepositInput, setAdvanceDepositInput] = useState<string>('');

  // Active Order state being built in POS
  const [currentOrder, setCurrentOrder] = useState<Partial<Order>>({
    mode: 'dine_in',
    sectionId: activeSection.id,
    items: [],
    subtotal: 0,
    attachedDues: 0,
    appliedCredit: 0,
    discountPercent: 0,
    finalTotal: 0,
    guestCount: 1,
  });

  // Selected Table for Dine-In
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);

  // Customer search & selection
  const [mobileQuery, setMobileQuery] = useState('');
  const [suggestedCustomers, setSuggestedCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [attachDuesChoice, setAttachDuesChoice] = useState(false);
  const [applyCreditChoice, setApplyCreditChoice] = useState(false);

  // Waiter & Guests
  const [selectedWaiter, setSelectedWaiter] = useState('');
  const [guestCountInput, setGuestCountInput] = useState(1);

  // Menu Search & Category
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [menuSearch, setMenuSearch] = useState<string>('');

  // Cart Expandable Drawer
  const [isCartExpanded, setIsCartExpanded] = useState(false);

  // Custom Item Modal State
  const [showCustomItemModal, setShowCustomItemModal] = useState(false);
  const [customItemName, setCustomItemName] = useState('');
  const [customItemPrice, setCustomItemPrice] = useState('');
  const [customItemQty, setCustomItemQty] = useState(1);

  // Note Modal State per item
  const [editingNoteItemId, setEditingNoteItemId] = useState<string | null>(null);
  const [itemNoteText, setItemNoteText] = useState('');

  // Modals
  const [activeKotModalOrder, setActiveKotModalOrder] = useState<Order | null>(null);
  const [kotNewItems, setKotNewItems] = useState<OrderItem[]>([]);
  const [kotVoidedItems, setKotVoidedItems] = useState<VoidedKotItem[]>([]);
  const [kotIsReprint, setKotIsReprint] = useState<boolean>(false);
  const [kotTokenNum, setKotTokenNum] = useState<number>(1);
  const [activeBillModalOrder, setActiveBillModalOrder] = useState<Order | null>(null);

  // Table Lifecycle Filters & Modal
  const [tableSectionFilter, setTableSectionFilter] = useState<string>('all');
  const [tableStatusFilter, setTableStatusFilter] = useState<string>('all');
  const [tableSearchQuery, setTableSearchQuery] = useState<string>('');
  const [selectedTableForLifecycle, setSelectedTableForLifecycle] = useState<Table | null>(null);

  // Filter section & status specific tables
  const filteredTables = tables.filter((tbl) => {
    if (tableSectionFilter !== 'all' && tbl.sectionId !== tableSectionFilter) return false;

    const activeOrd = getOrderForTable(tbl.id);
    const status = tbl.status;

    if (tableStatusFilter !== 'all') {
      if (tableStatusFilter === 'vacant') {
        if (status !== 'empty' && status !== 'vacant') return false;
      } else if (tableStatusFilter === 'occupied') {
        if (status !== 'occupied' && !activeOrd) return false;
      } else if (tableStatusFilter === 'billing') {
        if (status !== 'billing') return false;
      } else if (tableStatusFilter === 'settled') {
        if (status !== 'settled') return false;
      } else if (tableStatusFilter === 'reserved') {
        if (status !== 'reserved') return false;
      } else if (tableStatusFilter === 'cleaning') {
        if (status !== 'cleaning') return false;
      } else if (tableStatusFilter === 'locked') {
        if (!tbl.isLocked && status !== 'locked') return false;
      }
    }

    if (tableSearchQuery.trim()) {
      const q = tableSearchQuery.toLowerCase();
      const matchName = tbl.name.toLowerCase().includes(q);
      const matchWaiter = tbl.waiterName?.toLowerCase().includes(q);
      const matchRes = tbl.reservedBy?.toLowerCase().includes(q);
      const matchOrd = activeOrd ? activeOrd.orderNumber?.toString().includes(q) : false;
      if (!matchName && !matchWaiter && !matchRes && !matchOrd) return false;
    }

    return true;
  });

  // Reset order when activeSection changes
  useEffect(() => {
    resetPosState();
  }, [activeSection.id, selectedMode]);

  const resetPosState = () => {
    setSelectedTable(null);
    setSelectedCustomer(null);
    setMobileQuery('');
    setSuggestedCustomers([]);
    setAttachDuesChoice(false);
    setApplyCreditChoice(false);
    setSelectedWaiter('');
    setGuestCountInput(1);
    setAdvanceDepositInput('');
    setCurrentOrder({
      mode: selectedMode,
      sectionId: activeSection.id,
      items: [],
      subtotal: 0,
      attachedDues: 0,
      appliedCredit: 0,
      discountPercent: 0,
      finalTotal: 0,
      guestCount: 1,
    });
  };

  // Recalculate totals
  const updateOrderCalculations = (items: OrderItem[], dues: number, credit: number) => {
    const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const finalTotal = Math.max(0, subtotal + dues - credit);

    setCurrentOrder((prev) => ({
      ...prev,
      items,
      subtotal,
      attachedDues: dues,
      appliedCredit: credit,
      finalTotal,
    }));
  };

  // Table selection logic (Single Bill Rule)
  const handleTableClick = (table: Table) => {
    setSelectedTable(table);
    const existingActiveOrder = getOrderForTable(table.id);

    if (existingActiveOrder) {
      // Load existing active order (Single Bill Rule)
      setCurrentOrder(existingActiveOrder);
      setSelectedWaiter(existingActiveOrder.waiterName || '');
      setGuestCountInput(existingActiveOrder.guestCount || 1);
      setAdvanceDepositInput(existingActiveOrder.advanceDeposit ? existingActiveOrder.advanceDeposit.toString() : '');
      if (existingActiveOrder.customerMobile) {
        setMobileQuery(existingActiveOrder.customerMobile);
      }
      showToast(`Loaded active bill for ${table.name}`, 'info');
    } else {
      // Start new order for this empty table
      resetPosState();
      setSelectedTable(table);
      setCurrentOrder((prev) => ({
        ...prev,
        tableId: table.id,
        tableName: table.name,
      }));
    }
  };

  // Non-dine in start new order button
  const handleStartNonDineOrder = () => {
    resetPosState();
    setCurrentOrder((prev) => ({
      ...prev,
      mode: selectedMode,
    }));
  };

  // Customer search auto-suggest
  const handleCustomerMobileType = (val: string) => {
    setMobileQuery(val);
    if (val.length >= 3) {
      const results = searchCustomers(val);
      setSuggestedCustomers(results);
    } else {
      setSuggestedCustomers([]);
    }
  };

  const selectCustomer = (c: Customer) => {
    setSelectedCustomer(c);
    setMobileQuery(c.mobile);
    setSuggestedCustomers([]);

    const dues = attachDuesChoice ? c.dues : 0;
    const credit = applyCreditChoice ? c.advance : 0;

    setCurrentOrder((prev) => ({
      ...prev,
      customerId: c.id,
      customerName: c.name,
      customerMobile: c.mobile,
      customerAddress: c.address,
    }));

    updateOrderCalculations(currentOrder.items || [], dues, credit);
  };

  const handleToggleDuesAttach = (attach: boolean) => {
    setAttachDuesChoice(attach);
    const duesAmount = attach && selectedCustomer ? selectedCustomer.dues : 0;
    const creditAmount = applyCreditChoice && selectedCustomer ? selectedCustomer.advance : 0;
    updateOrderCalculations(currentOrder.items || [], duesAmount, creditAmount);
  };

  const handleToggleCreditApply = (apply: boolean) => {
    setApplyCreditChoice(apply);
    const duesAmount = attachDuesChoice && selectedCustomer ? selectedCustomer.dues : 0;
    const creditAmount = apply && selectedCustomer ? selectedCustomer.advance : 0;
    updateOrderCalculations(currentOrder.items || [], duesAmount, creditAmount);
  };

  // Add Item to Order Cart
  const handleAddItem = (menuItem: MenuItem) => {
    // Determine section price
    const price = menuItem.sectionPrices[activeSection.id] || menuItem.price;
    const items = [...(currentOrder.items || [])];
    const isEditingExistingOrder = !!currentOrder.id;

    // Search for unprinted cart item to increment quantity, otherwise create new line item for KOT
    const existingIndex = items.findIndex((i) => i.menuItemId === menuItem.id && !i.kotPrinted);

    if (existingIndex > -1) {
      items[existingIndex].quantity += 1;
      if (isEditingExistingOrder) {
        items[existingIndex].isNew = true;
      }
    } else {
      items.push({
        id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        menuItemId: menuItem.id,
        nameEn: menuItem.nameEn,
        nameHi: menuItem.nameHi,
        price,
        quantity: 1,
        kotPrint: menuItem.kotPrint,
        kotPrinted: false,
        isNew: isEditingExistingOrder, // Tag as new item if added to existing order!
      });
    }

    const dues = attachDuesChoice && selectedCustomer ? selectedCustomer.dues : currentOrder.attachedDues || 0;
    const credit = applyCreditChoice && selectedCustomer ? selectedCustomer.advance : currentOrder.appliedCredit || 0;
    updateOrderCalculations(items, dues, credit);
  };

  const handleUpdateQty = (itemId: string, delta: number) => {
    let items = [...(currentOrder.items || [])];
    const isEditingExistingOrder = !!currentOrder.id;

    items = items
      .map((item) => {
        if (item.id === itemId) {
          const newQty = item.quantity + delta;
          if (newQty > 0) {
            return {
              ...item,
              quantity: newQty,
              isNew: isEditingExistingOrder ? true : item.isNew,
            };
          }
          return null;
        }
        return item;
      })
      .filter(Boolean) as OrderItem[];

    const dues = currentOrder.attachedDues || 0;
    const credit = currentOrder.appliedCredit || 0;
    updateOrderCalculations(items, dues, credit);
  };

  // Custom Item Addition
  const handleAddCustomItem = () => {
    if (!customItemName || !customItemPrice) return;

    const price = Number(customItemPrice) || 0;
    const qty = Number(customItemQty) || 1;
    const isEditingExistingOrder = !!currentOrder.id;

    const customItem: OrderItem = {
      id: `custom-${Date.now()}`,
      nameEn: customItemName,
      nameHi: customItemName,
      price,
      quantity: qty,
      kotPrint: true,
      kotPrinted: false,
      isNew: isEditingExistingOrder,
    };

    const items = [...(currentOrder.items || []), customItem];
    const dues = currentOrder.attachedDues || 0;
    const credit = currentOrder.appliedCredit || 0;

    updateOrderCalculations(items, dues, credit);
    setCustomItemName('');
    setCustomItemPrice('');
    setCustomItemQty(1);
    setShowCustomItemModal(false);
    showToast(`Added custom item: ${customItemName}`);
  };

  // Save Item Note
  const handleSaveItemNote = () => {
    if (!editingNoteItemId) return;
    const items = (currentOrder.items || []).map((it) =>
      it.id === editingNoteItemId ? { ...it, note: itemNoteText } : it
    );
    updateOrderCalculations(items, currentOrder.attachedDues || 0, currentOrder.appliedCredit || 0);
    setEditingNoteItemId(null);
    setItemNoteText('');
  };

  // Bottom Action Bar Actions
  const handleActionSave = () => {
    if (selectedMode === 'dine_in' && !selectedTable && !currentOrder.tableId) {
      showToast('Please select a table for Dine-In order', 'error');
      return;
    }

    const deposit = Number(advanceDepositInput) || 0;

    const saved = saveOrder({
      ...currentOrder,
      advanceDeposit: deposit,
      waiterName: selectedWaiter,
      guestCount: guestCountInput,
      customerMobile: mobileQuery || currentOrder.customerMobile,
    });

    showToast(`Order saved for ${saved.tableName || saved.mode.toUpperCase()}`);
    resetPosState();
  };

  const handleActionKot = () => {
    if (selectedMode === 'dine_in' && !selectedTable && !currentOrder.tableId) {
      showToast('Please select a table first', 'error');
      return;
    }

    const hasKotItems = (currentOrder.items || []).some((i) => i.kotPrint);
    if (!hasKotItems) {
      showToast('Please add food items to print KOT', 'error');
      return;
    }

    const deposit = Number(advanceDepositInput) || 0;

    const saved = saveOrder({
      ...currentOrder,
      advanceDeposit: deposit,
      waiterName: selectedWaiter,
      guestCount: guestCountInput,
      customerMobile: mobileQuery || currentOrder.customerMobile,
    });

    const { order, newItems, voidedItems, isReprint, kotTokenNumber } = generateKot(saved);
    setActiveKotModalOrder(order);
    setKotNewItems(newItems);
    setKotVoidedItems(voidedItems);
    setKotIsReprint(isReprint);
    setKotTokenNum(kotTokenNumber);
  };

  const handleActionBill = () => {
    if (selectedMode === 'dine_in' && !selectedTable && !currentOrder.tableId) {
      showToast('Please select a table first', 'error');
      return;
    }

    const deposit = Number(advanceDepositInput) || 0;

    const saved = saveOrder({
      ...currentOrder,
      advanceDeposit: deposit,
      waiterName: selectedWaiter,
      guestCount: guestCountInput,
      customerMobile: mobileQuery || currentOrder.customerMobile,
    });

    setActiveBillModalOrder(saved);
  };

  // Get categories list
  const categories = ['All', ...Array.from(new Set(menuItems.map((m) => m.category)))];

  // Filter menu items by active section availability, category, and search text
  const filteredMenuItems = menuItems.filter((m) => {
    if (!m.active) return false;
    if (m.sections && m.sections.length > 0 && !m.sections.includes(activeSection.id)) return false;
    if (selectedCategory !== 'All' && m.category !== selectedCategory) return false;
    if (menuSearch.trim()) {
      const q = menuSearch.toLowerCase();
      return m.nameEn.toLowerCase().includes(q) || m.nameHi.includes(q);
    }
    return true;
  });

  return (
    <div className="flex flex-col h-[calc(100vh-105px)] bg-slate-950 text-slate-100 overflow-hidden">
      {/* Top Bar: Order Mode Selector */}
      <div className="bg-slate-900 border-b border-slate-800 p-2.5 px-4 flex items-center justify-between gap-2 overflow-x-auto">
        <div className="flex items-center gap-1.5 min-w-max">
          <button
            onClick={() => setSelectedMode('dine_in')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedMode === 'dine_in'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>Dine In</span>
          </button>

          <button
            onClick={() => setSelectedMode('takeaway')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedMode === 'takeaway'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Takeaway</span>
          </button>

          <button
            onClick={() => setSelectedMode('delivery')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedMode === 'delivery'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>Delivery</span>
          </button>

          <button
            onClick={() => setSelectedMode('reservation')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedMode === 'reservation'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Reservation</span>
          </button>

          <button
            onClick={() => setSelectedMode('free')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
              selectedMode === 'free'
                ? 'bg-amber-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
            }`}
          >
            <Gift className="w-4 h-4" />
            <span>Free / No Bill</span>
          </button>
        </div>

        {selectedMode !== 'dine_in' && (
          <button
            onClick={handleStartNonDineOrder}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-3.5 py-1.5 rounded-lg text-xs font-extrabold shadow"
          >
            + Start New {selectedMode.toUpperCase()} Order
          </button>
        )}
      </div>

      {/* Main Workspace Layout */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Left Panel: Table Grid (if Dine-In) / Customer Details */}
        <div className="w-full md:w-5/12 lg:w-4/12 border-b md:border-b-0 md:border-r border-slate-800 flex flex-col bg-slate-900/60 overflow-y-auto p-4 space-y-4">
          {selectedMode === 'dine_in' && (
            <div className="space-y-3">
              {/* Section & Status Filter Header */}
              <div className="flex flex-col gap-2 bg-slate-800/80 p-3 rounded-xl border border-slate-700/80">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" />
                    <span>Table Lifecycle</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold bg-slate-900 px-2 py-0.5 rounded-full border border-slate-700">
                    {filteredTables.length} Tables
                  </span>
                </div>

                {/* Section Filter Tabs */}
                <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-1">
                  <button
                    onClick={() => setTableSectionFilter('all')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                      tableSectionFilter === 'all'
                        ? 'bg-amber-500 text-slate-950 shadow'
                        : 'bg-slate-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    All Floors
                  </button>
                  {sections.map((sec) => (
                    <button
                      key={sec.id}
                      onClick={() => setTableSectionFilter(sec.id)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                        tableSectionFilter === sec.id
                          ? 'bg-amber-500 text-slate-950 shadow'
                          : 'bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {sec.name}
                    </button>
                  ))}
                </div>

                {/* Status Filter Chips */}
                <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5 text-[10px] font-bold">
                  {[
                    { id: 'all', label: 'All' },
                    { id: 'vacant', label: 'Vacant' },
                    { id: 'occupied', label: 'Occupied' },
                    { id: 'billing', label: 'Billing' },
                    { id: 'settled', label: 'Settled' },
                    { id: 'reserved', label: 'Reserved' },
                    { id: 'cleaning', label: 'Cleaning' },
                    { id: 'locked', label: 'Locked' },
                  ].map((chip) => {
                    const isAct = tableStatusFilter === chip.id;
                    return (
                      <button
                        key={chip.id}
                        onClick={() => setTableStatusFilter(chip.id)}
                        className={`px-2 py-0.5 rounded-md border transition whitespace-nowrap ${
                          isAct
                            ? 'border-amber-400 ring-1 ring-amber-400 font-extrabold text-amber-300 bg-slate-900'
                            : 'border-slate-700/60 text-slate-400 hover:bg-slate-700/50'
                        }`}
                      >
                        {chip.label}
                      </button>
                    );
                  })}
                </div>

                {/* Search Input */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={tableSearchQuery}
                    onChange={(e) => setTableSearchQuery(e.target.value)}
                    placeholder="Search table, waiter, guest, order #..."
                    className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
                  />
                  {tableSearchQuery && (
                    <button
                      onClick={() => setTableSearchQuery('')}
                      className="absolute right-2 top-2 text-slate-400 hover:text-white text-xs"
                    >
                      ×
                    </button>
                  )}
                </div>
              </div>

              {/* Tables Grid */}
              {filteredTables.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
                  No tables match selected filters.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {filteredTables.map((tbl) => {
                    const activeOrd = getOrderForTable(tbl.id);
                    const isOccupied = tbl.status === 'occupied' || !!activeOrd;
                    const isBilling = tbl.status === 'billing';
                    const isSettled = tbl.status === 'settled';
                    const isCleaning = tbl.status === 'cleaning';
                    const isReserved = tbl.status === 'reserved';
                    const isLocked = tbl.isLocked || tbl.status === 'locked';

                    const minutes = activeOrd ? getOrderMinutes(activeOrd) : 0;
                    const liveTimerStr = activeOrd ? formatLiveTimer(activeOrd.createdAt) : '';

                    const timerColor =
                      minutes >= 30
                        ? 'border-rose-500/80 text-rose-300 bg-rose-950/40'
                        : minutes >= 15
                        ? 'border-amber-500/80 text-amber-300 bg-amber-950/40'
                        : 'border-emerald-500/80 text-emerald-300 bg-emerald-950/40';

                    const isSelected = selectedTable?.id === tbl.id;

                    let cardBorderBg = 'bg-slate-800/80 border-slate-700 text-slate-400 hover:border-slate-500';

                    if (isSelected) {
                      cardBorderBg = 'ring-2 ring-amber-400 border-amber-400 bg-slate-800 text-slate-100';
                    } else if (isLocked) {
                      cardBorderBg = 'bg-rose-950/30 border-rose-600/70 text-rose-300';
                    } else if (isBilling) {
                      cardBorderBg = 'bg-amber-950/30 border-amber-500 text-amber-300';
                    } else if (isSettled) {
                      cardBorderBg = 'bg-blue-950/30 border-blue-500 text-blue-300';
                    } else if (isCleaning) {
                      cardBorderBg = 'bg-purple-950/30 border-purple-500 text-purple-300';
                    } else if (isReserved) {
                      cardBorderBg = 'bg-cyan-950/30 border-cyan-500 text-cyan-300';
                    } else if (isOccupied) {
                      cardBorderBg = timerColor;
                    }

                    return (
                      <div
                        key={tbl.id}
                        className={`relative p-2.5 rounded-xl border flex flex-col justify-between transition shadow-md group ${cardBorderBg}`}
                      >
                        {/* Card Header */}
                        <div className="flex items-center justify-between w-full">
                          <span className="font-extrabold text-sm text-slate-100">{tbl.name}</span>

                          {/* Options Trigger Button */}
                          <button
                            title="Table Operations"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedTableForLifecycle(tbl);
                            }}
                            className="p-1 rounded hover:bg-slate-700/80 text-slate-400 hover:text-amber-400 transition"
                          >
                            <MoreVertical className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Main Card Content Clickable Area */}
                        <button
                          onClick={() => {
                            if (isReserved || isLocked || isCleaning || isSettled) {
                              setSelectedTableForLifecycle(tbl);
                            } else {
                              handleTableClick(tbl);
                            }
                          }}
                          className="w-full text-left py-1 flex flex-col justify-center"
                        >
                          {/* Status Specific Info */}
                          {isLocked ? (
                            <div className="text-[10px] font-bold text-rose-400 flex items-center gap-1">
                              <Lock className="w-3 h-3" />
                              <span className="truncate">{tbl.lockedReason || 'LOCKED'}</span>
                            </div>
                          ) : isBilling ? (
                            <div>
                              <span className="px-1.5 py-0.5 text-[9px] font-extrabold bg-amber-500/20 text-amber-300 rounded border border-amber-500/40 uppercase">
                                BILL PRINTED
                              </span>
                              <div className="text-xs font-black text-amber-400 mt-1">₹{activeOrd?.finalTotal || 0}</div>
                            </div>
                          ) : isSettled ? (
                            <div>
                              <span className="px-1.5 py-0.5 text-[9px] font-extrabold bg-blue-500/20 text-blue-300 rounded border border-blue-500/40 uppercase">
                                SETTLED / PAID
                              </span>
                              <div className="text-[10px] text-slate-400 mt-1">Click to clean</div>
                            </div>
                          ) : isCleaning ? (
                            <div>
                              <span className="px-1.5 py-0.5 text-[9px] font-extrabold bg-purple-500/20 text-purple-300 rounded border border-purple-500/40 uppercase">
                                CLEANING
                              </span>
                              <div className="text-[10px] text-slate-400 mt-1">Click when ready</div>
                            </div>
                          ) : isReserved ? (
                            <div>
                              <span className="px-1.5 py-0.5 text-[9px] font-extrabold bg-cyan-500/20 text-cyan-300 rounded border border-cyan-500/40 uppercase">
                                RESERVED
                              </span>
                              <div className="text-[10px] text-cyan-200 mt-1 truncate">{tbl.reservedBy}</div>
                              <div className="text-[9px] text-slate-400">{tbl.reservedTime}</div>
                            </div>
                          ) : isOccupied && activeOrd ? (
                            <div>
                              <div className="text-xs font-black text-amber-400">₹{activeOrd.finalTotal}</div>
                              <div className="flex items-center gap-1 mt-0.5 text-[10px] font-extrabold tracking-wide text-slate-300">
                                <Clock className="w-3 h-3 animate-pulse text-amber-400" />
                                <span>{liveTimerStr}</span>
                              </div>
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-500 uppercase font-semibold">Vacant</span>
                          )}
                        </button>

                        {/* Card Footer Badges */}
                        <div className="flex items-center justify-between text-[9px] text-slate-400 border-t border-slate-700/50 pt-1 mt-1">
                          {tbl.waiterName ? (
                            <span className="truncate max-w-[80px]" title={`Waiter: ${tbl.waiterName}`}>
                              👤 {tbl.waiterName}
                            </span>
                          ) : (
                            <span></span>
                          )}
                          {tbl.guestCount ? <span>👥 {tbl.guestCount} Pax</span> : null}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Customer Details Form & Auto Suggest */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3.5 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-amber-400 uppercase">
              <span>Customer Details</span>
              {selectedCustomer && (
                <button
                  onClick={() => {
                    setSelectedCustomer(null);
                    setMobileQuery('');
                    setAttachDuesChoice(false);
                    setApplyCreditChoice(false);
                  }}
                  className="text-slate-400 hover:text-rose-400 text-[10px]"
                >
                  Clear Customer
                </button>
              )}
            </div>

            {/* Mobile Auto-suggest */}
            <div className="relative">
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Mobile (3+ chars auto-suggests)..."
                  value={mobileQuery}
                  onChange={(e) => handleCustomerMobileType(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Auto suggest dropdown */}
              {suggestedCustomers.length > 0 && (
                <div className="absolute left-0 right-0 mt-1 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl z-30 divide-y divide-slate-700 max-h-48 overflow-y-auto">
                  {suggestedCustomers.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => selectCustomer(c)}
                      className="w-full text-left p-2 hover:bg-slate-700 text-xs flex justify-between items-center"
                    >
                      <div>
                        <div className="font-bold text-slate-200">{c.name}</div>
                        <div className="text-slate-400">{c.mobile}</div>
                      </div>
                      <div className="text-right">
                        {c.dues > 0 && (
                          <span className="text-rose-400 font-bold block">Dues: ₹{c.dues}</span>
                        )}
                        {c.advance > 0 && (
                          <span className="text-emerald-400 font-bold block">Credit: ₹{c.advance}</span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* If Customer Selected: Dues & Credit prompt options */}
            {selectedCustomer && (
              <div className="space-y-2 pt-1 border-t border-slate-700 text-xs">
                <div className="font-semibold text-slate-200">{selectedCustomer.name}</div>

                {/* Pending Dues Option */}
                {selectedCustomer.dues > 0 && (
                  <div className="bg-rose-500/10 border border-rose-500/30 rounded-lg p-2.5 flex items-center justify-between text-rose-300">
                    <div>
                      <div className="font-bold">Pending Dues: ₹{selectedCustomer.dues}</div>
                      <div className="text-[10px] text-slate-400">Add ₹{selectedCustomer.dues} to this bill?</div>
                    </div>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => handleToggleDuesAttach(true)}
                        className={`px-2.5 py-1 rounded font-bold text-[11px] ${
                          attachDuesChoice ? 'bg-rose-500 text-white' : 'bg-slate-700 text-slate-300'
                        }`}
                      >
                        Yes
                      </button>
                      <button
                        onClick={() => handleToggleDuesAttach(false)}
                        className={`px-2.5 py-1 rounded font-bold text-[11px] ${
                          !attachDuesChoice ? 'bg-slate-700 text-white' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        No
                      </button>
                    </div>
                  </div>
                )}

                {/* Credit Balance Option */}
                {selectedCustomer.advance > 0 && (
                  <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-2.5 flex items-center justify-between text-emerald-300">
                    <div>
                      <div className="font-bold">Credit Balance: ₹{selectedCustomer.advance}</div>
                      <div className="text-[10px] text-slate-400">Apply ₹{selectedCustomer.advance} credit to this bill?</div>
                    </div>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => handleToggleCreditApply(true)}
                        className={`px-2.5 py-1 rounded font-bold text-[11px] ${
                          applyCreditChoice ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-300'
                        }`}
                      >
                        Yes
                      </button>
                      <button
                        onClick={() => handleToggleCreditApply(false)}
                        className={`px-2.5 py-1 rounded font-bold text-[11px] ${
                          !applyCreditChoice ? 'bg-slate-700 text-white' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        No
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Advance Deposit Input */}
            <div className="pt-2 border-t border-slate-700">
              <label className="text-[10px] font-extrabold text-amber-400 block mb-1 uppercase tracking-wider flex items-center justify-between">
                <span>Advance / Deposit (₹)</span>
                <span className="text-[9px] text-slate-400 font-normal font-sans">e.g. ₹500 advance pay</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-amber-400 font-bold text-xs">₹</span>
                <input
                  type="number"
                  placeholder="Enter Advance Deposit (e.g. 500)"
                  value={advanceDepositInput}
                  onChange={(e) => setAdvanceDepositInput(e.target.value)}
                  className="w-full bg-slate-950 border border-amber-500/50 rounded-lg pl-7 pr-3 py-1.5 text-xs font-bold text-amber-300 placeholder-slate-600 focus:outline-none focus:border-amber-400 shadow-inner"
                />
              </div>
            </div>

            {/* Waiter & Guests */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700">
              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">WAITER</label>
                <select
                  value={selectedWaiter}
                  onChange={(e) => setSelectedWaiter(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
                >
                  <option value="">Select Waiter</option>
                  {staff
                    .filter((s) => s.role === 'waiter')
                    .map((s) => (
                      <option key={s.id} value={s.name}>
                        {s.name}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">GUESTS</label>
                <input
                  type="number"
                  min="1"
                  value={guestCountInput}
                  onChange={(e) => setGuestCountInput(Math.max(1, Number(e.target.value) || 1))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel: Menu Grid & Active Cart */}
        <div className="w-full md:w-7/12 lg:w-8/12 flex flex-col bg-slate-950 overflow-hidden relative">
          {/* Category Filter Pills & Search */}
          <div className="p-3 bg-slate-900 border-b border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search items in English or Hindi (मसाला, डोसा)..."
                  value={menuSearch}
                  onChange={(e) => setMenuSearch(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <button
                onClick={() => setShowCustomItemModal(true)}
                className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-400 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 shrink-0"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Custom Item</span>
              </button>
            </div>

            {/* Category horizontal scroll pills */}
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pb-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold shrink-0 transition ${
                    selectedCategory === cat
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Menu Items Grid */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredMenuItems.map((item) => {
                const sectionPrice = item.sectionPrices[activeSection.id] || item.price;
                const cartQty =
                  (currentOrder.items || []).find((i) => i.menuItemId === item.id)?.quantity || 0;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleAddItem(item)}
                    className="relative bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-3.5 rounded-2xl flex flex-col justify-between text-left transition hover:shadow-lg group"
                  >
                    {/* Badge for Quantity in Cart */}
                    {cartQty > 0 && (
                      <span className="absolute top-2 right-2 bg-amber-500 text-slate-950 font-black text-xs px-2 py-0.5 rounded-full shadow">
                        ×{cartQty}
                      </span>
                    )}

                    <div>
                      <div className="font-extrabold text-sm text-slate-100 group-hover:text-amber-400 transition">
                        {item.nameEn}
                      </div>
                      <div className="text-xs text-slate-400 font-medium mt-0.5">
                        {item.nameHi}
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-sm font-black text-amber-400">₹{sectionPrice}</span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-semibold">
                        {item.category}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Cart Drawer Bar & Summary Above Action Buttons */}
          <div className="bg-slate-900 border-t border-slate-800 z-20">
            {/* Expandable Cart Drawer Trigger Header */}
            <button
              onClick={() => setIsCartExpanded(!isCartExpanded)}
              className="w-full bg-slate-850 hover:bg-slate-800 p-2.5 px-4 flex items-center justify-between border-b border-slate-800 text-xs font-bold text-slate-200 transition"
            >
              <div className="flex items-center gap-2">
                <span>Selected Items ({currentOrder.items?.length || 0})</span>
                {currentOrder.attachedDues ? (
                  <span className="bg-rose-500/20 text-rose-300 text-[10px] px-2 py-0.5 rounded">
                    +Dues ₹{currentOrder.attachedDues}
                  </span>
                ) : null}
                {currentOrder.appliedCredit ? (
                  <span className="bg-emerald-500/20 text-emerald-300 text-[10px] px-2 py-0.5 rounded">
                    -Credit ₹{currentOrder.appliedCredit}
                  </span>
                ) : null}
              </div>
              <div className="flex items-center gap-2 text-amber-400 font-extrabold">
                <span>Subtotal: ₹{currentOrder.finalTotal || 0}</span>
                {isCartExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
              </div>
            </button>

            {/* Expanded Cart Item Details */}
            {isCartExpanded && (
              <div className="max-h-48 overflow-y-auto p-3 divide-y divide-slate-800 bg-slate-950">
                {currentOrder.items?.length === 0 ? (
                  <div className="text-xs text-slate-500 py-4 text-center">No items added to cart yet</div>
                ) : (
                  currentOrder.items?.map((it) => (
                    <div key={it.id} className="py-2 flex items-center justify-between text-xs">
                      <div className="flex-1 pr-2">
                        <div className="font-bold text-slate-200 flex items-center gap-1.5">
                          <span>{it.nameEn}</span>
                          {it.isNew && (
                            <span className="bg-amber-400 text-slate-950 font-black text-[9px] px-1 rounded">
                              NEW
                            </span>
                          )}
                        </div>
                        {it.note ? (
                          <div className="text-[10px] text-amber-400 font-semibold italic">
                            Note: {it.note}
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setEditingNoteItemId(it.id);
                              setItemNoteText(it.note || '');
                            }}
                            className="text-[10px] text-slate-500 hover:text-amber-400"
                          >
                            + Add Instruction
                          </button>
                        )}
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-0.5 border border-slate-700">
                          <button
                            onClick={() => handleUpdateQty(it.id, -1)}
                            className="p-1 hover:bg-slate-700 rounded text-slate-300"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-black px-1.5 text-slate-100">{it.quantity}</span>
                          <button
                            onClick={() => handleUpdateQty(it.id, 1)}
                            className="p-1 hover:bg-slate-700 rounded text-slate-300"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <span className="font-extrabold text-amber-400 w-12 text-right">
                          ₹{it.price * it.quantity}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Always Visible 3-Button Bottom Action Bar */}
            <div className="p-3 grid grid-cols-3 gap-2.5 bg-slate-900 border-t border-slate-800">
              <button
                onClick={handleActionSave}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3 px-3 rounded-xl text-xs flex flex-col sm:flex-row items-center justify-center gap-1.5 shadow-md transition"
              >
                <Save className="w-4 h-4" />
                <span>SAVE</span>
              </button>

              <button
                onClick={handleActionKot}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-3 px-3 rounded-xl text-xs flex flex-col sm:flex-row items-center justify-center gap-1.5 shadow-md transition"
              >
                <Printer className="w-4 h-4" />
                <span>KOT</span>
              </button>

              <button
                onClick={handleActionBill}
                className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black py-3 px-3 rounded-xl text-xs flex flex-col sm:flex-row items-center justify-center gap-1.5 shadow-xl transition"
              >
                <CreditCard className="w-4 h-4" />
                <span>BILL</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Item Entry Modal */}
      {showCustomItemModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="font-bold text-slate-100 text-base">Add Custom Off-Menu Item</h4>
              <button
                onClick={() => setShowCustomItemModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Item Name</label>
                <input
                  type="text"
                  placeholder="e.g. Special Salad / Extra Sauce"
                  value={customItemName}
                  onChange={(e) => setCustomItemName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Price (₹)</label>
                  <input
                    type="number"
                    placeholder="0"
                    value={customItemPrice}
                    onChange={(e) => setCustomItemPrice(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-100"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={customItemQty}
                    onChange={(e) => setCustomItemQty(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-slate-100"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowCustomItemModal(false)}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleAddCustomItem}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs"
              >
                Add Item
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Item Special Instruction Modal */}
      {editingNoteItemId && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xs w-full p-4 space-y-3">
            <h4 className="font-bold text-slate-100 text-sm">Special Instructions</h4>
            <input
              type="text"
              placeholder="e.g. Extra Spicy / Less Oil / No Sugar"
              value={itemNoteText}
              onChange={(e) => setItemNoteText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-slate-100"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setEditingNoteItemId(null)}
                className="px-3 py-1.5 text-xs text-slate-400"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveItemNote}
                className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-lg text-xs"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* KOT Modal */}
      {activeKotModalOrder && (
        <KotModal
          order={activeKotModalOrder}
          newItemsOnly={kotNewItems}
          voidedItems={kotVoidedItems}
          isReprint={kotIsReprint}
          kotTokenNumber={kotTokenNum}
          onClose={() => setActiveKotModalOrder(null)}
          onPrintComplete={() => {
            setActiveKotModalOrder(null);
            resetPosState();
          }}
        />
      )}

      {/* Bill Modal */}
      {activeBillModalOrder && (
        <BillModal
          order={activeBillModalOrder}
          onClose={() => setActiveBillModalOrder(null)}
          onPaymentSuccess={() => {
            setActiveBillModalOrder(null);
            resetPosState();
          }}
        />
      )}

      {/* Table Lifecycle Operations Modal */}
      {selectedTableForLifecycle && (
        <TableLifecycleModal
          table={selectedTableForLifecycle}
          onClose={() => setSelectedTableForLifecycle(null)}
          onOpenCartForTable={(tbl) => {
            handleTableClick(tbl);
            setSelectedTableForLifecycle(null);
          }}
        />
      )}
    </div>
  );
};
