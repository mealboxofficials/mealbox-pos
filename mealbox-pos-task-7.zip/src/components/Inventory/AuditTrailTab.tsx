import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { History, Search, ArrowUpRight, ArrowDownRight, RefreshCw, ShoppingCart, Trash2 } from 'lucide-react';

export const AuditTrailTab: React.FC = () => {
  const { stockLogs, rawMaterials } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  const filteredLogs = stockLogs.filter((log) => {
    const matchesSearch =
      log.rawMaterialName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.notes && log.notes.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (log.referenceId && log.referenceId.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesType = typeFilter === 'all' || log.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'purchase_in':
        return { label: 'Stock In', bg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' };
      case 'sale_deduction':
        return { label: 'Sale Deduct', bg: 'bg-amber-500/10 text-amber-400 border-amber-500/20' };
      case 'sale_restoration':
        return { label: 'Sale Restore', bg: 'bg-sky-500/10 text-sky-400 border-sky-500/20' };
      case 'waste_out':
        return { label: 'Waste Out', bg: 'bg-rose-500/10 text-rose-400 border-rose-500/20' };
      case 'manual_adjustment':
        return { label: 'Audit Adjust', bg: 'bg-purple-500/10 text-purple-400 border-purple-500/20' };
      default:
        return { label: type, bg: 'bg-slate-800 text-slate-300' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <History className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Inventory Movement Audit Trail</h2>
            <p className="text-xs text-slate-400">
              Immutable ledger of every stock movement, POS order deduction, cancellation restoration, purchase entry & waste
            </p>
          </div>
        </div>

        <div className="text-right">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Ledger Entries</p>
          <p className="text-lg font-black text-slate-100">{stockLogs.length}</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between gap-4 flex-wrap">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search log by item name, order #, invoice # or notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 focus:border-amber-500 outline-none"
          />
        </div>

        <div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-xl px-3 py-2 outline-none font-medium"
          >
            <option value="all">All Movement Types</option>
            <option value="sale_deduction">Sale Deductions (POS Orders)</option>
            <option value="sale_restoration">Sale Restorations (Cancelled/Voided)</option>
            <option value="purchase_in">Stock In (Purchases)</option>
            <option value="waste_out">Waste & Spoilage</option>
            <option value="manual_adjustment">Stock Audit Adjustments</option>
          </select>
        </div>
      </div>

      {/* Movement Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">Timestamp</th>
                <th className="p-4">Movement Type</th>
                <th className="p-4">Raw Material</th>
                <th className="p-4">Qty Change</th>
                <th className="p-4">Prev → New Stock</th>
                <th className="p-4">Unit Cost</th>
                <th className="p-4">Total Cost</th>
                <th className="p-4">Notes / Reference</th>
                <th className="p-4 text-right">User</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-500 font-medium">
                    No stock movement logs found matching filters.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  const badge = getTypeBadge(log.type);
                  const isNegative = log.type === 'sale_deduction' || log.type === 'waste_out';

                  return (
                    <tr key={log.id} className="hover:bg-slate-800/50 transition">
                      <td className="p-4 text-slate-400 font-mono text-[11px]">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="p-4 font-bold">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-black border uppercase tracking-wider ${badge.bg}`}
                        >
                          {badge.label}
                        </span>
                      </td>
                      <td className="p-4 font-extrabold text-slate-100">{log.rawMaterialName}</td>
                      <td
                        className={`p-4 font-black text-sm ${
                          isNegative ? 'text-rose-400' : 'text-emerald-400'
                        }`}
                      >
                        {isNegative ? '−' : '+'}{log.quantity} {log.unit}
                      </td>
                      <td className="p-4 font-semibold text-slate-400 text-[11px]">
                        {log.previousStock} → <span className="text-slate-100 font-bold">{log.newStock} {log.unit}</span>
                      </td>
                      <td className="p-4 text-slate-400">₹{log.unitCostPrice}</td>
                      <td className="p-4 font-bold text-slate-200">₹{log.totalCost.toFixed(2)}</td>
                      <td className="p-4 text-slate-300 max-w-xs truncate">{log.notes}</td>
                      <td className="p-4 text-right text-slate-400">{log.createdBy}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
