import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Recipe, RecipeIngredient, UnitType } from '../../types';
import {
  calculateIngredientCost,
  calculateRecipeTotalCost,
  calculateFoodCostPercentage,
  getFoodCostColor,
} from '../../utils/inventoryEngine';
import { ChefHat, Plus, Trash2, Edit2, AlertCircle, CheckCircle2, Search, Percent } from 'lucide-react';

export const RecipesTab: React.FC = () => {
  const { menuItems, rawMaterials, recipes, saveRecipe, deleteRecipe } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editingRecipeId, setEditingRecipeId] = useState<string | null>(null);

  // Form State
  const [selectedMenuItemId, setSelectedMenuItemId] = useState('');
  const [yieldServings, setYieldServings] = useState('1');
  const [prepNotes, setPrepNotes] = useState('');
  const [ingredients, setIngredients] = useState<RecipeIngredient[]>([]);

  // Raw Material Map
  const rawMap = React.useMemo(() => {
    const map: Record<string, typeof rawMaterials[0]> = {};
    rawMaterials.forEach((m) => {
      map[m.id] = m;
    });
    return map;
  }, [rawMaterials]);

  const filteredRecipes = recipes.filter((r) =>
    r.menuItemName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingRecipeId(null);
    setSelectedMenuItemId(menuItems[0]?.id || '');
    setYieldServings('1');
    setPrepNotes('');
    setIngredients([]);
    setIsEditing(true);
  };

  const handleOpenEdit = (recipe: Recipe) => {
    setEditingRecipeId(recipe.id);
    setSelectedMenuItemId(recipe.menuItemId);
    setYieldServings(recipe.yieldServings.toString());
    setPrepNotes(recipe.preparationNotes || '');
    setIngredients([...recipe.ingredients]);
    setIsEditing(true);
  };

  const handleAddIngredient = () => {
    if (rawMaterials.length === 0) return;
    const defaultRaw = rawMaterials[0];
    setIngredients((prev) => [
      ...prev,
      {
        rawMaterialId: defaultRaw.id,
        rawMaterialName: defaultRaw.name,
        quantity: 0.1,
        unit: defaultRaw.unit,
      },
    ]);
  };

  const handleIngredientChange = (
    index: number,
    field: keyof RecipeIngredient,
    value: any
  ) => {
    setIngredients((prev) => {
      const updated = [...prev];
      if (field === 'rawMaterialId') {
        const selectedRaw = rawMaterials.find((m) => m.id === value);
        if (selectedRaw) {
          updated[index] = {
            ...updated[index],
            rawMaterialId: selectedRaw.id,
            rawMaterialName: selectedRaw.name,
            unit: selectedRaw.unit,
          };
        }
      } else {
        updated[index] = { ...updated[index], [field]: value };
      }
      return updated;
    });
  };

  const handleRemoveIngredient = (index: number) => {
    setIngredients((prev) => prev.filter((_, i) => i !== index));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMenuItemId) return;

    const menuItem = menuItems.find((m) => m.id === selectedMenuItemId);
    if (!menuItem) return;

    saveRecipe({
      id: editingRecipeId || undefined,
      menuItemId: menuItem.id,
      menuItemName: menuItem.nameEn,
      yieldServings: Number(yieldServings) || 1,
      preparationNotes: prepNotes,
      ingredients,
    });

    setIsEditing(false);
  };

  // Live calculation of current modal total cost
  const modalRecipeCost = React.useMemo(() => {
    return calculateRecipeTotalCost(ingredients, rawMap);
  }, [ingredients, rawMap]);

  const selectedMenuItem = menuItems.find((m) => m.id === selectedMenuItemId);
  const modalFoodCostPct = selectedMenuItem
    ? calculateFoodCostPercentage(modalRecipeCost, selectedMenuItem.price)
    : 0;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <ChefHat className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Recipe Engine & Food Costing</h2>
            <p className="text-xs text-slate-400">
              Map ingredients to menu items for precise automatic stock deduction & real-time food cost % calculation
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-lg"
        >
          <Plus className="w-4 h-4" />
          Create Recipe
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search dish recipe..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 focus:border-amber-500 outline-none"
          />
        </div>

        <div className="text-xs font-semibold text-slate-400">
          Mapped Recipes: <span className="text-amber-400 font-bold">{recipes.length}</span> / {menuItems.length} Dishes
        </div>
      </div>

      {/* Recipes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRecipes.length === 0 ? (
          <div className="col-span-full bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-500 font-medium">
            No recipes created yet. Click "Create Recipe" above to map ingredients to menu dishes.
          </div>
        ) : (
          filteredRecipes.map((recipe) => {
            const menuItem = menuItems.find((m) => m.id === recipe.menuItemId);
            const recipeCost = calculateRecipeTotalCost(recipe.ingredients, rawMap);
            const sellPrice = menuItem?.price || 0;
            const foodCostPct = calculateFoodCostPercentage(recipeCost, sellPrice);
            const statusColor = getFoodCostColor(foodCostPct);

            return (
              <div
                key={recipe.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 space-y-4 shadow-xl flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-base font-extrabold text-slate-100">{recipe.menuItemName}</h3>
                      <p className="text-[11px] text-slate-400">Yield: {recipe.yieldServings} Serving(s)</p>
                    </div>

                    <div className="text-right">
                      <span className={`inline-flex items-center gap-1 font-black text-xs px-2.5 py-1 rounded-full border ${statusColor}`}>
                        <Percent className="w-3 h-3" />
                        {foodCostPct.toFixed(1)}% Food Cost
                      </span>
                    </div>
                  </div>

                  {/* Financial Metrics */}
                  <div className="grid grid-cols-3 gap-2 bg-slate-950 border border-slate-850 p-2.5 rounded-xl my-3 text-center">
                    <div>
                      <p className="text-[10px] text-slate-500 font-bold">Recipe Cost</p>
                      <p className="text-xs font-black text-rose-400">₹{recipeCost.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 font-bold">Menu Price</p>
                      <p className="text-xs font-black text-emerald-400">₹{sellPrice}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 font-bold">Gross Margin</p>
                      <p className="text-xs font-black text-amber-400">₹{(sellPrice - recipeCost).toFixed(2)}</p>
                    </div>
                  </div>

                  {/* Ingredients Preview */}
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Ingredients ({recipe.ingredients.length})
                    </p>
                    <div className="space-y-1 max-h-32 overflow-y-auto text-xs text-slate-300 pr-1">
                      {recipe.ingredients.map((ing, idx) => {
                        const rawMat = rawMap[ing.rawMaterialId];
                        const ingCost = rawMat ? calculateIngredientCost(ing, rawMat) : 0;

                        return (
                          <div
                            key={idx}
                            className="flex items-center justify-between bg-slate-850/60 p-1.5 rounded-lg border border-slate-800"
                          >
                            <span className="font-semibold">{ing.rawMaterialName}</span>
                            <span className="text-slate-400 text-[11px]">
                              {ing.quantity} {ing.unit} (<span className="text-rose-300">₹{ingCost.toFixed(2)}</span>)
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Footer Buttons */}
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => handleOpenEdit(recipe)}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 border border-slate-700"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> Edit Recipe
                  </button>
                  <button
                    onClick={() => deleteRecipe(recipe.id)}
                    className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-bold px-3 py-1.5 rounded-xl text-xs border border-rose-500/20"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Recipe Create/Edit Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleFormSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-slate-100 text-base">
                {editingRecipeId ? 'Edit Recipe' : 'Create Recipe Mapping'}
              </h3>
              <div className="text-xs font-bold text-amber-400">
                Calculated Recipe Cost: ₹{modalRecipeCost.toFixed(2)} ({modalFoodCostPct.toFixed(1)}% Food Cost)
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Select Menu Item *</label>
                <select
                  value={selectedMenuItemId}
                  onChange={(e) => setSelectedMenuItemId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold"
                >
                  {menuItems.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.nameEn} (₹{m.price})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Yield (Servings)</label>
                <input
                  type="number"
                  min="1"
                  value={yieldServings}
                  onChange={(e) => setYieldServings(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>
            </div>

            {/* Ingredients Mapping Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wider">
                  Mapped Ingredients List
                </h4>
                <button
                  type="button"
                  onClick={handleAddIngredient}
                  className="bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold px-3 py-1 rounded-xl text-xs flex items-center gap-1 border border-slate-700"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Ingredient
                </button>
              </div>

              <div className="space-y-2">
                {ingredients.length === 0 ? (
                  <p className="text-xs text-slate-500 italic text-center py-4 border border-dashed border-slate-800 rounded-xl">
                    No ingredients added yet. Click "Add Ingredient" to build recipe.
                  </p>
                ) : (
                  ingredients.map((ing, idx) => {
                    const rawMat = rawMap[ing.rawMaterialId];
                    const ingCost = rawMat ? calculateIngredientCost(ing, rawMat) : 0;

                    return (
                      <div
                        key={idx}
                        className="grid grid-cols-12 gap-2 items-center bg-slate-950 border border-slate-800 p-2.5 rounded-xl text-xs"
                      >
                        <div className="col-span-5">
                          <label className="text-[10px] text-slate-500 font-bold block mb-0.5">Raw Material</label>
                          <select
                            value={ing.rawMaterialId}
                            onChange={(e) =>
                              handleIngredientChange(idx, 'rawMaterialId', e.target.value)
                            }
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-xs"
                          >
                            {rawMaterials.map((rm) => (
                              <option key={rm.id} value={rm.id}>
                                {rm.name} (Stock: {rm.currentStock} {rm.unit})
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="col-span-3">
                          <label className="text-[10px] text-slate-500 font-bold block mb-0.5">Quantity</label>
                          <input
                            type="number"
                            step="0.001"
                            value={ing.quantity}
                            onChange={(e) =>
                              handleIngredientChange(idx, 'quantity', Number(e.target.value))
                            }
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 font-bold"
                          />
                        </div>

                        <div className="col-span-2">
                          <label className="text-[10px] text-slate-500 font-bold block mb-0.5">Unit</label>
                          <select
                            value={ing.unit}
                            onChange={(e) =>
                              handleIngredientChange(idx, 'unit', e.target.value as UnitType)
                            }
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-xs"
                          >
                            <option value="Gram">Gram</option>
                            <option value="Kg">Kg</option>
                            <option value="ml">ml</option>
                            <option value="Litre">Litre</option>
                            <option value="Piece">Piece</option>
                            <option value="Packet">Packet</option>
                          </select>
                        </div>

                        <div className="col-span-2 flex items-center justify-between pl-1">
                          <div>
                            <p className="text-[9px] text-slate-500 font-bold">Cost</p>
                            <p className="font-extrabold text-rose-400">₹{ingCost.toFixed(2)}</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveIngredient(idx)}
                            className="text-rose-400 hover:text-rose-300 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-300 block mb-1 text-xs">Preparation Notes / Chef Instructions</label>
              <textarea
                rows={2}
                placeholder="e.g. Marinate chicken for 2 hours. Use medium flame."
                value={prepNotes}
                onChange={(e) => setPrepNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100"
              />
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800">
              <div className="text-xs">
                <span className="text-slate-400 font-medium">Food Cost Benchmark: </span>
                <span className="text-emerald-400 font-bold">Ideal &lt;30%</span> |{' '}
                <span className="text-amber-400 font-bold">Warning 30-38%</span> |{' '}
                <span className="text-rose-400 font-bold">Critical &gt;38%</span>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs shadow-lg"
                >
                  Save Recipe
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
