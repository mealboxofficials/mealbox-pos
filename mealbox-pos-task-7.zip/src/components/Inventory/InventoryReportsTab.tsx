import React from 'react';
import { useApp } from '../../context/AppContext';
import { calculateRecipeTotalCost, calculateFoodCostPercentage } from '../../utils/inventoryEngine';
import { BarChart3, AlertTriangle, TrendingDown, DollarSign, Calendar, PieChart } from 'lucide-react';

export const InventoryReportsTab: React.FC = () => {
  const { rawMaterials, recipes, menuItems, stockLogs, wasteEntries } = useApp();

  // Raw Material Map
  const rawMap = React.useMemo(() => {
    const map: Record<string, typeof rawMaterials[0]> = {};
    rawMaterials.forEach((m) => {
      map[m.id] = m;
    });
    return map;
  }, [rawMaterials]);

  // 1. Total Valuation
  const totalValuation = rawMaterials.reduce(
    (sum, m) => sum + m.currentStock * m.unitCostPrice,
    0
  );

  // 2. Low Stock Items
  const lowStockMaterials = rawMaterials.filter((m) => m.currentStock <= m.reorderLevel);

  // 3. Category Breakdown Valuation
  const categoryValuation: Record<string, number> = {};
  rawMaterials.forEach((m) => {
    categoryValuation[m.category] = (categoryValuation[m.category] || 0) + m.currentStock * m.unitCostPrice;
  });

  // 4. Daily Consumption Report (from stockLogs for today)
  const todayStr = new Date().toISOString().split('T')[0];
  const todayConsumptionLogs = stockLogs.filter(
    (log) => log.type === 'sale_deduction' && log.timestamp.startsWith(todayStr)
  );

  const todayMaterialConsumption: Record<string, { name: string; qty: number; unit: string; cost: number }> = {};
  todayConsumptionLogs.forEach((log) => {
    if (!todayMaterialConsumption[log.rawMaterialId]) {
      todayMaterialConsumption[log.rawMaterialId] = {
        name: log.rawMaterialName,
        qty: 0,
        unit: log.unit,
        cost: 0,
      };
    }
    todayMaterialConsumption[log.rawMaterialId].qty += log.quantity;
    todayMaterialConsumption[log.rawMaterialId].cost += log.totalCost;
  });

  // 5. Overall Average Food Cost %
  const mappedRecipeStats = recipes.map((recipe) => {
    const menuItem = menuItems.find((m) => m.id === recipe.menuItemId);
    const cost = calculateRecipeTotalCost(recipe.ingredients, rawMap);
    const price = menuItem?.price || 0;
    const foodCostPct = calculateFoodCostPercentage(cost, price);
    return { recipe, cost, price, foodCostPct };
  });

  const avgFoodCostPct =
    mappedRecipeStats.length > 0
      ? mappedRecipeStats.reduce((sum, r) => sum + r.foodCostPct, 0) / mappedRecipeStats.length
      : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Inventory Intelligence & Reports</h2>
            <p className="text-xs text-slate-400">
              Commercial stock valuation, daily ingredient consumption, food cost % breakdown & low stock alerts
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-right">
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Inventory Value</p>
            <p className="text-xl font-black text-emerald-400">
              ₹{totalValuation.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Avg Food Cost %</p>
            <p className="text-xl font-black text-amber-400">{avgFoodCostPct.toFixed(1)}%</p>
          </div>
        </div>
      </div>

      {/* Grid Section 1: Valuation by Category & Low Stock Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Category Valuation */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <h3 className="font-extrabold text-slate-100 text-sm flex items-center gap-2">
            <PieChart className="w-4 h-4 text-amber-400" />
            Inventory Valuation by Category
          </h3>

          <div className="space-y-3">
            {Object.entries(categoryValuation).map(([cat, val]) => {
              const pct = totalValuation > 0 ? (val / totalValuation) * 100 : 0;
              return (
                <div key={cat} className="space-y-1 text-xs">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-200">{cat}</span>
                    <span className="text-emerald-400">₹{val.toLocaleString('en-IN', { maximumFractionDigits: 2 })} ({pct.toFixed(1)}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                    <div
                      className="bg-amber-500 h-full rounded-full transition-all"
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Low Stock Alerts Summary */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-100 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              Low Stock Reorder Alerts ({lowStockMaterials.length})
            </h3>
            <span className="text-[11px] text-rose-400 font-bold bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
              URGENT
            </span>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto text-xs">
            {lowStockMaterials.length === 0 ? (
              <p className="text-slate-500 text-center py-6 font-medium">
                All raw material stock levels are healthy! No reorder alerts.
              </p>
            ) : (
              lowStockMaterials.map((m) => (
                <div
                  key={m.id}
                  className="flex items-center justify-between bg-slate-950 p-2.5 rounded-xl border border-rose-500/30"
                >
                  <div>
                    <span className="font-extrabold text-slate-100">{m.name}</span>
                    <span className="block text-[10px] text-slate-500">
                      Supplier: {m.supplierName || 'Default Vendor'}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-rose-400 text-sm">
                      {m.currentStock} {m.unit}
                    </span>
                    <span className="block text-[10px] text-slate-400">
                      Reorder Min: {m.reorderLevel} {m.unit}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Grid Section 2: Today's Consumption & Food Cost % Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Today's Consumption Report */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-100 text-sm flex items-center gap-2">
              <Calendar className="w-4 h-4 text-sky-400" />
              Daily Raw Material Consumption ({todayStr})
            </h3>
            <span className="text-xs text-slate-400 font-mono">Real-time POS Deductions</span>
          </div>

          <div className="space-y-2 max-h-64 overflow-y-auto text-xs">
            {Object.keys(todayMaterialConsumption).length === 0 ? (
              <p className="text-slate-500 text-center py-8 font-medium">
                No raw material consumption logged today yet. Place POS orders to trigger recipe deductions.
              </p>
            ) : (
              Object.values(todayMaterialConsumption).map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between bg-slate-950 p-2.5 rounded-xl border border-slate-850"
                >
                  <span className="font-bold text-slate-200">{item.name}</span>
                  <div className="text-right">
                    <span className="font-black text-amber-400">
                      {item.qty.toFixed(3)} {item.unit}
                    </span>
                    <span className="block text-[10px] text-slate-400">
                      Cost: ₹{item.cost.toFixed(2)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Dish Food Cost % Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <h3 className="font-extrabold text-slate-100 text-sm flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-emerald-400" />
            Dish Food Cost % Margin Ranking
          </h3>

          <div className="space-y-2 max-h-64 overflow-y-auto text-xs">
            {mappedRecipeStats.length === 0 ? (
              <p className="text-slate-500 text-center py-8 font-medium">
                No mapped dish recipes available for food cost analysis.
              </p>
            ) : (
              mappedRecipeStats
                .sort((a, b) => a.foodCostPct - b.foodCostPct)
                .map((stat) => (
                  <div
                    key={stat.recipe.id}
                    className="flex items-center justify-between bg-slate-950 p-2.5 rounded-xl border border-slate-850"
                  >
                    <div>
                      <span className="font-bold text-slate-200">{stat.recipe.menuItemName}</span>
                      <span className="block text-[10px] text-slate-400">
                        Cost: ₹{stat.cost.toFixed(2)} | Price: ₹{stat.price}
                      </span>
                    </div>

                    <div className="text-right">
                      <span
                        className={`font-black text-xs px-2 py-0.5 rounded ${
                          stat.foodCostPct <= 30
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : stat.foodCostPct <= 38
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {stat.foodCostPct.toFixed(1)}% Food Cost
                      </span>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
