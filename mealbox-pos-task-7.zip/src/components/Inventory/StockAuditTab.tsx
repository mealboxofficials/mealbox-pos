import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PhysicalStockAuditItem } from '../../types';
import { ClipboardCheck, CheckCircle2, AlertTriangle, Save, RefreshCw } from 'lucide-react';

export const StockAuditTab: React.FC = () => {
  const { rawMaterials, stockAudits, submitStockAudit } = useApp();

  const [auditNotes, setAuditNotes] = useState('');
  // Map of rawMaterialId -> string entered physical stock
  const [counts, setCounts] = useState<Record<string, string>>({});
  const [reasons, setReasons] = useState<Record<string, string>>({});

  const handleCountChange = (id: string, val: string) => {
    setCounts((prev) => ({ ...prev, [id]: val }));
  };

  const handleReasonChange = (id: string, val: string) => {
    setReasons((prev) => ({ ...prev, [id]: val }));
  };

  const handleSubmitAudit = (e: React.FormEvent) => {
    e.preventDefault();

    const auditItems: PhysicalStockAuditItem[] = [];

    rawMaterials.forEach((m) => {
      const enteredStr = counts[m.id];
      if (enteredStr !== undefined && enteredStr !== '') {
        const physicalStock = Number(enteredStr) || 0;
        const systemStock = m.currentStock;
        const variance = Number((physicalStock - systemStock).toFixed(3));
        const varianceValue = Number((variance * m.unitCostPrice).toFixed(2));

        auditItems.push({
          rawMaterialId: m.id,
          rawMaterialName: m.name,
          unit: m.unit,
          systemStock,
          physicalStock,
          variance,
          unitCost: m.unitCostPrice,
          varianceValue,
          reason: reasons[m.id] || 'Physical Stock Audit',
        });
      }
    });

    if (auditItems.length === 0) {
      alert('Please enter counted physical stock for at least 1 raw material before submitting.');
      return;
    }

    submitStockAudit(auditItems, auditNotes);

    setCounts({});
    setReasons({});
    setAuditNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <ClipboardCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Physical Stock Audit & Count</h2>
            <p className="text-xs text-slate-400">
              Conduct physical inventory counts, calculate variances, and auto-reconcile raw material stocks
            </p>
          </div>
        </div>

        <div className="text-right">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Past Audits Completed</p>
          <p className="text-lg font-black text-amber-400">{stockAudits.length}</p>
        </div>
      </div>

      {/* Perform Audit Form */}
      <form onSubmit={handleSubmitAudit} className="space-y-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl p-4">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800">
            <h3 className="font-extrabold text-sm text-slate-100 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-amber-400" />
              New Physical Stock Sheet
            </h3>
            <span className="text-xs text-slate-400">Enter actual measured physical stock in kitchen</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3">Raw Material</th>
                  <th className="p-3">System Stock</th>
                  <th className="p-3">Physical Counted *</th>
                  <th className="p-3">Variance</th>
                  <th className="p-3">Variance Value</th>
                  <th className="p-3">Audit Reason / Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                {rawMaterials.map((m) => {
                  const valStr = counts[m.id];
                  const hasVal = valStr !== undefined && valStr !== '';
                  const physicalNum = hasVal ? Number(valStr) || 0 : m.currentStock;
                  const variance = Number((physicalNum - m.currentStock).toFixed(3));
                  const varianceVal = Number((variance * m.unitCostPrice).toFixed(2));

                  return (
                    <tr key={m.id} className="hover:bg-slate-800/50 transition">
                      <td className="p-3 font-bold text-slate-100">
                        {m.name} <span className="text-slate-500 font-normal">({m.category})</span>
                      </td>
                      <td className="p-3 font-extrabold text-slate-300">
                        {m.currentStock} {m.unit}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="number"
                            step="0.001"
                            placeholder={m.currentStock.toString()}
                            value={counts[m.id] || ''}
                            onChange={(e) => handleCountChange(m.id, e.target.value)}
                            className="w-28 bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg p-1.5 text-slate-100 font-black text-xs outline-none"
                          />
                          <span className="text-slate-400 font-bold text-[11px]">{m.unit}</span>
                        </div>
                      </td>
                      <td className="p-3 font-black">
                        {!hasVal ? (
                          <span className="text-slate-600">0</span>
                        ) : variance === 0 ? (
                          <span className="text-emerald-400 font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Matched
                          </span>
                        ) : variance > 0 ? (
                          <span className="text-emerald-400">+{variance} {m.unit}</span>
                        ) : (
                          <span className="text-rose-400">{variance} {m.unit}</span>
                        )}
                      </td>
                      <td className="p-3 font-bold">
                        {!hasVal || variance === 0 ? (
                          <span className="text-slate-600">₹0.00</span>
                        ) : varianceVal > 0 ? (
                          <span className="text-emerald-400">+₹{varianceVal.toFixed(2)}</span>
                        ) : (
                          <span className="text-rose-400">-₹{Math.abs(varianceVal).toFixed(2)}</span>
                        )}
                      </td>
                      <td className="p-3">
                        <input
                          type="text"
                          placeholder="e.g. Monthly Physical Count"
                          value={reasons[m.id] || ''}
                          onChange={(e) => handleReasonChange(m.id, e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-slate-200 text-xs"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-800">
            <div>
              <input
                type="text"
                placeholder="Overall Audit Notes (e.g. End of Month Stock Take)"
                value={auditNotes}
                onChange={(e) => setAuditNotes(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 w-80 outline-none"
              />
            </div>

            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-xl"
            >
              <Save className="w-4 h-4" />
              Submit Stock Audit & Reconcile Inventory
            </button>
          </div>
        </div>
      </form>

      {/* Historical Stock Audits */}
      {stockAudits.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="font-extrabold text-slate-100 text-sm">Past Stock Audit History</h3>

          <div className="space-y-3">
            {stockAudits.map((audit) => (
              <div
                key={audit.id}
                className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs space-y-2"
              >
                <div className="flex items-center justify-between text-slate-400 border-b border-slate-850 pb-2">
                  <span className="font-mono text-amber-400 font-bold">
                    {new Date(audit.auditDate).toLocaleString()}
                  </span>
                  <span>Audited By: <strong className="text-slate-200">{audit.auditedBy}</strong></span>
                  <span>Total Net Variance Value: <strong className={audit.totalVarianceValue >= 0 ? 'text-emerald-400' : 'text-rose-400'}>₹{audit.totalVarianceValue.toFixed(2)}</strong></span>
                </div>

                <div className="flex flex-wrap gap-2 pt-1">
                  {audit.items.map((item, idx) => (
                    <span
                      key={idx}
                      className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg text-slate-300 font-medium"
                    >
                      {item.rawMaterialName}: Sys ({item.systemStock}) → Real ({item.physicalStock}) [
                      <strong className={item.variance >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                        {item.variance > 0 ? '+' : ''}{item.variance} {item.unit}
                      </strong>
                      ]
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
