import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UnitType, WasteReason } from '../../types';
import { Trash2, Plus, AlertOctagon, Calendar, DollarSign } from 'lucide-react';

export const WasteTab: React.FC = () => {
  const { wasteEntries, rawMaterials, menuItems, addWasteEntry } = useApp();

  const [isAddOpen, setIsAddOpen] = useState(false);

  // Form State
  const [wasteType, setWasteType] = useState<'raw_material' | 'prepared_food'>('raw_material');
  const [referenceId, setReferenceId] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<UnitType>('Kg');
  const [reason, setReason] = useState<WasteReason>('spoiled');
  const [notes, setNotes] = useState('');

  const handleOpenAdd = () => {
    setWasteType('raw_material');
    setReferenceId(rawMaterials[0]?.id || '');
    setQuantity('');
    setUnit(rawMaterials[0]?.unit || 'Kg');
    setReason('spoiled');
    setNotes('');
    setIsAddOpen(true);
  };

  const handleTypeChange = (type: 'raw_material' | 'prepared_food') => {
    setWasteType(type);
    if (type === 'raw_material') {
      const defaultMat = rawMaterials[0];
      setReferenceId(defaultMat?.id || '');
      setUnit(defaultMat?.unit || 'Kg');
    } else {
      const defaultMenu = menuItems[0];
      setReferenceId(defaultMenu?.id || '');
      setUnit('Piece');
    }
  };

  const handleRefChange = (id: string) => {
    setReferenceId(id);
    if (wasteType === 'raw_material') {
      const mat = rawMaterials.find((m) => m.id === id);
      if (mat) setUnit(mat.unit);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!referenceId || !quantity) return;

    let itemName = '';
    let estimatedCost = 0;
    const qtyNum = Number(quantity) || 0;

    if (wasteType === 'raw_material') {
      const mat = rawMaterials.find((m) => m.id === referenceId);
      itemName = mat?.name || 'Raw Material';
      estimatedCost = Number((qtyNum * (mat?.unitCostPrice || 0)).toFixed(2));
    } else {
      const menu = menuItems.find((m) => m.id === referenceId);
      itemName = menu?.nameEn || 'Prepared Food';
      estimatedCost = Number((qtyNum * ((menu?.price || 0) * 0.4)).toFixed(2)); // estimated 40% cost of sell price
    }

    addWasteEntry({
      type: wasteType === 'raw_material' ? 'raw_material' : 'menu_item',
      referenceId,
      name: itemName,
      quantity: qtyNum,
      unit,
      reason,
      estimatedCost,
      notes,
    });

    setIsAddOpen(false);
  };

  const totalWasteLoss = wasteEntries.reduce((sum, w) => sum + w.estimatedCost, 0);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-rose-500/20 text-rose-400 rounded-xl">
            <Trash2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Waste & Spoilage Log</h2>
            <p className="text-xs text-slate-400">
              Track raw material expiration, kitchen preparation waste, spillages, and food shrinkage loss
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Loss Value</p>
            <p className="text-lg font-black text-rose-400">₹{totalWasteLoss.toLocaleString('en-IN')}</p>
          </div>

          <button
            onClick={handleOpenAdd}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-lg"
          >
            <Plus className="w-4 h-4" />
            Log Waste Entry
          </button>
        </div>
      </div>

      {/* Waste History Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">Date / Time</th>
                <th className="p-4">Type</th>
                <th className="p-4">Item Name</th>
                <th className="p-4">Quantity Lost</th>
                <th className="p-4">Reason</th>
                <th className="p-4">Est. Loss Cost</th>
                <th className="p-4">Notes</th>
                <th className="p-4 text-right">Logged By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {wasteEntries.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500 font-medium">
                    No waste entries logged. Click "Log Waste Entry" to record kitchen waste.
                  </td>
                </tr>
              ) : (
                wasteEntries.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-800/50 transition">
                    <td className="p-4 text-slate-400 font-mono text-[11px]">
                      {new Date(w.createdAt).toLocaleString()}
                    </td>
                    <td className="p-4 font-bold">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] uppercase font-black ${
                          w.type === 'raw_material'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                        }`}
                      >
                        {w.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-4 font-extrabold text-slate-100">{w.name}</td>
                    <td className="p-4 font-black text-rose-400">
                      {w.quantity} {w.unit}
                    </td>
                    <td className="p-4 font-bold capitalize text-slate-300">{w.reason.replace('_', ' ')}</td>
                    <td className="p-4 font-black text-rose-400">₹{w.estimatedCost.toFixed(2)}</td>
                    <td className="p-4 text-slate-400 max-w-xs truncate">{w.notes || '—'}</td>
                    <td className="p-4 text-right text-slate-400">{w.createdBy}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Waste Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <h3 className="font-bold text-slate-100 text-base border-b border-slate-800 pb-2">
              Log Kitchen Waste / Food Spoilage
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Waste Category</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleTypeChange('raw_material')}
                    className={`py-2 rounded-xl font-bold border ${
                      wasteType === 'raw_material'
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    Raw Ingredient
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTypeChange('prepared_food')}
                    className={`py-2 rounded-xl font-bold border ${
                      wasteType === 'prepared_food'
                        ? 'bg-indigo-500/20 text-indigo-400 border-indigo-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    Prepared Dish
                  </button>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Select Item *</label>
                <select
                  value={referenceId}
                  onChange={(e) => handleRefChange(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold"
                >
                  {wasteType === 'raw_material'
                    ? rawMaterials.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} (Cost: ₹{m.unitCostPrice}/{m.unit})
                        </option>
                      ))
                    : menuItems.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.nameEn} (Sell: ₹{m.price})
                        </option>
                      ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Quantity Lost *</label>
                  <input
                    type="number"
                    required
                    step="0.001"
                    placeholder="e.g. 2.5"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold text-rose-400"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Reason</label>
                  <select
                    value={reason}
                    onChange={(e) => setReason(e.target.value as WasteReason)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="spoiled">Spoiled / Expired</option>
                    <option value="prep_waste">Kitchen Prep Waste</option>
                    <option value="burnt">Overcooked / Burnt</option>
                    <option value="spilled">Spilled / Dropped</option>
                    <option value="customer_return">Customer Return</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Notes / Explanation</label>
                <input
                  type="text"
                  placeholder="e.g. Fridge temperature fluctuation overnight"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-rose-500 hover:bg-rose-400 text-white font-bold px-5 py-2 rounded-xl text-xs shadow-lg"
              >
                Confirm Waste Log
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
