import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RawMaterial, UnitType } from '../../types';
import { Package, AlertTriangle, Plus, Edit2, Trash2, ArrowUpRight, ArrowDownRight, Search } from 'lucide-react';

export const RawMaterialsTab: React.FC = () => {
  const {
    rawMaterials,
    addRawMaterial,
    updateRawMaterial,
    deleteRawMaterial,
    manualStockAdjust,
    suppliers,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);

  // Modals state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<RawMaterial | null>(null);
  const [adjustingMaterial, setAdjustingMaterial] = useState<RawMaterial | null>(null);

  // Add/Edit Form State
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Dairy & Poultry');
  const [unit, setUnit] = useState<UnitType>('Kg');
  const [currentStock, setCurrentStock] = useState('');
  const [reorderLevel, setReorderLevel] = useState('');
  const [unitCostPrice, setUnitCostPrice] = useState('');
  const [supplierId, setSupplierId] = useState('');

  // Manual Adjust Form State
  const [adjustQty, setAdjustQty] = useState('');
  const [adjustType, setAdjustType] = useState<'in' | 'out'>('in');
  const [adjustReason, setAdjustReason] = useState('Stock Correction / Opening');

  const categories = ['Dairy & Poultry', 'Grocery & Spices', 'Vegetables & Produce', 'Packaging & Supplies', 'Beverage Ingre.'];

  const filteredMaterials = rawMaterials.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || m.category === categoryFilter;
    const isLow = m.currentStock <= (m.reorderLevel ?? m.lowStockThreshold ?? 5);
    const matchesLow = !showLowStockOnly || isLow;
    return matchesSearch && matchesCategory && matchesLow;
  });

  const totalValuation = rawMaterials.reduce(
    (sum, m) => sum + m.currentStock * m.unitCostPrice,
    0
  );

  const lowStockCount = rawMaterials.filter((m) => m.currentStock <= (m.reorderLevel ?? m.lowStockThreshold ?? 5)).length;

  const handleOpenAdd = () => {
    setName('');
    setCategory('Dairy & Poultry');
    setUnit('Kg');
    setCurrentStock('');
    setReorderLevel('5');
    setUnitCostPrice('');
    setSupplierId('');
    setIsAddOpen(true);
  };

  const handleOpenEdit = (m: RawMaterial) => {
    setEditingMaterial(m);
    setName(m.name);
    setCategory(m.category);
    setUnit(m.unit);
    setCurrentStock(m.currentStock.toString());
    setReorderLevel((m.reorderLevel ?? m.lowStockThreshold ?? 5).toString());
    setUnitCostPrice(m.unitCostPrice.toString());
    setSupplierId(m.supplierId || '');
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const selectedSup = suppliers.find((s) => s.id === supplierId);

    addRawMaterial({
      name: name.trim(),
      category,
      unit,
      currentStock: Number(currentStock) || 0,
      reorderLevel: Number(reorderLevel) || 5,
      unitCostPrice: Number(unitCostPrice) || 0,
      supplierId: supplierId || undefined,
      supplierName: selectedSup?.name,
    });

    setIsAddOpen(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMaterial || !name.trim()) return;

    const selectedSup = suppliers.find((s) => s.id === supplierId);

    updateRawMaterial(editingMaterial.id, {
      name: name.trim(),
      category,
      unit,
      currentStock: Number(currentStock) || 0,
      reorderLevel: Number(reorderLevel) || 5,
      unitCostPrice: Number(unitCostPrice) || 0,
      supplierId: supplierId || undefined,
      supplierName: selectedSup?.name,
    });

    setEditingMaterial(null);
  };

  const handleAdjustSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingMaterial || !adjustQty) return;

    manualStockAdjust(
      adjustingMaterial.id,
      Number(adjustQty) || 0,
      adjustType,
      adjustReason
    );

    setAdjustingMaterial(null);
    setAdjustQty('');
  };

  return (
    <div className="space-y-6">
      {/* Top Metrics Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Total Items</p>
            <p className="text-2xl font-black text-slate-100 mt-1">{rawMaterials.length}</p>
          </div>
          <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl">
            <Package className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Stock Valuation</p>
            <p className="text-2xl font-black text-emerald-400 mt-1">₹{totalValuation.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</p>
          </div>
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl font-bold text-lg">
            ₹
          </div>
        </div>

        <div
          onClick={() => setShowLowStockOnly(!showLowStockOnly)}
          className={`cursor-pointer p-4 rounded-2xl border transition flex items-center justify-between ${
            showLowStockOnly
              ? 'bg-rose-500/20 border-rose-500/50 text-rose-300'
              : 'bg-slate-900 border-slate-800 text-slate-100'
          }`}
        >
          <div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Low Stock Items</p>
            <p className="text-2xl font-black text-rose-400 mt-1">{lowStockCount}</p>
          </div>
          <div className="p-3 bg-rose-500/20 text-rose-400 rounded-xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-end">
          <button
            onClick={handleOpenAdd}
            className="w-full h-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg transition"
          >
            <Plus className="w-5 h-5" />
            Add Raw Material
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-wrap gap-3 items-center justify-between">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search raw material or category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 focus:border-amber-500 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-xl px-3 py-2 outline-none font-medium"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowLowStockOnly(!showLowStockOnly)}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
              showLowStockOnly
                ? 'bg-rose-500 text-white border-rose-500'
                : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            Low Stock Only ({lowStockCount})
          </button>
        </div>
      </div>

      {/* Raw Materials Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">Material Name</th>
                <th className="p-4">Category</th>
                <th className="p-4">Current Stock</th>
                <th className="p-4">Reorder Level</th>
                <th className="p-4">Cost Price / Unit</th>
                <th className="p-4">Stock Value</th>
                <th className="p-4">Default Supplier</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {filteredMaterials.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500 font-medium">
                    No raw materials found matching filters.
                  </td>
                </tr>
              ) : (
                filteredMaterials.map((m) => {
                  const threshold = m.reorderLevel ?? m.lowStockThreshold ?? 5;
                  const isLowStock = m.currentStock <= threshold;
                  const value = m.currentStock * m.unitCostPrice;

                  return (
                    <tr key={m.id} className="hover:bg-slate-800/50 transition">
                      <td className="p-4 font-bold text-slate-100">
                        <div className="flex items-center gap-2">
                          <span>{m.name}</span>
                          {isLowStock && (
                            <span className="bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-black px-2 py-0.5 rounded flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              REORDER
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-4 text-slate-400 font-medium">{m.category}</td>
                      <td className="p-4 font-black text-sm">
                        <span className={isLowStock ? 'text-rose-400' : 'text-emerald-400'}>
                          {m.currentStock} {m.unit}
                        </span>
                      </td>
                      <td className="p-4 text-slate-400 font-semibold">
                        {m.reorderLevel} {m.unit}
                      </td>
                      <td className="p-4 font-bold text-amber-400">
                        ₹{m.unitCostPrice} / {m.unit}
                      </td>
                      <td className="p-4 font-black text-slate-100">
                        ₹{value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                      </td>
                      <td className="p-4 text-slate-400">{m.supplierName || '—'}</td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setAdjustingMaterial(m)}
                            className="bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold px-2.5 py-1.5 rounded-lg border border-slate-700 text-[11px] flex items-center gap-1"
                            title="Quick Adjust Stock"
                          >
                            <ArrowUpRight className="w-3 h-3" /> Adjust
                          </button>
                          <button
                            onClick={() => handleOpenEdit(m)}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 p-1.5 rounded-lg border border-slate-700"
                            title="Edit Material"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteRawMaterial(m.id)}
                            className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 p-1.5 rounded-lg border border-rose-500/20"
                            title="Delete Material"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Material Modal */}
      {(isAddOpen || editingMaterial) && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={isAddOpen ? handleAddSubmit : handleEditSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <h3 className="font-bold text-slate-100 text-base border-b border-slate-800 pb-2">
              {isAddOpen ? 'Add New Raw Material' : `Edit Raw Material — ${editingMaterial?.name}`}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Material Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Basmati Rice 1121 / Paneer"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Stock Unit</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value as UnitType)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="Kg">Kg (Kilogram)</option>
                    <option value="Gram">Gram</option>
                    <option value="Litre">Litre</option>
                    <option value="ml">ml (Millilitre)</option>
                    <option value="Piece">Piece / Pc</option>
                    <option value="Packet">Packet</option>
                    <option value="Can">Can</option>
                    <option value="Box">Box</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Current Stock</label>
                  <input
                    type="number"
                    step="0.001"
                    placeholder="0"
                    value={currentStock}
                    onChange={(e) => setCurrentStock(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Reorder Level</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="5"
                    value={reorderLevel}
                    onChange={(e) => setReorderLevel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Cost / Unit (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={unitCostPrice}
                    onChange={(e) => setUnitCostPrice(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-amber-400 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Default Supplier</label>
                <select
                  value={supplierId}
                  onChange={(e) => setSupplierId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                >
                  <option value="">-- Select Supplier --</option>
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.companyName || 'Vendor'})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsAddOpen(false);
                  setEditingMaterial(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Save Material
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Manual Stock Adjust Modal */}
      {adjustingMaterial && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleAdjustSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl"
          >
            <h3 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">
              Quick Adjust Stock — {adjustingMaterial.name}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Adjustment Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustType('in')}
                    className={`py-2 rounded-xl font-bold flex items-center justify-center gap-1 border ${
                      adjustType === 'in'
                        ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    <ArrowUpRight className="w-4 h-4" /> Stock In (+)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustType('out')}
                    className={`py-2 rounded-xl font-bold flex items-center justify-center gap-1 border ${
                      adjustType === 'out'
                        ? 'bg-rose-500/20 text-rose-400 border-rose-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    <ArrowDownRight className="w-4 h-4" /> Stock Out (−)
                  </button>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">
                  Quantity ({adjustingMaterial.unit}) *
                </label>
                <input
                  type="number"
                  required
                  step="0.001"
                  min="0.001"
                  placeholder="e.g. 5"
                  value={adjustQty}
                  onChange={(e) => setAdjustQty(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold text-base text-amber-400"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Reason / Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Spoilage / Opening Stock / Manual Count"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setAdjustingMaterial(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Apply Adjustment
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
