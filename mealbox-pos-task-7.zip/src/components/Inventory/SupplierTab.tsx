import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Supplier } from '../../types';
import { Users, Plus, Edit2, Phone, Building2, CreditCard, DollarSign } from 'lucide-react';

export const SupplierTab: React.FC = () => {
  const { suppliers, addSupplier, updateSupplier, recordSupplierPayment } = useApp();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [payingSupplier, setPayingSupplier] = useState<Supplier | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [gstin, setGstin] = useState('');

  // Payment form state
  const [payAmount, setPayAmount] = useState('');
  const [payNotes, setPayNotes] = useState('');

  const handleOpenAdd = () => {
    setName('');
    setCompanyName('');
    setContactPerson('');
    setPhone('');
    setEmail('');
    setAddress('');
    setGstin('');
    setIsAddOpen(true);
  };

  const handleOpenEdit = (s: Supplier) => {
    setEditingSupplier(s);
    setName(s.name);
    setCompanyName(s.companyName || '');
    setContactPerson(s.contactPerson || '');
    setPhone(s.phone || s.mobile || '');
    setEmail(s.email || '');
    setAddress(s.address || '');
    setGstin(s.gstin || '');
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    addSupplier({
      name: name.trim(),
      companyName: companyName.trim() || undefined,
      contactPerson: contactPerson.trim() || undefined,
      phone: phone.trim(),
      email: email.trim() || undefined,
      address: address.trim() || undefined,
      gstin: gstin.trim() || undefined,
    });

    setIsAddOpen(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSupplier || !name.trim()) return;

    updateSupplier(editingSupplier.id, {
      name: name.trim(),
      companyName: companyName.trim() || undefined,
      contactPerson: contactPerson.trim() || undefined,
      phone: phone.trim(),
      email: email.trim() || undefined,
      address: address.trim() || undefined,
      gstin: gstin.trim() || undefined,
    });

    setEditingSupplier(null);
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingSupplier || !payAmount) return;

    recordSupplierPayment(
      payingSupplier.id,
      Number(payAmount) || 0,
      payNotes
    );

    setPayingSupplier(null);
    setPayAmount('');
    setPayNotes('');
  };

  const totalBalanceDue = suppliers.reduce((sum, s) => sum + s.balanceDue, 0);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Supplier & Vendor Management</h2>
            <p className="text-xs text-slate-400">
              Manage raw material vendors, track credit balances due, and record payments
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Pending Dues</p>
            <p className="text-lg font-black text-rose-400">₹{totalBalanceDue.toLocaleString('en-IN')}</p>
          </div>

          <button
            onClick={handleOpenAdd}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-lg"
          >
            <Plus className="w-4 h-4" />
            Add Supplier
          </button>
        </div>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {suppliers.map((s) => (
          <div
            key={s.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 space-y-4 shadow-xl flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-base font-extrabold text-slate-100">{s.name}</h3>
                  <p className="text-xs font-semibold text-amber-400 flex items-center gap-1 mt-0.5">
                    <Building2 className="w-3.5 h-3.5" />
                    {s.companyName || 'Independent Vendor'}
                  </p>
                </div>

                <div className="text-right">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Balance Due</p>
                  <p
                    className={`text-base font-black ${
                      s.balanceDue > 0 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    ₹{s.balanceDue.toLocaleString('en-IN')}
                  </p>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-300 mt-4 bg-slate-950 p-3 rounded-xl border border-slate-850">
                <p className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-500" />
                  <span className="font-bold">{s.phone || s.mobile}</span>
                </p>
                {s.contactPerson && (
                  <p className="text-slate-400">
                    Contact Person: <span className="text-slate-200 font-semibold">{s.contactPerson}</span>
                  </p>
                )}
                {s.address && <p className="text-slate-400 truncate">Address: {s.address}</p>}
                {s.gstin && <p className="text-slate-500 font-mono text-[10px]">GSTIN: {s.gstin}</p>}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <button
                onClick={() => setPayingSupplier(s)}
                disabled={s.balanceDue <= 0}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 ${
                  s.balanceDue > 0
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5" /> Record Payment
              </button>

              <button
                onClick={() => handleOpenEdit(s)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-3 py-1.5 rounded-xl text-xs border border-slate-700 flex items-center gap-1"
              >
                <Edit2 className="w-3.5 h-3.5" /> Edit
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Supplier Modal */}
      {(isAddOpen || editingSupplier) && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={isAddOpen ? handleAddSubmit : handleEditSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <h3 className="font-bold text-slate-100 text-base border-b border-slate-800 pb-2">
              {isAddOpen ? 'Add New Supplier' : `Edit Supplier — ${editingSupplier?.name}`}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Supplier / Trade Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Samastipur Dairy Traders"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Company Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Sudha Milk Agency"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Contact Person</label>
                  <input
                    type="text"
                    placeholder="e.g. Rajesh Kumar"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Phone / Mobile *</label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9876543210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">GSTIN Number</label>
                  <input
                    type="text"
                    placeholder="e.g. 10ABCDE1234F1Z5"
                    value={gstin}
                    onChange={(e) => setGstin(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 uppercase"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Address</label>
                <input
                  type="text"
                  placeholder="e.g. Station Road, Samastipur"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsAddOpen(false);
                  setEditingSupplier(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Save Supplier
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Record Payment Modal */}
      {payingSupplier && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handlePaymentSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl"
          >
            <h3 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">
              Pay Vendor — {payingSupplier.name}
            </h3>

            <div className="text-xs bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Current Balance Due:</span>
              <span className="font-black text-rose-400 text-sm">₹{payingSupplier.balanceDue.toLocaleString('en-IN')}</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Payment Amount (₹) *</label>
                <input
                  type="number"
                  required
                  min="1"
                  max={payingSupplier.balanceDue}
                  placeholder={payingSupplier.balanceDue.toString()}
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold text-base text-emerald-400"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Notes / Payment Ref</label>
                <input
                  type="text"
                  placeholder="e.g. Cash payment / GPay UPI Ref"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPayingSupplier(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Confirm Payment
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
