import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PurchaseItem, UnitType } from '../../types';
import { ShoppingBag, Plus, Trash2, FileText, Calendar, DollarSign, UserCheck } from 'lucide-react';

export const PurchaseTab: React.FC = () => {
  const { purchaseEntries, suppliers, rawMaterials, addPurchaseEntry } = useApp();

  const [isAddOpen, setIsAddOpen] = useState(false);

  // Form State
  const [supplierId, setSupplierId] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMode, setPaymentMode] = useState<'cash' | 'upi' | 'card' | 'credit'>('cash');
  const [items, setItems] = useState<PurchaseItem[]>([]);
  const [paidAmount, setPaidAmount] = useState('');

  const totalAmount = React.useMemo(() => {
    return items.reduce((sum, item) => sum + item.totalCost, 0);
  }, [items]);

  const handleOpenAdd = () => {
    setSupplierId(suppliers[0]?.id || '');
    setInvoiceNumber(`INV-${Math.floor(10000 + Math.random() * 90000)}`);
    setPurchaseDate(new Date().toISOString().split('T')[0]);
    setPaymentMode('cash');
    setItems([]);
    setPaidAmount('');
    setIsAddOpen(true);
  };

  const handleAddItem = () => {
    if (rawMaterials.length === 0) return;
    const defaultRaw = rawMaterials[0];
    setItems((prev) => [
      ...prev,
      {
        rawMaterialId: defaultRaw.id,
        rawMaterialName: defaultRaw.name,
        quantity: 10,
        unit: defaultRaw.unit,
        unitCostPrice: defaultRaw.unitCostPrice,
        totalCost: 10 * defaultRaw.unitCostPrice,
      },
    ]);
  };

  const handleItemChange = (index: number, field: keyof PurchaseItem, value: any) => {
    setItems((prev) => {
      const updated = [...prev];
      if (field === 'rawMaterialId') {
        const selectedRaw = rawMaterials.find((m) => m.id === value);
        if (selectedRaw) {
          const qty = updated[index].quantity || 1;
          const cost = selectedRaw.unitCostPrice;
          updated[index] = {
            ...updated[index],
            rawMaterialId: selectedRaw.id,
            rawMaterialName: selectedRaw.name,
            unit: selectedRaw.unit,
            unitCostPrice: cost,
            totalCost: qty * cost,
          };
        }
      } else if (field === 'quantity' || field === 'unitCostPrice') {
        const qty = field === 'quantity' ? Number(value) : updated[index].quantity;
        const cost = field === 'unitCostPrice' ? Number(value) : updated[index].unitCostPrice;
        updated[index] = {
          ...updated[index],
          [field]: value,
          totalCost: Number((qty * cost).toFixed(2)),
        };
      } else {
        updated[index] = { ...updated[index], [field]: value };
      }
      return updated;
    });
  };

  const handleRemoveItem = (index: number) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierId || items.length === 0) return;

    const supplier = suppliers.find((s) => s.id === supplierId);

    addPurchaseEntry({
      supplierId,
      supplierName: supplier?.name || 'Unknown Supplier',
      invoiceNumber,
      purchaseDate,
      totalAmount,
      paidAmount: Number(paidAmount) || (paymentMode === 'credit' ? 0 : totalAmount),
      paymentMode,
      items,
    });

    setIsAddOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Stock In & Purchase Entries</h2>
            <p className="text-xs text-slate-400">
              Receive supplier inventory deliveries, record vendor invoices, and auto-update stock & balance due
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-lg"
        >
          <Plus className="w-4 h-4" />
          New Purchase Entry
        </button>
      </div>

      {/* Purchase Entries Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">PO / Invoice #</th>
                <th className="p-4">Date</th>
                <th className="p-4">Supplier</th>
                <th className="p-4">Items Count</th>
                <th className="p-4">Total Amount</th>
                <th className="p-4">Paid Amount</th>
                <th className="p-4">Pending Due</th>
                <th className="p-4">Mode</th>
                <th className="p-4">Entered By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {purchaseEntries.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-500 font-medium">
                    No purchase entries logged yet. Click "New Purchase Entry" to receive stock.
                  </td>
                </tr>
              ) : (
                purchaseEntries.map((p) => {
                  const due = p.totalAmount - p.paidAmount;

                  return (
                    <tr key={p.id} className="hover:bg-slate-800/50 transition">
                      <td className="p-4 font-bold text-amber-400">
                        {p.purchaseNumber}
                        <span className="block text-[10px] text-slate-500">Inv: {p.invoiceNumber || 'N/A'}</span>
                      </td>
                      <td className="p-4 text-slate-300 font-medium">{p.purchaseDate}</td>
                      <td className="p-4 font-bold text-slate-100">{p.supplierName}</td>
                      <td className="p-4 text-slate-400 font-bold">{p.items.length} item(s)</td>
                      <td className="p-4 font-black text-slate-100">₹{p.totalAmount.toLocaleString('en-IN')}</td>
                      <td className="p-4 font-bold text-emerald-400">₹{p.paidAmount.toLocaleString('en-IN')}</td>
                      <td className="p-4 font-bold text-rose-400">
                        {due > 0 ? `₹${due.toLocaleString('en-IN')}` : 'PAID'}
                      </td>
                      <td className="p-4 font-bold uppercase text-[10px] tracking-wider text-slate-400">
                        {p.paymentMode}
                      </td>
                      <td className="p-4 text-slate-400">{p.createdBy}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Purchase Entry Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-slate-100 text-base">
                Record Stock In / Supplier Purchase Invoice
              </h3>
              <div className="text-xs font-bold text-emerald-400">
                Invoice Total: ₹{totalAmount.toLocaleString('en-IN')}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Supplier / Vendor *</label>
                <select
                  value={supplierId}
                  onChange={(e) => setSupplierId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.companyName || 'Vendor'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Invoice / Bill #</label>
                <input
                  type="text"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Purchase Date</label>
                <input
                  type="date"
                  value={purchaseDate}
                  onChange={(e) => setPurchaseDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Payment Mode</label>
                <select
                  value={paymentMode}
                  onChange={(e) => setPaymentMode(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                >
                  <option value="cash">Cash</option>
                  <option value="upi">UPI / Online</option>
                  <option value="card">Card</option>
                  <option value="credit">Credit / Unpaid Due</option>
                </select>
              </div>
            </div>

            {/* Items Received Table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wider">
                  Received Raw Materials List
                </h4>
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold px-3 py-1 rounded-xl text-xs flex items-center gap-1 border border-slate-700"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Item
                </button>
              </div>

              <div className="space-y-2">
                {items.length === 0 ? (
                  <p className="text-xs text-slate-500 italic text-center py-4 border border-dashed border-slate-800 rounded-xl">
                    No items added. Click "Add Item" to add delivered raw materials.
                  </p>
                ) : (
                  items.map((item, idx) => (
                    <div
                      key={idx}
                      className="grid grid-cols-12 gap-2 items-center bg-slate-950 border border-slate-800 p-2.5 rounded-xl text-xs"
                    >
                      <div className="col-span-5">
                        <label className="text-[10px] text-slate-500 font-bold block mb-0.5">Raw Material</label>
                        <select
                          value={item.rawMaterialId}
                          onChange={(e) => handleItemChange(idx, 'rawMaterialId', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-xs"
                        >
                          {rawMaterials.map((rm) => (
                            <option key={rm.id} value={rm.id}>
                              {rm.name} ({rm.unit})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-500 font-bold block mb-0.5">Qty ({item.unit})</label>
                        <input
                          type="number"
                          step="0.001"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 font-bold"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-[10px] text-slate-500 font-bold block mb-0.5">Unit Price (₹)</label>
                        <input
                          type="number"
                          step="0.01"
                          value={item.unitCostPrice}
                          onChange={(e) => handleItemChange(idx, 'unitCostPrice', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 font-bold text-amber-400"
                        />
                      </div>

                      <div className="col-span-3 flex items-center justify-between pl-1">
                        <div>
                          <p className="text-[9px] text-slate-500 font-bold">Total Cost</p>
                          <p className="font-extrabold text-emerald-400">₹{item.totalCost.toFixed(2)}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="text-rose-400 hover:text-rose-300 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-800 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">
                  Amount Paid Now (₹) {paymentMode === 'credit' && '(Optional for Credit)'}
                </label>
                <input
                  type="number"
                  placeholder={paymentMode === 'credit' ? '0' : totalAmount.toString()}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-black text-sm text-emerald-400"
                />
              </div>

              <div className="flex items-end justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-6 py-2.5 rounded-xl text-xs shadow-lg"
                >
                  Save Stock In
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
