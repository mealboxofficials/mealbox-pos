import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { MenuItem, OrderItem, OrderMode, Order } from '../../types';
import {
  Utensils,
  Search,
  ShoppingCart,
  BellRing,
  Droplets,
  Receipt,
  CheckCircle2,
  Clock,
  ChevronRight,
  Plus,
  Minus,
  X,
  Sparkles,
  Flame,
  Leaf,
  Info,
  Phone,
  User,
  MapPin,
  ArrowLeft,
  QrCode,
  RefreshCw,
} from 'lucide-react';

interface CustomerMenuAppProps {
  initialTableId?: string;
  initialMode?: OrderMode;
  onBackToPos?: () => void;
}

interface CartItem extends OrderItem {
  variantName?: string;
}

export const CustomerMenuApp: React.FC<CustomerMenuAppProps> = ({
  initialTableId,
  initialMode = 'dine_in',
  onBackToPos,
}) => {
  const {
    tables,
    sections,
    menuItems,
    orders,
    saveOrder,
    generateKot,
    addServiceRequest,
    showToast,
    getOrderForTable,
  } = useApp();

  // Selected table and mode state
  const [selectedTableId, setSelectedTableId] = useState<string>(
    initialTableId || (tables.length > 0 ? tables[0].id : '')
  );
  const [orderMode, setOrderMode] = useState<OrderMode>(initialMode);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | 'veg' | 'nonveg' | 'spicy'>('all');

  // Customer Contact Info (for Takeaway / Delivery or Dine In identification)
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [guestCount, setGuestCount] = useState<number>(2);

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCartDrawer, setShowCartDrawer] = useState(false);
  const [selectedCustomizingItem, setSelectedCustomizingItem] = useState<MenuItem | null>(null);
  const [customizingNote, setCustomizingNote] = useState('');
  const [customizingQty, setCustomizingQty] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Order Tracking View State
  const [activeTab, setActiveTab] = useState<'menu' | 'status'>('menu');
  const [lastActionMessage, setLastActionMessage] = useState<string | null>(null);

  const selectedTable = tables.find((t) => t.id === selectedTableId || t.name === selectedTableId);
  const currentActiveOrder = selectedTable ? getOrderForTable(selectedTable.id) : undefined;

  // Sync selectedTable when initialTableId changes
  useEffect(() => {
    if (initialTableId) {
      const t = tables.find((tbl) => tbl.id === initialTableId || tbl.name === initialTableId);
      if (t) setSelectedTableId(t.id);
    }
  }, [initialTableId, tables]);

  // Categories list
  const categories = ['all', ...Array.from(new Set(menuItems.map((m) => m.category)))];

  // Filtered menu items
  const filteredMenuItems = menuItems.filter((item) => {
    if (!item.active) return false;

    // Search query match
    const matchesSearch =
      item.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.nameHi.includes(searchQuery) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());

    // Category match
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;

    // Dietary match
    let matchesDietary = true;
    if (dietaryFilter === 'veg') matchesDietary = item.isVeg !== false; // Default veg
    if (dietaryFilter === 'nonveg') matchesDietary = item.isVeg === false;
    if (dietaryFilter === 'spicy') matchesDietary = item.isSpicy === true;

    return matchesSearch && matchesCategory && matchesDietary;
  });

  // Cart Operations
  const addToCart = (item: MenuItem, qty = 1, note = '') => {
    setCart((prev) => {
      const existingIdx = prev.findIndex(
        (ci) => ci.menuItemId === item.id && (ci.note || '') === (note || '')
      );
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx].quantity += qty;
        return updated;
      } else {
        const sectionPrice = selectedTable
          ? item.sectionPrices[selectedTable.sectionId] || item.price
          : item.price;
        const newCartItem: CartItem = {
          id: `cart-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          menuItemId: item.id,
          nameEn: item.nameEn,
          nameHi: item.nameHi,
          price: sectionPrice,
          quantity: qty,
          note,
          kotPrint: item.kotPrint,
          kotPrinted: false,
        };
        return [...prev, newCartItem];
      }
    });
    showToast(`Added ${item.nameEn} to cart`, 'success');
  };

  const updateCartQty = (cartId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((ci) => {
          if (ci.id === cartId) {
            const newQty = ci.quantity + delta;
            return newQty > 0 ? { ...ci, quantity: newQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const cartTotalAmount = cart.reduce((sum, ci) => sum + ci.price * ci.quantity, 0);
  const cartTotalItems = cart.reduce((sum, ci) => sum + ci.quantity, 0);

  // Submit QR Self-Order
  const handlePlaceOrder = () => {
    if (cart.length === 0) return;
    if (isSubmitting) return; // Prevent duplicate submission

    setIsSubmitting(true);

    try {
      if (orderMode === 'dine_in' && !selectedTable) {
        showToast('Please select a valid table for dine-in order', 'error');
        setIsSubmitting(false);
        return;
      }

      if (currentActiveOrder && orderMode === 'dine_in') {
        // APPEND TO EXISTING TABLE ORDER (Repeat QR Order)
        const combinedItems = [...currentActiveOrder.items, ...cart];
        const newSubtotal = combinedItems.reduce((sum, i) => sum + i.price * i.quantity, 0);

        const updatedOrder = saveOrder({
          id: currentActiveOrder.id,
          items: combinedItems,
          subtotal: newSubtotal,
          finalTotal: Math.max(0, newSubtotal - currentActiveOrder.discountAmount),
        });

        // Automatically send KOT to kitchen for the newly added items
        generateKot(updatedOrder.id);

        setCart([]);
        setShowCartDrawer(false);
        setActiveTab('status');
        setLastActionMessage('✨ Your additional items have been sent to the Kitchen!');
        showToast('Order updated & sent to Kitchen!', 'success');
      } else {
        // NEW ORDER CREATION
        const subtotal = cartTotalAmount;
        const section = selectedTable
          ? sections.find((s) => s.id === selectedTable.sectionId)
          : sections[0];

        const newOrderData: Partial<Order> = {
          sectionId: section ? section.id : 'sec-mealbox',
          sectionName: section ? section.name : 'Main Dining',
          tableId: orderMode === 'dine_in' ? selectedTable?.id : undefined,
          tableName: orderMode === 'dine_in' ? selectedTable?.name : undefined,
          mode: orderMode,
          items: cart,
          subtotal,
          finalTotal: subtotal,
          guestCount: guestCount || 1,
          customerName: customerName || 'QR Guest',
          customerMobile,
          customerAddress,
        };

        const createdOrder = saveOrder(newOrderData);

        // Auto-generate KOT so kitchen display instantly receives it
        generateKot(createdOrder.id);

        setCart([]);
        setShowCartDrawer(false);
        setActiveTab('status');
        setLastActionMessage(`🎉 Order #${createdOrder.orderNumber} placed & sent to Kitchen!`);
        showToast(`Order #${createdOrder.orderNumber} Placed Successfully!`, 'success');
      }
    } catch (err: any) {
      showToast(`Failed to place order: ${err.message}`, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Service Request Helpers (Call Waiter / Water / Bill)
  const handleServiceAction = (type: 'waiter' | 'water' | 'bill') => {
    if (!selectedTable) {
      showToast('Service call is available for Dine-In tables', 'info');
      return;
    }
    addServiceRequest(selectedTable.id, type);
    const textMap = { waiter: 'Waiter Called', water: 'Water Requested', bill: 'Bill Requested' };
    setLastActionMessage(`🔔 ${textMap[type]} for ${selectedTable.name}. Staff notified!`);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-28">
      {/* MOBILE-FIRST HEADER */}
      <div className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 p-3 sm:p-4 shadow-xl">
        <div className="max-w-lg mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            {onBackToPos && (
              <button
                onClick={onBackToPos}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-xl transition"
                title="Back to POS"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="w-10 h-10 bg-amber-500 rounded-2xl flex items-center justify-center font-black text-slate-950 shadow-md">
              <QrCode className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black text-amber-400 tracking-wide">
                  MealBox Digital Menu
                </h1>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Self-Order
                </span>
              </div>

              {/* Table / Order Selector */}
              <div className="flex items-center gap-2 mt-0.5">
                {orderMode === 'dine_in' ? (
                  <select
                    value={selectedTableId}
                    onChange={(e) => setSelectedTableId(e.target.value)}
                    className="bg-slate-950 text-amber-300 text-xs font-bold rounded-lg px-2 py-0.5 border border-amber-500/40 focus:outline-none"
                  >
                    {tables.map((tbl) => (
                      <option key={tbl.id} value={tbl.id}>
                        📍 Table {tbl.name} ({tbl.status.toUpperCase()})
                      </option>
                    ))}
                  </select>
                ) : (
                  <span className="text-xs font-bold text-slate-300">
                    {orderMode === 'takeaway' ? '🥡 Takeaway Counter' : '🛵 Home Delivery'}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Tab Toggle: Menu vs Order Status */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('menu')}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition ${
                activeTab === 'menu'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Menu
            </button>
            <button
              onClick={() => setActiveTab('status')}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition relative ${
                activeTab === 'status'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Track Order
              {currentActiveOrder && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 pt-4 space-y-4">
        {/* CUSTOMER ASSISTANCE QUICK CALL BAR */}
        {orderMode === 'dine_in' && selectedTable && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-lg flex items-center justify-between gap-2">
            <div className="text-[11px] font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Need Help?
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleServiceAction('water')}
                className="px-2.5 py-1.5 bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 rounded-xl text-xs font-bold flex items-center gap-1 transition"
              >
                <Droplets className="w-3.5 h-3.5" />
                Water
              </button>
              <button
                onClick={() => handleServiceAction('waiter')}
                className="px-2.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl text-xs font-bold flex items-center gap-1 transition"
              >
                <BellRing className="w-3.5 h-3.5" />
                Call Staff
              </button>
              <button
                onClick={() => handleServiceAction('bill')}
                className="px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold flex items-center gap-1 transition"
              >
                <Receipt className="w-3.5 h-3.5" />
                Get Bill
              </button>
            </div>
          </div>
        )}

        {/* FEEDBACK ACTION BANNER */}
        {lastActionMessage && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 p-3 rounded-2xl flex items-center justify-between text-xs text-emerald-300 font-bold">
            <span>{lastActionMessage}</span>
            <button onClick={() => setLastActionMessage(null)} className="text-emerald-400">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 1: DIGITAL MENU BROWSER */}
        {/* ======================================================== */}
        {activeTab === 'menu' && (
          <div className="space-y-4">
            {/* Search Input & Dietary Filters */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search French Fries, Paneer Butter Masala..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 font-medium"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Dietary Filter Pills */}
              <div className="flex items-center gap-2 text-xs font-bold overflow-x-auto pb-1 scrollbar-none">
                <button
                  onClick={() => setDietaryFilter('all')}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition ${
                    dietaryFilter === 'all'
                      ? 'bg-amber-500 text-slate-950 font-black'
                      : 'bg-slate-900 text-slate-400 border border-slate-800'
                  }`}
                >
                  All Items
                </button>
                <button
                  onClick={() => setDietaryFilter('veg')}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition flex items-center gap-1 ${
                    dietaryFilter === 'veg'
                      ? 'bg-emerald-500 text-slate-950 font-black'
                      : 'bg-slate-900 text-emerald-400 border border-slate-800'
                  }`}
                >
                  <Leaf className="w-3.5 h-3.5" />
                  Veg Only
                </button>
                <button
                  onClick={() => setDietaryFilter('nonveg')}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition flex items-center gap-1 ${
                    dietaryFilter === 'nonveg'
                      ? 'bg-rose-500 text-slate-950 font-black'
                      : 'bg-slate-900 text-rose-400 border border-slate-800'
                  }`}
                >
                  🔴 Non-Veg
                </button>
                <button
                  onClick={() => setDietaryFilter('spicy')}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition flex items-center gap-1 ${
                    dietaryFilter === 'spicy'
                      ? 'bg-orange-500 text-slate-950 font-black'
                      : 'bg-slate-900 text-orange-400 border border-slate-800'
                  }`}
                >
                  <Flame className="w-3.5 h-3.5" />
                  Chef Spicy
                </button>
              </div>

              {/* Category Filter Horizontal Scroll */}
              <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none text-xs font-bold">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap capitalize transition ${
                      selectedCategory === cat
                        ? 'bg-slate-200 text-slate-950 font-black shadow-md'
                        : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Menu Items Cards Grid */}
            <div className="space-y-3">
              {filteredMenuItems.length === 0 ? (
                <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-2">
                  <Utensils className="w-10 h-10 text-slate-600 mx-auto" />
                  <p className="text-sm font-bold text-slate-400">No dishes match your filter</p>
                  <p className="text-xs text-slate-500">Try searching or selecting another category</p>
                </div>
              ) : (
                filteredMenuItems.map((item) => {
                  const displayPrice = selectedTable
                    ? item.sectionPrices[selectedTable.sectionId] || item.price
                    : item.price;

                  // Find qty in cart
                  const cartItem = cart.find((c) => c.menuItemId === item.id);
                  const qtyInCart = cartItem ? cartItem.quantity : 0;

                  return (
                    <div
                      key={item.id}
                      className="bg-slate-900 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-3.5 flex gap-3 justify-between items-start transition shadow-md"
                    >
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-3 h-3 rounded-full border flex items-center justify-center ${
                              item.isVeg === false
                                ? 'border-rose-500 bg-rose-500/20'
                                : 'border-emerald-500 bg-emerald-500/20'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                item.isVeg === false ? 'bg-rose-500' : 'bg-emerald-500'
                              }`}
                            />
                          </span>
                          <h3 className="text-sm font-black text-slate-100">{item.nameEn}</h3>
                          {item.nameHi && (
                            <span className="text-xs font-bold text-amber-400/80">
                              ({item.nameHi})
                            </span>
                          )}
                        </div>

                        <div className="text-xs font-black text-amber-400">₹{displayPrice}</div>

                        {item.description && (
                          <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>
                        )}

                        {item.allergens && item.allergens.length > 0 && (
                          <div className="flex items-center gap-1 text-[10px] text-slate-500 font-bold">
                            <Info className="w-3 h-3 text-amber-400" />
                            Allergens: {item.allergens.join(', ')}
                          </div>
                        )}
                      </div>

                      {/* Add Button / Quantity Controls */}
                      <div className="flex flex-col items-end justify-between gap-2 self-stretch">
                        <span className="text-[10px] font-extrabold uppercase text-slate-500 bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
                          {item.category}
                        </span>

                        {qtyInCart === 0 ? (
                          <button
                            onClick={() => {
                              setSelectedCustomizingItem(item);
                              setCustomizingQty(1);
                              setCustomizingNote('');
                            }}
                            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs px-4 py-2 rounded-xl shadow-lg transition active:scale-95 flex items-center gap-1"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            ADD
                          </button>
                        ) : (
                          <div className="flex items-center bg-amber-500/20 border border-amber-500 text-amber-400 rounded-xl p-1 font-black text-xs">
                            <button
                              onClick={() => updateCartQty(cartItem!.id, -1)}
                              className="w-7 h-7 flex items-center justify-center rounded-lg bg-amber-500 text-slate-950 hover:bg-amber-400 transition"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="px-3 text-sm font-extrabold">{qtyInCart}</span>
                            <button
                              onClick={() => updateCartQty(cartItem!.id, 1)}
                              className="w-7 h-7 flex items-center justify-center rounded-lg bg-amber-500 text-slate-950 hover:bg-amber-400 transition"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: LIVE ORDER STATUS & TRACKER */}
        {/* ======================================================== */}
        {activeTab === 'status' && (
          <div className="space-y-5">
            {currentActiveOrder ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-5 shadow-2xl">
                {/* Active Order Header */}
                <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-xl font-bold">
                        <Clock className="w-5 h-5" />
                      </span>
                      <h2 className="text-xl font-black text-slate-100">
                        Order #{currentActiveOrder.orderNumber}
                      </h2>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      {currentActiveOrder.tableName || 'Dine-In'} &bull; Started at{' '}
                      {new Date(currentActiveOrder.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>

                  <span className="px-3 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/40 rounded-full text-xs font-black uppercase">
                    Kitchen Active
                  </span>
                </div>

                {/* Progress Visual Tracker */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex justify-between text-xs font-bold text-slate-300">
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Order Sent
                    </span>
                    <span className="text-amber-400 flex items-center gap-1">
                      <RefreshCw className="w-4 h-4 animate-spin" /> Preparing
                    </span>
                    <span className="text-slate-500">Ready to Serve</span>
                  </div>
                  <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden p-0.5 border border-slate-800">
                    <div className="bg-gradient-to-r from-emerald-500 to-amber-500 h-full rounded-full w-2/3 transition-all duration-500" />
                  </div>
                </div>

                {/* Ordered Items List */}
                <div className="space-y-3">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">
                    Dishes Being Prepared ({currentActiveOrder.items.length})
                  </h3>
                  <div className="divide-y divide-slate-850 bg-slate-950/60 rounded-2xl border border-slate-800 p-3">
                    {currentActiveOrder.items.map((item, idx) => (
                      <div key={idx} className="py-2.5 flex justify-between items-center text-xs">
                        <div>
                          <div className="font-bold text-slate-200">
                            {item.nameEn}{' '}
                            <span className="text-amber-400 font-black">x{item.quantity}</span>
                          </div>
                          {item.note && (
                            <div className="text-[10px] text-amber-300/80 italic">
                              Note: {item.note}
                            </div>
                          )}
                        </div>
                        <div className="text-right">
                          <span className="font-bold text-slate-300">
                            ₹{item.price * item.quantity}
                          </span>
                          <span className="block text-[10px] text-emerald-400 font-extrabold">
                            {item.kotPrinted ? 'Sent to Kitchen' : 'Queued'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Order Summary Financials */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Subtotal</span>
                    <span className="font-bold text-slate-200">
                      ₹{currentActiveOrder.subtotal}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Tax & Service</span>
                    <span className="font-bold text-slate-200">₹0</span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-amber-400 pt-2 border-t border-slate-800">
                    <span>Total Bill</span>
                    <span>₹{currentActiveOrder.finalTotal}</span>
                  </div>
                </div>

                {/* Repeat QR Order Action */}
                <button
                  onClick={() => setActiveTab('menu')}
                  className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-3 rounded-2xl text-xs uppercase tracking-wide transition shadow-xl flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add More Items to Table Order
                </button>
              </div>
            ) : (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-4">
                <div className="w-16 h-16 bg-slate-800 text-amber-400 rounded-3xl flex items-center justify-center mx-auto">
                  <ShoppingCart className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-200">No Active Order Yet</h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                    Browse the menu and place your first order. Your items will go directly to the
                    Kitchen!
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('menu')}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-6 py-2.5 rounded-xl text-xs shadow-lg"
                >
                  Browse Menu & Order
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* FLOATING BOTTOM CART BAR */}
      {/* ======================================================== */}
      {cart.length > 0 && !showCartDrawer && (
        <div className="fixed bottom-4 left-0 right-0 z-40 px-4">
          <div className="max-w-lg mx-auto bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-2xl p-3.5 shadow-2xl flex items-center justify-between gap-3 cursor-pointer transition active:scale-[0.99]">
            <div className="flex items-center gap-3">
              <div className="bg-slate-950 text-amber-400 px-3 py-1.5 rounded-xl text-xs font-black">
                {cartTotalItems} {cartTotalItems === 1 ? 'Item' : 'Items'}
              </div>
              <div>
                <div className="text-xs font-extrabold uppercase opacity-80">Total Amount</div>
                <div className="text-base font-black">₹{cartTotalAmount}</div>
              </div>
            </div>

            <button
              onClick={() => setShowCartDrawer(true)}
              className="bg-slate-950 hover:bg-slate-900 text-amber-400 font-black px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow-lg"
            >
              <span>View Cart</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* ITEM CUSTOMIZATION MODAL */}
      {/* ======================================================== */}
      {selectedCustomizingItem && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in slide-in-from-bottom duration-300">
            <div className="flex justify-between items-start border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-100">
                  {selectedCustomizingItem.nameEn}
                </h3>
                <p className="text-xs text-amber-400 font-bold mt-0.5">
                  ₹{selectedCustomizingItem.price} &bull; {selectedCustomizingItem.category}
                </p>
              </div>
              <button
                onClick={() => setSelectedCustomizingItem(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quantity Selector */}
            <div className="flex justify-between items-center bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <span className="text-xs font-bold text-slate-300">Quantity</span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCustomizingQty((q) => Math.max(1, q - 1))}
                  className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 flex items-center justify-center font-bold"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="text-base font-black text-amber-400">{customizingQty}</span>
                <button
                  onClick={() => setCustomizingQty((q) => q + 1)}
                  className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 flex items-center justify-center font-bold"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Special Instruction Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                Special Instructions (Optional)
              </label>
              <textarea
                value={customizingNote}
                onChange={(e) => setCustomizingNote(e.target.value)}
                placeholder="e.g. Less oil, extra spicy, no garlic..."
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Submit Add to Cart */}
            <button
              onClick={() => {
                addToCart(selectedCustomizingItem, customizingQty, customizingNote);
                setSelectedCustomizingItem(null);
              }}
              className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-3 rounded-2xl text-xs uppercase tracking-wide transition shadow-xl"
            >
              Add To Order (₹{selectedCustomizingItem.price * customizingQty})
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SLIDE-UP CART DRAWER */}
      {/* ======================================================== */}
      {showCartDrawer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-end justify-center p-0">
          <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl max-w-lg w-full max-h-[90vh] flex flex-col p-5 space-y-4 shadow-2xl animate-in slide-in-from-bottom duration-300">
            {/* Cart Drawer Header */}
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-amber-400" />
                <h3 className="text-lg font-black text-slate-100">Your Order Cart</h3>
              </div>
              <button
                onClick={() => setShowCartDrawer(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items List */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {cart.map((ci) => (
                <div
                  key={ci.id}
                  className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex justify-between items-center gap-3 text-xs"
                >
                  <div className="space-y-0.5 flex-1">
                    <div className="font-black text-slate-100">{ci.nameEn}</div>
                    <div className="text-amber-400 font-bold">₹{ci.price} each</div>
                    {ci.note && (
                      <div className="text-[10px] text-slate-400 italic">Note: {ci.note}</div>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateCartQty(ci.id, -1)}
                      className="w-7 h-7 rounded-lg bg-slate-800 text-amber-400 flex items-center justify-center font-bold"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="font-black text-slate-200 px-1">{ci.quantity}</span>
                    <button
                      onClick={() => updateCartQty(ci.id, 1)}
                      className="w-7 h-7 rounded-lg bg-slate-800 text-amber-400 flex items-center justify-center font-bold"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Settings Form */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-3 text-xs">
              {/* Order Mode Selection */}
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-400 uppercase">Fulfillment Mode</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setOrderMode('dine_in')}
                    className={`px-2.5 py-1 rounded-lg font-bold transition ${
                      orderMode === 'dine_in'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    Dine-In
                  </button>
                  <button
                    onClick={() => setOrderMode('takeaway')}
                    className={`px-2.5 py-1 rounded-lg font-bold transition ${
                      orderMode === 'takeaway'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    Takeaway
                  </button>
                  <button
                    onClick={() => setOrderMode('delivery')}
                    className={`px-2.5 py-1 rounded-lg font-bold transition ${
                      orderMode === 'delivery'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    Delivery
                  </button>
                </div>
              </div>

              {/* Guest / Contact Inputs */}
              {orderMode === 'dine_in' && (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-0.5">
                      Selected Table
                    </label>
                    <div className="bg-slate-900 border border-slate-800 p-2 rounded-xl text-amber-400 font-extrabold">
                      {selectedTable ? selectedTable.name : 'Table 1'}
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 block mb-0.5">
                      Guests (Pax)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={guestCount}
                      onChange={(e) => setGuestCount(Number(e.target.value) || 1)}
                      className="w-full bg-slate-900 border border-slate-800 p-2 rounded-xl text-slate-100 font-bold focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {/* Customer Mobile for Takeaway/Delivery */}
              {(orderMode === 'takeaway' || orderMode === 'delivery') && (
                <div className="space-y-2 pt-1">
                  <input
                    type="text"
                    placeholder="Customer Name"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 p-2 rounded-xl text-slate-100 focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="Customer Mobile Number"
                    value={customerMobile}
                    onChange={(e) => setCustomerMobile(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 p-2 rounded-xl text-slate-100 focus:outline-none"
                  />
                  {orderMode === 'delivery' && (
                    <textarea
                      placeholder="Delivery Address"
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      rows={2}
                      className="w-full bg-slate-900 border border-slate-800 p-2 rounded-xl text-slate-100 focus:outline-none"
                    />
                  )}
                </div>
              )}
            </div>

            {/* Total Financial Summary & Submit Button */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <div className="flex justify-between items-center font-black text-sm text-slate-100">
                <span>Total Amount Payable</span>
                <span className="text-amber-400 text-lg">₹{cartTotalAmount}</span>
              </div>

              <button
                onClick={handlePlaceOrder}
                disabled={isSubmitting}
                className="w-full bg-amber-500 hover:bg-amber-400 disabled:bg-slate-700 text-slate-950 font-black py-3.5 rounded-2xl text-xs uppercase tracking-wide transition shadow-xl flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Sending Order to Kitchen...
                  </>
                ) : (
                  <>
                    <Utensils className="w-4 h-4" />
                    {currentActiveOrder
                      ? 'Add To Table Order & Send KOT'
                      : 'Place Order & Send To Kitchen'}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
