import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { useApp } from '../../context/AppContext';
import { Table, Section } from '../../types';
import { RESTAURANT_CONFIG } from '../../data/restaurantConfig';
import {
  QrCode,
  X,
  Printer,
  Download,
  ExternalLink,
  Check,
  Sparkles,
  Layers,
  Building2,
  Copy,
} from 'lucide-react';

interface QrCodeModalProps {
  onClose: () => void;
  onLaunchCustomerView?: (tableId: string) => void;
}

export const QrCodeModal: React.FC<QrCodeModalProps> = ({
  onClose,
  onLaunchCustomerView,
}) => {
  const { tables, sections } = useApp();

  const [selectedTableId, setSelectedTableId] = useState<string>(
    tables.length > 0 ? tables[0].id : ''
  );
  const [selectedSectionId, setSelectedSectionId] = useState<string>('all');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const selectedTable = tables.find((t) => t.id === selectedTableId) || tables[0];
  const tableSection = sections.find((s) => s.id === selectedTable?.sectionId);

  // Generate QR code data URL whenever selectedTableId changes
  useEffect(() => {
    if (!selectedTable) return;

    const appBaseUrl = window.location.origin + window.location.pathname;
    const qrTargetUrl = `${appBaseUrl}?qrTable=${encodeURIComponent(selectedTable.id)}&sec=${encodeURIComponent(selectedTable.sectionId)}`;

    QRCode.toDataURL(
      qrTargetUrl,
      {
        width: 300,
        margin: 2,
        color: {
          dark: '#0f172a', // Slate-900
          light: '#ffffff',
        },
      },
      (err, url) => {
        if (!err && url) {
          setQrDataUrl(url);
        }
      }
    );
  }, [selectedTable]);

  // Filter tables by section if selected
  const filteredTables =
    selectedSectionId === 'all'
      ? tables
      : tables.filter((t) => t.sectionId === selectedSectionId);

  const handleCopyLink = () => {
    const appBaseUrl = window.location.origin + window.location.pathname;
    const url = `${appBaseUrl}?qrTable=${encodeURIComponent(selectedTable.id)}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrintCard = () => {
    if (!qrDataUrl || !selectedTable) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const cardHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Table QR Code - ${selectedTable.name}</title>
          <style>
            body {
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
              display: flex;
              align-items: center;
              justify-content: center;
              min-height: 100vh;
              background: #f8fafc;
              margin: 0;
            }
            .card {
              width: 320px;
              background: #ffffff;
              border: 3px solid #0f172a;
              border-radius: 24px;
              padding: 24px;
              text-align: center;
              box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            }
            .brand {
              font-size: 20px;
              font-weight: 900;
              color: #d97706;
              letter-spacing: 0.5px;
            }
            .tagline {
              font-size: 11px;
              color: #64748b;
              margin-top: 2px;
              margin-bottom: 16px;
            }
            .table-badge {
              display: inline-block;
              background: #0f172a;
              color: #fbbf24;
              font-size: 18px;
              font-weight: 900;
              padding: 6px 18px;
              border-radius: 9999px;
              margin-bottom: 16px;
            }
            .qr-img {
              width: 220px;
              height: 220px;
              border-radius: 16px;
              border: 1px solid #e2e8f0;
              margin: 0 auto 16px auto;
            }
            .instructions {
              font-size: 13px;
              font-weight: 700;
              color: #1e293b;
              margin-bottom: 4px;
            }
            .sub-instructions {
              font-size: 11px;
              color: #64748b;
            }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="brand">${RESTAURANT_CONFIG.name}</div>
            <div class="tagline">${RESTAURANT_CONFIG.tagline}</div>
            <div class="table-badge">TABLE ${selectedTable.name}</div>
            <br/>
            <img class="qr-img" src="${qrDataUrl}" alt="QR Code" />
            <div class="instructions">📱 SCAN QR TO ORDER FOOD</div>
            <div class="sub-instructions">Browse Digital Menu &bull; Call Staff &bull; Pay Dues</div>
          </div>
          <script>
            window.onload = () => {
              window.print();
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(cardHtml);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-6 space-y-6 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex justify-between items-center border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5 text-amber-400 font-bold">
            <QrCode className="w-6 h-6" />
            <div>
              <h2 className="text-lg font-black text-slate-100">Table QR Code Generator</h2>
              <p className="text-xs text-slate-400 font-medium">
                Unique QR codes for contactless dining & digital customer self-ordering
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Main Body */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 overflow-y-auto pr-1">
          {/* Left Column: Table Selection Controls */}
          <div className="space-y-4">
            {/* Section Filter */}
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">Floor Section</label>
              <select
                value={selectedSectionId}
                onChange={(e) => setSelectedSectionId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs font-bold text-slate-100 focus:outline-none focus:border-amber-400"
              >
                <option value="all">All Floor Sections</option>
                {sections.map((sec) => (
                  <option key={sec.id} value={sec.id}>
                    {sec.name} ({sec.tableCount} Tables)
                  </option>
                ))}
              </select>
            </div>

            {/* Table Selector Grid */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">Select Table</label>
              <div className="grid grid-cols-3 gap-2 max-h-56 overflow-y-auto p-1 bg-slate-950 rounded-2xl border border-slate-800">
                {filteredTables.map((tbl) => {
                  const isSel = tbl.id === selectedTableId;
                  return (
                    <button
                      key={tbl.id}
                      onClick={() => setSelectedTableId(tbl.id)}
                      className={`p-2.5 rounded-xl text-xs font-black transition border text-center ${
                        isSel
                          ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                          : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {tbl.name}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Table Details Info Box */}
            {selectedTable && (
              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1.5 text-xs">
                <div className="flex justify-between font-extrabold text-slate-300">
                  <span>Selected Table</span>
                  <span className="text-amber-400">{selectedTable.name}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Section</span>
                  <span>{tableSection ? tableSection.name : 'Main Section'}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Current Table Status</span>
                  <span className="capitalize font-bold text-emerald-400">
                    {selectedTable.status}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Printable QR Card Display */}
          <div className="flex flex-col items-center justify-center bg-slate-950 p-6 rounded-3xl border border-slate-800 space-y-4">
            <div className="bg-white text-slate-950 p-5 rounded-3xl text-center shadow-2xl border-2 border-slate-800 max-w-[240px] w-full">
              <div className="text-xs font-black text-amber-600 tracking-wider uppercase">
                {RESTAURANT_CONFIG.name}
              </div>
              <div className="text-[10px] text-slate-500 font-bold mb-2">
                {tableSection?.name || 'Dining Area'}
              </div>

              <div className="bg-slate-950 text-amber-400 font-black text-sm py-1 px-3 rounded-full inline-block mb-3">
                TABLE {selectedTable?.name}
              </div>

              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="QR Code"
                  className="w-40 h-40 mx-auto rounded-xl border border-slate-200"
                />
              ) : (
                <div className="w-40 h-40 bg-slate-100 rounded-xl mx-auto flex items-center justify-center text-xs text-slate-400 font-bold animate-pulse">
                  Generating QR...
                </div>
              )}

              <div className="text-[11px] font-black text-slate-900 mt-3">
                📱 SCAN TO VIEW MENU & ORDER
              </div>
              <div className="text-[9px] text-slate-500 font-semibold mt-0.5">
                No App Download Required
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 w-full">
              <button
                onClick={handlePrintCard}
                className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg"
              >
                <Printer className="w-4 h-4" />
                Print Card
              </button>

              <button
                onClick={handleCopyLink}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                title="Copy QR URL"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>

              {onLaunchCustomerView && (
                <button
                  onClick={() => {
                    onClose();
                    onLaunchCustomerView(selectedTable.id);
                  }}
                  className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/40 font-extrabold px-3 py-2.5 rounded-xl text-xs flex items-center gap-1.5"
                  title="Test Customer QR View"
                >
                  <ExternalLink className="w-4 h-4" />
                  Test View
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
