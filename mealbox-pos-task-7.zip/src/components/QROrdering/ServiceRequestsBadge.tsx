import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, Droplets, Receipt, CheckCircle, BellRing, X } from 'lucide-react';

export const ServiceRequestsBadge: React.FC = () => {
  const { serviceRequests, acknowledgeServiceRequest, completeServiceRequest } = useApp();
  const [showDropdown, setShowDropdown] = useState(false);

  const pendingRequests = serviceRequests.filter((r) => r.status !== 'completed');
  const count = pendingRequests.length;

  return (
    <div className="relative">
      {/* Alert Trigger Button */}
      <button
        onClick={() => setShowDropdown(!showDropdown)}
        className={`relative p-2 rounded-xl transition flex items-center gap-1.5 border font-bold text-xs ${
          count > 0
            ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 hover:bg-amber-500/30'
            : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
        }`}
        title="Pending Customer Service Calls"
      >
        <BellRing className={`w-4 h-4 ${count > 0 ? 'text-amber-400 animate-bounce' : ''}`} />
        <span className="hidden sm:inline">Table Alerts</span>
        {count > 0 && (
          <span className="bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded-full text-[10px] font-black shadow">
            {count}
          </span>
        )}
      </button>

      {/* Slide-down Request List */}
      {showDropdown && (
        <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-4 z-50 space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <div className="flex items-center gap-1.5 font-black text-xs text-amber-400">
              <Bell className="w-4 h-4" />
              <span>Table Service Calls ({count})</span>
            </div>
            <button
              onClick={() => setShowDropdown(false)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
            {pendingRequests.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-500 font-bold">
                No active service calls from tables
              </div>
            ) : (
              pendingRequests.map((req) => {
                const icon =
                  req.type === 'water' ? (
                    <Droplets className="w-4 h-4 text-sky-400" />
                  ) : req.type === 'bill' ? (
                    <Receipt className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <BellRing className="w-4 h-4 text-amber-400" />
                  );

                return (
                  <div
                    key={req.id}
                    className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-slate-900 rounded-lg">{icon}</div>
                      <div>
                        <div className="font-black text-slate-100">
                          Table {req.tableName}
                        </div>
                        <div className="text-[10px] text-amber-300 font-bold uppercase">
                          {req.type === 'water'
                            ? 'Water Request'
                            : req.type === 'bill'
                            ? 'Bill Request'
                            : 'Staff Called'}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => completeServiceRequest(req.id)}
                      className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-2.5 py-1 rounded-lg text-[10px] flex items-center gap-1 shadow"
                    >
                      <CheckCircle className="w-3 h-3" />
                      Done
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
