export type UserRole = 'owner' | 'manager' | 'cashier' | 'waiter' | 'kitchen';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  mobile: string;
  pin: string;
  assignedSections: string[]; // Section IDs
}

export interface Section {
  id: string;
  name: string;
  color: string; // Tailwind color name/hex for theme
  upiId: string;
  tablePrefix: string;
  tableCount: number;
}

export type TableStatus = 'empty' | 'vacant' | 'reserved' | 'occupied' | 'billing' | 'settled' | 'cleaning' | 'locked';

export interface TableHistoryLog {
  id: string;
  tableId: string;
  tableName: string;
  action:
    | 'occupied'
    | 'transfer'
    | 'merge'
    | 'split'
    | 'billed'
    | 'settled'
    | 'cleaning'
    | 'vacant'
    | 'reserved'
    | 'unreserved'
    | 'locked'
    | 'unlocked'
    | 'waiter_changed'
    | 'guest_count_changed'
    | 'note_updated';
  orderId?: string;
  orderNumber?: number;
  details: string;
  timestamp: string;
  userName?: string;
}

export interface Table {
  id: string;
  sectionId: string;
  name: string;
  status: TableStatus;
  currentOrderId?: string;
  occupiedSince?: string;
  isLocked?: boolean;
  lockedBy?: string;
  lockedReason?: string;
  tableNote?: string;
  reservedBy?: string;
  reservedMobile?: string;
  reservedTime?: string;
  reservedGuests?: number;
  reservedNote?: string;
  waiterId?: string;
  waiterName?: string;
  guestCount?: number;
}

export interface MenuItem {
  id: string;
  nameEn: string;
  nameHi: string;
  price: number; // default price
  sectionPrices: Record<string, number>; // sectionId -> price
  category: string;
  kotPrint: boolean; // if false, doesn't print on KOT (e.g. Water, Cold Drink)
  discountable: boolean; // if false, percentage discount doesn't apply
  active: boolean;
  sections?: string[]; // section IDs where available
  isVeg?: boolean;
  isSpicy?: boolean;
  isJain?: boolean;
  description?: string;
  imageUrl?: string;
  allergens?: string[];
  variants?: { name: string; price: number }[];
}

export interface ServiceRequest {
  id: string;
  tableId: string;
  tableName: string;
  sectionId?: string;
  sectionName?: string;
  type: 'waiter' | 'water' | 'bill' | 'custom';
  message?: string;
  status: 'pending' | 'acknowledged' | 'completed';
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  mobile: string;
  whatsapp?: string;
  address?: string;
  dues: number; // pending amount customer owes restaurant
  advance: number; // credit balance restaurant owes customer
  totalOrders: number;
  totalSpent: number;
  createdAt: string;
  lastVisit: string;
}

export interface Staff {
  id: string;
  name: string;
  mobile: string;
  role: UserRole;
  salary: number; // monthly salary
  advanceTotal: number;
  duesTotal: number;
  joinDate: string;
  photoUrl?: string;
  assignedSections: string[];
}

export interface OrderItem {
  id: string;
  menuItemId?: string;
  nameEn: string;
  nameHi: string;
  price: number;
  quantity: number;
  note?: string; // Special instruction (Spicy, Less Oil, etc.)
  kotPrint: boolean;
  kotPrinted: boolean;
  isNew?: boolean; // Tagged true when added to existing order
}

export type OrderMode = 'dine_in' | 'takeaway' | 'delivery' | 'reservation' | 'free';

export type OrderStatus = 'active' | 'settled' | 'void';

export interface SplitPaymentDetail {
  method: 'cash' | 'upi' | 'card' | 'dues' | 'credit';
  amount: number;
}

export interface VoidedKotItem {
  nameEn: string;
  nameHi: string;
  quantity: number;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: number;
  sectionId: string;
  sectionName: string;
  tableId?: string;
  tableName?: string;
  mode: OrderMode;
  status: OrderStatus;
  customerId?: string;
  customerName?: string;
  customerMobile?: string;
  customerAddress?: string;
  waiterId?: string;
  waiterName?: string;
  guestCount?: number;
  reservationTime?: string;
  items: OrderItem[];
  subtotal: number;
  attachedDues: number;
  appliedCredit: number;
  discountPercent: number;
  discountAmount: number;
  advanceDeposit?: number; // Advance/Deposit amount (e.g. 500) entered before/during ordering
  finalTotal: number;
  paidAmount: number;
  paymentMode?: 'cash' | 'upi' | 'card' | 'split' | 'dues' | 'credit';
  splitDetails?: SplitPaymentDetail[];
  shortfallHandling?: 'dues' | 'discount';
  excessHandling?: 'return' | 'credit' | 'tip';
  createdAt: string; // ISO string
  paidAt?: string;
  kotPrintedAt?: string;
  kotTokenCount?: number;
  pendingVoidedKotItems?: VoidedKotItem[];
  voidReason?: string;
  voidedBy?: string;
  voidedAt?: string;
}

export interface Expense {
  id: string;
  sectionId: string;
  category: 'Goods' | 'Vendor' | 'Staff' | 'Rent' | 'Electricity' | 'Other';
  description: string;
  amount: number;
  mode: 'cash' | 'online';
  date: string; // ISO string YYYY-MM-DD
  staffId?: string;
  createdBy: string;
}

export interface Denominations {
  c500: number;
  c200: number;
  c100: number;
  c50: number;
  c20: number;
  c10: number;
  coins: number;
}

export interface DaySession {
  id: string;
  sectionId: string;
  date: string; // YYYY-MM-DD
  status: 'open' | 'closed';
  openingCash: number;
  openingDenominations: Denominations;
  closingCash?: number;
  closingDenominations?: Denominations;
  expectedCash?: number;
  discrepancy?: number;
  openedBy: string;
  closedBy?: string;
  openedAt: string;
  closedAt?: string;
}

export interface InventoryItem {
  id: string;
  itemName: string;
  openingStock: number;
  quantityIn: number;
  quantityOut: number;
  stock: number; // openingStock + in - out
  costPrice: number;
  sellPrice: number;
  unit: string;
  lowStockThreshold: number;
}

export interface InventoryLog {
  id: string;
  inventoryId: string;
  itemName: string;
  type: 'in' | 'out';
  quantity: number;
  orderId?: string;
  supplier?: string;
  cost?: number;
  date: string;
}

export type InventoryUnit = 'kg' | 'g' | 'litre' | 'ml' | 'piece' | 'packet' | 'box' | 'dozen' | string;
export type UnitType = InventoryUnit;
export type WasteReason = string;

export type RawMaterialCategory =
  | 'Dairy'
  | 'Spices & Condiments'
  | 'Vegetables & Produce'
  | 'Meat & Poultry'
  | 'Grains & Pulses'
  | 'Beverages & Packaged'
  | 'Packaging & Supplies'
  | 'Other'
  | string;

export interface RawMaterial {
  id: string;
  name: string;
  category: RawMaterialCategory;
  unit: InventoryUnit;
  currentStock: number;
  lowStockThreshold: number;
  reorderLevel?: number;
  unitCostPrice: number; // Cost price per base unit
  supplierId?: string;
  supplierName?: string;
  updatedAt: string;
}

export interface RecipeIngredient {
  rawMaterialId: string;
  rawMaterialName?: string;
  quantity: number;
  unit: InventoryUnit;
}

export interface Recipe {
  id: string;
  menuItemId: string;
  menuItemName: string;
  ingredients: RecipeIngredient[];
  yieldServings: number;
  preparationNotes?: string;
  totalCost: number; // Computed cost per serving
  updatedAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  companyName?: string;
  contactPerson: string;
  mobile: string;
  phone?: string;
  email?: string;
  gstin?: string;
  address?: string;
  balanceDue: number;
  paymentTerms?: string;
  createdAt: string;
}

export interface PurchaseEntryItem {
  rawMaterialId: string;
  rawMaterialName: string;
  quantity: number;
  unit: InventoryUnit;
  unitCostPrice: number;
  totalCost: number;
  batchNumber?: string;
  expiryDate?: string;
}

export type PurchaseItem = PurchaseEntryItem;

export interface PurchaseEntry {
  id: string;
  purchaseNumber: string;
  supplierId: string;
  supplierName: string;
  invoiceNumber?: string;
  invoiceDate: string;
  items: PurchaseEntryItem[];
  totalAmount: number;
  paidAmount: number;
  paymentMode: 'cash' | 'online' | 'credit';
  createdAt: string;
  createdBy: string;
}

export type MovementType =
  | 'purchase_in'
  | 'sale_deduction'
  | 'sale_restoration'
  | 'waste_out'
  | 'manual_adjustment'
  | 'stock_out';

export interface StockMovementLog {
  id: string;
  rawMaterialId: string;
  rawMaterialName: string;
  type: MovementType;
  quantity: number;
  unit: InventoryUnit;
  previousStock: number;
  newStock: number;
  unitCostPrice: number;
  totalCost: number;
  referenceId?: string; // Order ID / Purchase ID / Waste ID / Audit ID
  notes?: string;
  timestamp: string;
  createdBy: string;
}

export interface WasteEntry {
  id: string;
  type: 'raw_material' | 'menu_item';
  referenceId: string; // rawMaterialId or menuItemId
  name: string;
  quantity: number;
  unit: InventoryUnit;
  reason: 'Expired' | 'Spoiled' | 'Spilled / Damaged' | 'Cooking Error' | 'Returned / Rejected' | 'Other';
  estimatedCost: number;
  notes?: string;
  createdAt: string;
  createdBy: string;
}

export interface PhysicalStockAuditItem {
  rawMaterialId: string;
  rawMaterialName: string;
  unit: InventoryUnit;
  systemStock: number;
  physicalStock: number;
  variance: number; // physicalStock - systemStock
  unitCost: number;
  varianceValue: number; // variance * unitCost
  reason?: string;
}

export interface PhysicalStockAudit {
  id: string;
  auditDate: string;
  items: PhysicalStockAuditItem[];
  totalVarianceValue: number;
  auditedBy: string;
  notes?: string;
}

