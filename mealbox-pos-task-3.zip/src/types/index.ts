export type UserRole = 'owner' | 'manager' | 'cashier' | 'waiter' | 'kitchen';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  mobile: string;
  pin: string;
  assignedSections: string[]; // Section IDs
}

export interface Section {
  id: string;
  name: string;
  color: string; // Tailwind color name/hex for theme
  upiId: string;
  tablePrefix: string;
  tableCount: number;
}

export type TableStatus = 'empty' | 'vacant' | 'reserved' | 'occupied' | 'billing' | 'settled' | 'cleaning' | 'locked';

export interface TableHistoryLog {
  id: string;
  tableId: string;
  tableName: string;
  action:
    | 'occupied'
    | 'transfer'
    | 'merge'
    | 'split'
    | 'billed'
    | 'settled'
    | 'cleaning'
    | 'vacant'
    | 'reserved'
    | 'unreserved'
    | 'locked'
    | 'unlocked'
    | 'waiter_changed'
    | 'guest_count_changed'
    | 'note_updated';
  orderId?: string;
  orderNumber?: number;
  details: string;
  timestamp: string;
  userName?: string;
}

export interface Table {
  id: string;
  sectionId: string;
  name: string;
  status: TableStatus;
  currentOrderId?: string;
  occupiedSince?: string;
  isLocked?: boolean;
  lockedBy?: string;
  lockedReason?: string;
  tableNote?: string;
  reservedBy?: string;
  reservedMobile?: string;
  reservedTime?: string;
  reservedGuests?: number;
  reservedNote?: string;
  waiterId?: string;
  waiterName?: string;
  guestCount?: number;
}

export interface MenuItem {
  id: string;
  nameEn: string;
  nameHi: string;
  price: number; // default price
  sectionPrices: Record<string, number>; // sectionId -> price
  category: string;
  kotPrint: boolean; // if false, doesn't print on KOT (e.g. Water, Cold Drink)
  discountable: boolean; // if false, percentage discount doesn't apply
  active: boolean;
  sections?: string[]; // section IDs where available
}

export interface Customer {
  id: string;
  name: string;
  mobile: string;
  whatsapp?: string;
  address?: string;
  dues: number; // pending amount customer owes restaurant
  advance: number; // credit balance restaurant owes customer
  totalOrders: number;
  totalSpent: number;
  createdAt: string;
  lastVisit: string;
}

export interface Staff {
  id: string;
  name: string;
  mobile: string;
  role: UserRole;
  salary: number; // monthly salary
  advanceTotal: number;
  duesTotal: number;
  joinDate: string;
  photoUrl?: string;
  assignedSections: string[];
}

export interface OrderItem {
  id: string;
  menuItemId?: string;
  nameEn: string;
  nameHi: string;
  price: number;
  quantity: number;
  note?: string; // Special instruction (Spicy, Less Oil, etc.)
  kotPrint: boolean;
  kotPrinted: boolean;
  isNew?: boolean; // Tagged true when added to existing order
}

export type OrderMode = 'dine_in' | 'takeaway' | 'delivery' | 'reservation' | 'free';

export type OrderStatus = 'active' | 'settled' | 'void';

export interface SplitPaymentDetail {
  method: 'cash' | 'upi' | 'card' | 'dues' | 'credit';
  amount: number;
}

export interface VoidedKotItem {
  nameEn: string;
  nameHi: string;
  quantity: number;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: number;
  sectionId: string;
  sectionName: string;
  tableId?: string;
  tableName?: string;
  mode: OrderMode;
  status: OrderStatus;
  customerId?: string;
  customerName?: string;
  customerMobile?: string;
  customerAddress?: string;
  waiterId?: string;
  waiterName?: string;
  guestCount?: number;
  reservationTime?: string;
  items: OrderItem[];
  subtotal: number;
  attachedDues: number;
  appliedCredit: number;
  discountPercent: number;
  discountAmount: number;
  advanceDeposit?: number; // Advance/Deposit amount (e.g. 500) entered before/during ordering
  finalTotal: number;
  paidAmount: number;
  paymentMode?: 'cash' | 'upi' | 'card' | 'split' | 'dues' | 'credit';
  splitDetails?: SplitPaymentDetail[];
  shortfallHandling?: 'dues' | 'discount';
  excessHandling?: 'return' | 'credit' | 'tip';
  createdAt: string; // ISO string
  paidAt?: string;
  kotPrintedAt?: string;
  kotTokenCount?: number;
  pendingVoidedKotItems?: VoidedKotItem[];
  voidReason?: string;
  voidedBy?: string;
  voidedAt?: string;
}

export interface Expense {
  id: string;
  sectionId: string;
  category: 'Goods' | 'Vendor' | 'Staff' | 'Rent' | 'Electricity' | 'Other';
  description: string;
  amount: number;
  mode: 'cash' | 'online';
  date: string; // ISO string YYYY-MM-DD
  staffId?: string;
  createdBy: string;
}

export interface Denominations {
  c500: number;
  c200: number;
  c100: number;
  c50: number;
  c20: number;
  c10: number;
  coins: number;
}

export interface DaySession {
  id: string;
  sectionId: string;
  date: string; // YYYY-MM-DD
  status: 'open' | 'closed';
  openingCash: number;
  openingDenominations: Denominations;
  closingCash?: number;
  closingDenominations?: Denominations;
  expectedCash?: number;
  discrepancy?: number;
  openedBy: string;
  closedBy?: string;
  openedAt: string;
  closedAt?: string;
}

export interface InventoryItem {
  id: string;
  itemName: string;
  openingStock: number;
  quantityIn: number;
  quantityOut: number;
  stock: number; // openingStock + in - out
  costPrice: number;
  sellPrice: number;
  unit: string;
  lowStockThreshold: number;
}

export interface InventoryLog {
  id: string;
  inventoryId: string;
  itemName: string;
  type: 'in' | 'out';
  quantity: number;
  orderId?: string;
  supplier?: string;
  cost?: number;
  date: string;
}
