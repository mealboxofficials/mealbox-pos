import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Table, TableStatus } from '../../types';
import {
  X,
  ArrowRightLeft,
  GitMerge,
  Columns,
  Lock,
  Unlock,
  CalendarCheck,
  UserCheck,
  Users,
  StickyNote,
  History,
  CheckCircle2,
  Sparkles,
  ShieldAlert,
  Clock,
  ChevronRight,
  AlertCircle,
  XCircle,
  Check,
} from 'lucide-react';

interface TableLifecycleModalProps {
  table: Table;
  initialTab?: 'actions' | 'transfer' | 'merge' | 'split' | 'reserve' | 'lock' | 'waiter' | 'history';
  onClose: () => void;
  onOpenCartForTable?: (table: Table) => void;
}

export const TableLifecycleModal: React.FC<TableLifecycleModalProps> = ({
  table,
  initialTab = 'actions',
  onClose,
  onOpenCartForTable,
}) => {
  const {
    tables,
    sections,
    staff,
    getOrderForTable,
    tableHistoryLogs,
    transferTable,
    mergeTables,
    splitTable,
    lockTable,
    unlockTable,
    reserveTable,
    cancelReservation,
    seatReservedTable,
    changeTableWaiter,
    changeTableGuestCount,
    updateTableNote,
    setTableStatus,
  } = useApp();

  const [activeTab, setActiveTab] = useState<string>(initialTab);

  // Transfer State
  const [targetTransferTableId, setTargetTransferTableId] = useState<string>('');

  // Merge State
  const [targetMergeTableId, setTargetMergeTableId] = useState<string>('');

  // Split State
  const [targetSplitTableId, setTargetSplitTableId] = useState<string>('');
  const [splitItemQuantities, setSplitItemQuantities] = useState<Record<string, number>>({});

  // Reserve State
  const [resName, setResName] = useState(table.reservedBy || '');
  const [resMobile, setResMobile] = useState(table.reservedMobile || '');
  const [resTime, setResTime] = useState(table.reservedTime || '19:30');
  const [resGuests, setResGuests] = useState(table.reservedGuests || 2);
  const [resNote, setResNote] = useState(table.reservedNote || '');

  // Lock State
  const [lockReason, setLockReason] = useState(table.lockedReason || 'Reserved for VIP');

  // Waiter & Guest State
  const [selectedWaiterId, setSelectedWaiterId] = useState(table.waiterId || '');
  const [guestCountInput, setGuestCountInput] = useState(table.guestCount || 2);

  // Note State
  const [tableNoteInput, setTableNoteInput] = useState(table.tableNote || '');

  const activeOrder = getOrderForTable(table.id);
  const tableSection = sections.find((s) => s.id === table.sectionId);

  // Available vacant tables for transfer/split
  const vacantTables = tables.filter(
    (t) => t.id !== table.id && (t.status === 'empty' || t.status === 'vacant') && !t.isLocked
  );

  // Available occupied tables for merge
  const occupiedTables = tables.filter(
    (t) => t.id !== table.id && (t.status === 'occupied' || t.status === 'billing')
  );

  // Filtered history for this table
  const historyForTable = tableHistoryLogs.filter((l) => l.tableId === table.id);

  // Handle Transfer
  const handlePerformTransfer = () => {
    if (!targetTransferTableId) return;
    const ok = transferTable(table.id, targetTransferTableId);
    if (ok) onClose();
  };

  // Handle Merge
  const handlePerformMerge = () => {
    if (!targetMergeTableId) return;
    const ok = mergeTables(table.id, targetMergeTableId);
    if (ok) onClose();
  };

  // Handle Split
  const handlePerformSplit = () => {
    if (!targetSplitTableId) return;
    const itemsToMove = Object.entries(splitItemQuantities)
      .filter(([_, qty]) => Number(qty) > 0)
      .map(([itemId, quantity]) => ({ itemId, quantity: Number(quantity) }));

    if (itemsToMove.length === 0) return;
    const ok = splitTable(table.id, targetSplitTableId, itemsToMove);
    if (ok) onClose();
  };

  // Handle Reserve Submit
  const handlePerformReserve = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resName || !resMobile) return;
    reserveTable(table.id, {
      reservedBy: resName,
      reservedMobile: resMobile,
      reservedTime: resTime,
      reservedGuests: resGuests,
      reservedNote: resNote,
    });
    onClose();
  };

  // Handle Lock Submit
  const handlePerformLock = () => {
    lockTable(table.id, lockReason);
    onClose();
  };

  // Handle Unlock
  const handlePerformUnlock = () => {
    unlockTable(table.id);
    onClose();
  };

  // Handle Waiter / Guest submit
  const handlePerformWaiterGuest = () => {
    if (selectedWaiterId) {
      const selectedStaff = staff.find((s) => s.id === selectedWaiterId);
      if (selectedStaff) {
        changeTableWaiter(table.id, selectedStaff.id, selectedStaff.name);
      }
    }
    if (guestCountInput > 0) {
      changeTableGuestCount(table.id, guestCountInput);
    }
    onClose();
  };

  // Handle Note submit
  const handlePerformSaveNote = () => {
    updateTableNote(table.id, tableNoteInput);
    onClose();
  };

  const getStatusBadge = (status: TableStatus) => {
    switch (status) {
      case 'occupied':
        return <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full text-xs font-bold uppercase">Occupied</span>;
      case 'billing':
        return <span className="px-2.5 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-full text-xs font-bold uppercase">Bill Printed</span>;
      case 'settled':
        return <span className="px-2.5 py-1 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-full text-xs font-bold uppercase">Settled / Paid</span>;
      case 'cleaning':
        return <span className="px-2.5 py-1 bg-purple-500/20 text-purple-400 border border-purple-500/30 rounded-full text-xs font-bold uppercase">Needs Cleaning</span>;
      case 'reserved':
        return <span className="px-2.5 py-1 bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-full text-xs font-bold uppercase">Reserved</span>;
      case 'locked':
        return <span className="px-2.5 py-1 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-full text-xs font-bold uppercase">Locked</span>;
      default:
        return <span className="px-2.5 py-1 bg-slate-800 text-slate-300 border border-slate-700 rounded-full text-xs font-bold uppercase">Vacant</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-900/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-extrabold text-base">
              {table.name}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-slate-100 font-bold text-lg">{table.name} Operations</h2>
                {getStatusBadge(table.status)}
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                <span>Section: {tableSection?.name || 'General'}</span>
                {activeOrder && <span>• Order #{activeOrder.orderNumber} (₹{activeOrder.finalTotal})</span>}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Nav Tabs */}
        <div className="px-4 border-b border-slate-800 bg-slate-950/50 flex space-x-1 overflow-x-auto scrollbar-none py-2 text-xs font-semibold">
          {[
            { id: 'actions', label: 'Quick Actions', icon: Sparkles },
            { id: 'transfer', label: 'Transfer Table', icon: ArrowRightLeft, disabled: !activeOrder },
            { id: 'merge', label: 'Merge Tables', icon: GitMerge, disabled: !activeOrder },
            { id: 'split', label: 'Split Table', icon: Columns, disabled: !activeOrder || activeOrder.items.length <= 1 },
            { id: 'reserve', label: 'Reserve', icon: CalendarCheck, disabled: table.status === 'occupied' || table.status === 'billing' },
            { id: 'lock', label: table.isLocked ? 'Unlock Table' : 'Lock Table', icon: table.isLocked ? Unlock : Lock },
            { id: 'waiter', label: 'Waiter & Guests', icon: UserCheck },
            { id: 'history', label: 'Table Audit Trail', icon: History },
          ].map((tabItem) => {
            const Icon = tabItem.icon;
            return (
              <button
                key={tabItem.id}
                disabled={tabItem.disabled}
                onClick={() => setActiveTab(tabItem.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition ${
                  activeTab === tabItem.id
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : tabItem.disabled
                    ? 'text-slate-600 opacity-50 cursor-not-allowed'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tabItem.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* TAB 1: QUICK ACTIONS */}
          {activeTab === 'actions' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* View/Open Order */}
                {activeOrder && (
                  <button
                    onClick={() => {
                      onClose();
                      if (onOpenCartForTable) onOpenCartForTable(table);
                    }}
                    className="p-3.5 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-left transition flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-emerald-400 font-bold text-sm flex items-center gap-1.5">
                        <span>Open Active Order Cart</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        Order #{activeOrder.orderNumber} • ₹{activeOrder.finalTotal}
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-1 transition" />
                  </button>
                )}

                {/* Seat Reserved Guest */}
                {table.status === 'reserved' && (
                  <button
                    onClick={() => {
                      seatReservedTable(table.id);
                      onClose();
                      if (onOpenCartForTable) onOpenCartForTable(table);
                    }}
                    className="p-3.5 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-xl text-left transition flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-cyan-400 font-bold text-sm">Seat Reserved Guests</div>
                      <p className="text-xs text-slate-400 mt-1">
                        {table.reservedBy} ({table.reservedGuests} guests)
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-cyan-400 group-hover:translate-x-1 transition" />
                  </button>
                )}

                {/* Mark Cleaning -> Vacant */}
                {table.status === 'settled' && (
                  <button
                    onClick={() => setTableStatus(table.id, 'cleaning')}
                    className="p-3.5 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 rounded-xl text-left transition flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-purple-400 font-bold text-sm">Mark for Cleaning</div>
                      <p className="text-xs text-slate-400 mt-1">Busser/Cleaner notified to sanitize table</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-purple-400 group-hover:translate-x-1 transition" />
                  </button>
                )}

                {/* Mark Ready / Vacant */}
                {(table.status === 'cleaning' || table.status === 'settled') && (
                  <button
                    onClick={() => {
                      setTableStatus(table.id, 'empty');
                      onClose();
                    }}
                    className="p-3.5 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-xl text-left transition flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-emerald-400 font-bold text-sm">Mark Vacant & Ready</div>
                      <p className="text-xs text-slate-400 mt-1">Clear table status for new guests</p>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition" />
                  </button>
                )}

                {/* Transfer Table Shortcut */}
                {activeOrder && (
                  <button
                    onClick={() => setActiveTab('transfer')}
                    className="p-3.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-xl text-left transition flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-slate-200 font-bold text-sm flex items-center gap-1.5">
                        <ArrowRightLeft className="w-4 h-4 text-amber-400" />
                        <span>Transfer Order</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">Move order to another vacant table</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400 group-hover:translate-x-1 transition" />
                  </button>
                )}

                {/* Merge Tables Shortcut */}
                {activeOrder && (
                  <button
                    onClick={() => setActiveTab('merge')}
                    className="p-3.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-xl text-left transition flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-slate-200 font-bold text-sm flex items-center gap-1.5">
                        <GitMerge className="w-4 h-4 text-blue-400" />
                        <span>Merge Table</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">Combine items with another active table</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400 group-hover:translate-x-1 transition" />
                  </button>
                )}
              </div>

              {/* Table Note Input */}
              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-3.5 space-y-2">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <StickyNote className="w-4 h-4 text-amber-400" />
                  <span>Table Note / Special Instructions</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={tableNoteInput}
                    onChange={(e) => setTableNoteInput(e.target.value)}
                    placeholder="e.g. High chair needed, Anniversary couple..."
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
                  />
                  <button
                    onClick={handlePerformSaveNote}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TRANSFER TABLE */}
          {activeTab === 'transfer' && (
            <div className="space-y-4">
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300">
                Transfer active <strong>Order #{activeOrder?.orderNumber}</strong> from <strong>{table.name}</strong> to a vacant table.
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Select Destination Vacant Table
                </label>
                {vacantTables.length === 0 ? (
                  <p className="text-xs text-rose-400 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl">
                    No vacant tables available for transfer in any section.
                  </p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {vacantTables.map((vt) => {
                      const sec = sections.find((s) => s.id === vt.sectionId);
                      const isSelected = targetTransferTableId === vt.id;
                      return (
                        <button
                          key={vt.id}
                          onClick={() => setTargetTransferTableId(vt.id)}
                          className={`p-3 rounded-xl border text-left transition ${
                            isSelected
                              ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                              : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-750'
                          }`}
                        >
                          <div className="text-sm font-bold">{vt.name}</div>
                          <div className="text-[10px] text-slate-400">{sec?.name || 'Main Hall'}</div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => setActiveTab('actions')}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  disabled={!targetTransferTableId}
                  onClick={handlePerformTransfer}
                  className="px-5 py-2 bg-amber-500 disabled:opacity-50 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                  <span>Execute Transfer</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: MERGE TABLES */}
          {activeTab === 'merge' && (
            <div className="space-y-4">
              <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-xl text-xs text-blue-300">
                Merge items from <strong>{table.name} (Order #{activeOrder?.orderNumber})</strong> into another occupied table's order.
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Select Target Occupied Table to Merge INTO
                </label>
                {occupiedTables.length === 0 ? (
                  <p className="text-xs text-rose-400 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl">
                    No other occupied tables available to merge into.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {occupiedTables.map((ot) => {
                      const otOrd = getOrderForTable(ot.id);
                      const isSelected = targetMergeTableId === ot.id;
                      return (
                        <button
                          key={ot.id}
                          onClick={() => setTargetMergeTableId(ot.id)}
                          className={`p-3 rounded-xl border text-left transition ${
                            isSelected
                              ? 'bg-blue-500/20 border-blue-500 text-blue-300 font-bold'
                              : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-750'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-bold">{ot.name}</span>
                            <span className="text-xs text-amber-400 font-bold">₹{otOrd?.finalTotal || 0}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 mt-1">
                            Order #{otOrd?.orderNumber || ''} • {otOrd?.items.length || 0} Items
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => setActiveTab('actions')}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  disabled={!targetMergeTableId}
                  onClick={handlePerformMerge}
                  className="px-5 py-2 bg-blue-500 disabled:opacity-50 hover:bg-blue-400 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <GitMerge className="w-4 h-4" />
                  <span>Execute Merge</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: SPLIT TABLE */}
          {activeTab === 'split' && (
            <div className="space-y-4">
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-xl text-xs text-purple-300">
                Select items from <strong>{table.name}</strong> to move to a new vacant table.
              </div>

              {/* Destination Vacant Table Picker */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  Select Target Vacant Table
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {vacantTables.map((vt) => (
                    <button
                      key={vt.id}
                      onClick={() => setTargetSplitTableId(vt.id)}
                      className={`p-2 rounded-lg border text-left text-xs font-bold transition ${
                        targetSplitTableId === vt.id
                          ? 'bg-purple-500/20 border-purple-500 text-purple-300'
                          : 'bg-slate-800 border-slate-700 text-slate-300'
                      }`}
                    >
                      {vt.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Items Selection with Quantity Steppers */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-2">
                  Items to Split
                </label>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {activeOrder?.items.map((item) => {
                    const currentQty = splitItemQuantities[item.id] || 0;
                    return (
                      <div
                        key={item.id}
                        className="p-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="font-bold text-slate-200">{item.nameEn}</div>
                          <div className="text-[10px] text-slate-400">
                            Available: {item.quantity} • ₹{item.price} each
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              setSplitItemQuantities((prev) => ({
                                ...prev,
                                [item.id]: Math.max(0, (prev[item.id] || 0) - 1),
                              }))
                            }
                            className="w-6 h-6 rounded bg-slate-700 hover:bg-slate-600 font-bold text-slate-200"
                          >
                            -
                          </button>
                          <span className="w-6 text-center font-bold text-amber-400">{currentQty}</span>
                          <button
                            onClick={() =>
                              setSplitItemQuantities((prev) => ({
                                ...prev,
                                [item.id]: Math.min(item.quantity, (prev[item.id] || 0) + 1),
                              }))
                            }
                            className="w-6 h-6 rounded bg-slate-700 hover:bg-slate-600 font-bold text-slate-200"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => setActiveTab('actions')}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  disabled={!targetSplitTableId || !Object.values(splitItemQuantities).some((q) => Number(q) > 0)}
                  onClick={handlePerformSplit}
                  className="px-5 py-2 bg-purple-500 disabled:opacity-50 hover:bg-purple-400 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <Columns className="w-4 h-4" />
                  <span>Execute Split</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: RESERVE */}
          {activeTab === 'reserve' && (
            <form onSubmit={handlePerformReserve} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Customer Name *</label>
                <input
                  type="text"
                  required
                  value={resName}
                  onChange={(e) => setResName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={resMobile}
                    onChange={(e) => setResMobile(e.target.value)}
                    placeholder="9876543210"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Reservation Time *</label>
                  <input
                    type="time"
                    required
                    value={resTime}
                    onChange={(e) => setResTime(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Guest Count</label>
                <input
                  type="number"
                  min="1"
                  max="20"
                  value={resGuests}
                  onChange={(e) => setResGuests(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Reservation Note / Request</label>
                <input
                  type="text"
                  value={resNote}
                  onChange={(e) => setResNote(e.target.value)}
                  placeholder="e.g. Corner table, Birthday celebration..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              {table.status === 'reserved' && (
                <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
                  <button
                    type="button"
                    onClick={() => {
                      cancelReservation(table.id);
                      onClose();
                    }}
                    className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-bold"
                  >
                    Cancel Existing Reservation
                  </button>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveTab('actions')}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold hover:bg-slate-700"
                >
                  Close
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold transition"
                >
                  Save Reservation
                </button>
              </div>
            </form>
          )}

          {/* TAB 6: LOCK / UNLOCK */}
          {activeTab === 'lock' && (
            <div className="space-y-4 text-xs">
              {table.isLocked ? (
                <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl space-y-3">
                  <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                    <Lock className="w-5 h-5" />
                    <span>Table Currently Locked</span>
                  </div>
                  <p className="text-slate-300">
                    Locked By: <strong>{table.lockedBy || 'Staff'}</strong>
                    <br />
                    Reason: <strong>{table.lockedReason || 'N/A'}</strong>
                  </p>
                  <button
                    onClick={handlePerformUnlock}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl transition flex items-center gap-1.5"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>Unlock Table Now</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <label className="font-bold text-slate-300 block mb-1">Lock Reason</label>
                    <input
                      type="text"
                      value={lockReason}
                      onChange={(e) => setLockReason(e.target.value)}
                      placeholder="e.g. Table damaged, Reserved for VIP party..."
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => setActiveTab('actions')}
                      className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl font-semibold"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handlePerformLock}
                      className="px-5 py-2 bg-rose-500 hover:bg-rose-400 text-white rounded-xl font-bold transition flex items-center gap-1.5"
                    >
                      <Lock className="w-4 h-4" />
                      <span>Lock Table</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 7: WAITER & GUESTS */}
          {activeTab === 'waiter' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Assign Waiter</label>
                <select
                  value={selectedWaiterId}
                  onChange={(e) => setSelectedWaiterId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
                >
                  <option value="">-- Unassigned Waiter --</option>
                  {staff.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Guest Count (Pax)</label>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setGuestCountInput((prev) => Math.max(1, prev - 1))}
                    className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-lg text-slate-200 border border-slate-700"
                  >
                    -
                  </button>
                  <span className="text-lg font-extrabold text-amber-400 px-4">{guestCountInput}</span>
                  <button
                    type="button"
                    onClick={() => setGuestCountInput((prev) => prev + 1)}
                    className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-lg text-slate-200 border border-slate-700"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => setActiveTab('actions')}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePerformWaiterGuest}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition"
                >
                  Save Changes
                </button>
              </div>
            </div>
          )}

          {/* TAB 8: HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <History className="w-4 h-4 text-amber-400" />
                <span>Audit History Logs ({historyForTable.length})</span>
              </h3>

              {historyForTable.length === 0 ? (
                <p className="text-xs text-slate-500 italic p-4 text-center border border-slate-800 rounded-xl">
                  No activity history logged for this table yet.
                </p>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {historyForTable.map((log) => (
                    <div
                      key={log.id}
                      className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between text-slate-300 font-bold">
                        <span className="uppercase text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-amber-400">
                          {log.action}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {log.userName}
                        </span>
                      </div>
                      <p className="text-slate-200">{log.details}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
