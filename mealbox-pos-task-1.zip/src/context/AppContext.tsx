import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  User,
  Section,
  Table,
  MenuItem,
  Customer,
  Staff,
  Order,
  OrderItem,
  OrderMode,
  Expense,
  DaySession,
  InventoryItem,
  InventoryLog,
  Denominations,
  SplitPaymentDetail,
} from '../types';
import {
  INITIAL_SECTIONS,
  INITIAL_TABLES,
  INITIAL_MENU,
  INITIAL_CUSTOMERS,
  INITIAL_STAFF,
  SYSTEM_USERS,
  INITIAL_INVENTORY,
} from '../data/initialData';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  // Auth & Roles
  users: User[];
  currentUser: User;
  setCurrentUser: (user: User) => void;
  verifyManagerPin: (pin: string) => boolean;
  isLocked: boolean;
  lockTerminal: () => void;
  unlockTerminal: (pin: string) => boolean;
  loginWithPin: (userId: string, pin: string) => boolean;
  verifyPin: (pin: string) => boolean;

  // Database Maintenance
  exportDatabase: () => void;
  importDatabase: (jsonContent: string) => boolean;
  resetDatabase: () => void;

  // Active Section
  sections: Section[];
  activeSection: Section;
  setActiveSectionId: (id: string) => void;
  updateSectionUpi: (sectionId: string, upiId: string) => void;

  // Day Session
  daySessions: Record<string, DaySession>; // sectionId -> DaySession
  isDayOpen: boolean;
  openDaySession: (sectionId: string, openingCash: number, denominations: Denominations) => void;
  closeDaySession: (
    sectionId: string,
    closingCash: number,
    denominations: Denominations,
    expectedCash: number
  ) => void;

  // Tables
  tables: Table[];

  // Menu
  menuItems: MenuItem[];
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (id: string, updates: Partial<MenuItem>) => void;
  toggleMenuItemActive: (id: string) => void;

  // Customers
  customers: Customer[];
  searchCustomers: (query: string) => Customer[];
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt' | 'lastVisit' | 'totalOrders' | 'totalSpent'>) => Customer;
  addWalkInAdvance: (mobile: string, name: string, amount: number) => void;

  // Orders
  orders: Order[];
  activeOrders: Order[];
  getOrderForTable: (tableId: string) => Order | undefined;
  saveOrder: (orderData: Partial<Order>) => Order;
  generateKot: (orderId: string) => { order: Order; newItems: OrderItem[] };
  processBillPayment: (
    orderId: string,
    paymentData: {
      paidAmount: number;
      paymentMode: 'cash' | 'upi' | 'card' | 'split' | 'dues' | 'credit';
      splitDetails?: SplitPaymentDetail[];
      discountPercent?: number;
      shortfallHandling?: 'dues' | 'discount';
      excessHandling?: 'return' | 'credit' | 'tip';
      customerMobile?: string;
      customerName?: string;
    }
  ) => void;
  voidOrder: (orderId: string, reason: string, voidedByPin: string) => boolean;

  // Staff
  staff: Staff[];
  addStaffAdvance: (staffId: string, amount: number, note: string) => void;

  // Expenses
  expenses: Expense[];
  addExpense: (expense: Omit<Expense, 'id'>) => void;

  // Inventory
  inventory: InventoryItem[];
  inventoryLogs: InventoryLog[];
  addInventoryStock: (inventoryId: string, quantity: number, cost: number, supplier: string) => void;

  // System & Utilities
  isOffline: boolean;
  setIsOffline: (offline: boolean) => void;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;

  // Order Timer Helper
  getOrderMinutes: (order: Order) => number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'mealbox_pos_data_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load or fallback to initial
  const loadInitialData = () => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to parse saved state', e);
    }
    return null;
  };

  const savedData = loadInitialData();

  const [users, setUsers] = useState<User[]>(savedData?.users || SYSTEM_USERS);
  const [currentUser, setCurrentUser] = useState<User>(
    savedData?.currentUserId
      ? (savedData?.users || SYSTEM_USERS).find((u: User) => u.id === savedData.currentUserId) || SYSTEM_USERS[0]
      : SYSTEM_USERS[0]
  );
  const [isLocked, setIsLocked] = useState<boolean>(savedData?.isLocked || false);
  const [sections, setSections] = useState<Section[]>(savedData?.sections || INITIAL_SECTIONS);
  const [activeSectionId, setActiveSectionIdState] = useState<string>(
    savedData?.activeSectionId || INITIAL_SECTIONS[0].id
  );

  const [tables, setTables] = useState<Table[]>(savedData?.tables || INITIAL_TABLES);
  const [menuItems, setMenuItems] = useState<MenuItem[]>(savedData?.menuItems || INITIAL_MENU);
  const [customers, setCustomers] = useState<Customer[]>(savedData?.customers || INITIAL_CUSTOMERS);
  const [staff, setStaff] = useState<Staff[]>(savedData?.staff || INITIAL_STAFF);
  const [orders, setOrders] = useState<Order[]>(savedData?.orders || []);
  const ordersRef = useRef<Order[]>(savedData?.orders || []);

  useEffect(() => {
    ordersRef.current = orders;
  }, [orders]);
  const [expenses, setExpenses] = useState<Expense[]>(savedData?.expenses || []);
  const [inventory, setInventory] = useState<InventoryItem[]>(savedData?.inventory || INITIAL_INVENTORY);
  const [inventoryLogs, setInventoryLogs] = useState<InventoryLog[]>(savedData?.inventoryLogs || []);
  const [daySessions, setDaySessions] = useState<Record<string, DaySession>>(savedData?.daySessions || {
    'sec-mealbox': {
      id: 'ds-1',
      sectionId: 'sec-mealbox',
      date: new Date().toISOString().split('T')[0],
      status: 'open',
      openingCash: 2000,
      openingDenominations: { c500: 2, c200: 2, c100: 5, c50: 2, c20: 0, c10: 0, coins: 0 },
      openedBy: 'Owner',
      openedAt: new Date().toISOString(),
    },
  });

  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync to local storage
  useEffect(() => {
    const dataToSave = {
      users,
      currentUserId: currentUser.id,
      isLocked,
      sections,
      activeSectionId,
      tables,
      menuItems,
      customers,
      staff,
      orders,
      expenses,
      inventory,
      inventoryLogs,
      daySessions,
    };
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(dataToSave));
    } catch (e) {
      console.error('LocalStorage save error', e);
    }
  }, [users, currentUser, isLocked, sections, activeSectionId, tables, menuItems, customers, staff, orders, expenses, inventory, inventoryLogs, daySessions]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Lock / Unlock Terminal & Security
  const lockTerminal = () => {
    setIsLocked(true);
    showToast('Terminal Locked', 'info');
  };

  const unlockTerminal = (pin: string): boolean => {
    const matchingUser = users.find((u) => u.pin === pin);
    if (matchingUser) {
      setCurrentUser(matchingUser);
      setIsLocked(false);
      showToast(`Welcome back, ${matchingUser.name}`, 'success');
      return true;
    }
    // Also check manager or owner override PINs
    const managerUser = users.find((u) => (u.role === 'owner' || u.role === 'manager') && u.pin === pin);
    if (managerUser) {
      setCurrentUser(managerUser);
      setIsLocked(false);
      showToast(`Terminal unlocked by ${managerUser.name}`, 'success');
      return true;
    }
    return false;
  };

  const loginWithPin = (userId: string, pin: string): boolean => {
    const targetUser = users.find((u) => u.id === userId);
    if (!targetUser) return false;

    const isManagerPin = users.some((u) => (u.role === 'owner' || u.role === 'manager') && u.pin === pin);
    if (targetUser.pin === pin || isManagerPin) {
      setCurrentUser(targetUser);
      setIsLocked(false);
      showToast(`Logged in as ${targetUser.name}`, 'success');
      return true;
    }
    return false;
  };

  const verifyPin = (pin: string): boolean => {
    if (currentUser.pin === pin) return true;
    return users.some((u) => (u.role === 'owner' || u.role === 'manager') && u.pin === pin);
  };

  const verifyManagerPin = (pin: string) => {
    return users.some((u) => (u.role === 'owner' || u.role === 'manager') && u.pin === pin);
  };

  // Database Export, Import, Reset
  const exportDatabase = () => {
    const dataToExport = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      users,
      sections,
      activeSectionId,
      tables,
      menuItems,
      customers,
      staff,
      orders,
      expenses,
      inventory,
      inventoryLogs,
      daySessions,
    };
    const jsonStr = JSON.stringify(dataToExport, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MealBox_POS_Backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('Database backup downloaded successfully', 'success');
  };

  const importDatabase = (jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (!parsed || typeof parsed !== 'object') {
        throw new Error('Invalid backup file');
      }
      if (parsed.users) setUsers(parsed.parsed ? parsed.users : parsed.users);
      if (parsed.sections) setSections(parsed.sections);
      if (parsed.tables) setTables(parsed.tables);
      if (parsed.menuItems) setMenuItems(parsed.menuItems);
      if (parsed.customers) setCustomers(parsed.customers);
      if (parsed.staff) setStaff(parsed.staff);
      if (parsed.orders) setOrders(parsed.orders);
      if (parsed.expenses) setExpenses(parsed.expenses);
      if (parsed.inventory) setInventory(parsed.inventory);
      if (parsed.inventoryLogs) setInventoryLogs(parsed.inventoryLogs);
      if (parsed.daySessions) setDaySessions(parsed.daySessions);

      showToast('Database restored successfully from file!', 'success');
      return true;
    } catch (err: any) {
      showToast(`Restore failed: ${err.message}`, 'error');
      return false;
    }
  };

  const resetDatabase = () => {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    setUsers(SYSTEM_USERS);
    setCurrentUser(SYSTEM_USERS[0]);
    setIsLocked(false);
    setSections(INITIAL_SECTIONS);
    setActiveSectionIdState(INITIAL_SECTIONS[0].id);
    setTables(INITIAL_TABLES);
    setMenuItems(INITIAL_MENU);
    setCustomers(INITIAL_CUSTOMERS);
    setStaff(INITIAL_STAFF);
    setOrders([]);
    setExpenses([]);
    setInventory(INITIAL_INVENTORY);
    setInventoryLogs([]);
    showToast('Database reset to factory default state', 'info');
  };

  const activeSection = sections.find((s) => s.id === activeSectionId) || sections[0];

  const setActiveSectionId = (id: string) => {
    setActiveSectionIdState(id);
  };

  const updateSectionUpi = (sectionId: string, upiId: string) => {
    setSections((prev) => prev.map((s) => (s.id === sectionId ? { ...s, upiId } : s)));
    showToast('UPI ID updated for section');
  };

  const currentDaySession = daySessions[activeSection.id];
  const isDayOpen = currentDaySession ? currentDaySession.status === 'open' : false;

  const openDaySession = (sectionId: string, openingCash: number, denominations: Denominations) => {
    const today = new Date().toISOString().split('T')[0];
    const newSession: DaySession = {
      id: `session-${Date.now()}`,
      sectionId,
      date: today,
      status: 'open',
      openingCash,
      openingDenominations: denominations,
      openedBy: currentUser.name,
      openedAt: new Date().toISOString(),
    };
    setDaySessions((prev) => ({ ...prev, [sectionId]: newSession }));
    showToast(`Day Opened for ${sections.find((s) => s.id === sectionId)?.name} with ₹${openingCash}`);
  };

  const closeDaySession = (
    sectionId: string,
    closingCash: number,
    denominations: Denominations,
    expectedCash: number
  ) => {
    const existing = daySessions[sectionId];
    if (!existing) return;

    const discrepancy = closingCash - expectedCash;

    const closed: DaySession = {
      ...existing,
      status: 'closed',
      closingCash,
      closingDenominations: denominations,
      expectedCash,
      discrepancy,
      closedBy: currentUser.name,
      closedAt: new Date().toISOString(),
    };

    setDaySessions((prev) => ({ ...prev, [sectionId]: closed }));
    showToast(`Day Closed. Cash Discrepancy: ${discrepancy >= 0 ? '+' : ''}₹${discrepancy}`, discrepancy === 0 ? 'success' : 'info');
  };

  // Customers
  const searchCustomers = (query: string) => {
    if (!query || query.trim().length < 2) return [];
    const q = query.trim().toLowerCase();
    return customers.filter(
      (c) => c.mobile.includes(q) || c.name.toLowerCase().includes(q)
    );
  };

  const addCustomer = (customerData: Omit<Customer, 'id' | 'createdAt' | 'lastVisit' | 'totalOrders' | 'totalSpent'>): Customer => {
    // Check if customer already exists by mobile
    const existing = customers.find((c) => c.mobile === customerData.mobile);
    if (existing) {
      const updated = {
        ...existing,
        name: customerData.name || existing.name,
        address: customerData.address || existing.address,
        dues: customerData.dues !== undefined ? customerData.dues : existing.dues,
        advance: customerData.advance !== undefined ? customerData.advance : existing.advance,
      };
      setCustomers((prev) => prev.map((c) => (c.id === existing.id ? updated : c)));
      return updated;
    }

    const newCust: Customer = {
      id: `cust-${Date.now()}`,
      name: customerData.name || 'Guest Customer',
      mobile: customerData.mobile,
      whatsapp: customerData.whatsapp || customerData.mobile,
      address: customerData.address || '',
      dues: customerData.dues || 0,
      advance: customerData.advance || 0,
      totalOrders: 0,
      totalSpent: 0,
      createdAt: new Date().toISOString(),
      lastVisit: new Date().toISOString(),
    };

    setCustomers((prev) => [...prev, newCust]);
    return newCust;
  };

  const addWalkInAdvance = (mobile: string, name: string, amount: number) => {
    let cust = customers.find((c) => c.mobile === mobile);
    if (!cust) {
      cust = addCustomer({ mobile, name, dues: 0, advance: amount });
    } else {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === cust!.id ? { ...c, advance: c.advance + amount, name: name || c.name } : c
        )
      );
    }
    showToast(`Saved ₹${amount} advance credit for ${name || mobile}`);
  };

  // Menu
  const addMenuItem = (itemData: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = {
      ...itemData,
      id: `menu-${Date.now()}`,
    };
    setMenuItems((prev) => [...prev, newItem]);
    showToast('Menu item added successfully');
  };

  const updateMenuItem = (id: string, updates: Partial<MenuItem>) => {
    setMenuItems((prev) => prev.map((item) => (item.id === id ? { ...item, ...updates } : item)));
    showToast('Menu item updated');
  };

  const toggleMenuItemActive = (id: string) => {
    setMenuItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, active: !item.active } : item))
    );
  };

  // Orders logic
  const activeOrders = orders.filter((o) => o.status === 'active' && o.sectionId === activeSection.id);

  const getOrderForTable = (tableId: string) => {
    return activeOrders.find((o) => o.tableId === tableId && o.status === 'active');
  };

  const getOrderMinutes = (order: Order) => {
    if (!order.createdAt) return 0;
    const start = new Date(order.createdAt).getTime();
    const now = new Date().getTime();
    return Math.floor((now - start) / (1000 * 60));
  };

  // Single Bill Rule Order Saver
  const saveOrder = (orderData: Partial<Order>): Order => {
    const nowIso = new Date().toISOString();

    // Deduct inventory for packaged non-KOT items (Water, Cold Drink, Ice Cream)
    if (orderData.items) {
      orderData.items.forEach((item) => {
        const inv = inventory.find((i) => i.itemName.toLowerCase() === item.nameEn.toLowerCase());
        if (inv) {
          const qty = item.quantity;
          setInventory((prev) =>
            prev.map((i) =>
              i.id === inv.id
                ? {
                    ...i,
                    quantityOut: i.quantityOut + qty,
                    stock: Math.max(0, i.openingStock + i.quantityIn - (i.quantityOut + qty)),
                  }
                : i
            )
          );
        }
      });
    }

    if (orderData.id) {
      // Editing existing order
      const existing = ordersRef.current.find((o) => o.id === orderData.id) || orders.find((o) => o.id === orderData.id);
      const updatedOrder: Order = existing
        ? ({
            ...existing,
            ...orderData,
            items: orderData.items || existing.items,
          } as Order)
        : ({
            ...orderData,
            createdAt: orderData.createdAt || nowIso,
          } as Order);

      ordersRef.current = ordersRef.current.map((o) => (o.id === orderData.id ? updatedOrder : o));
      setOrders((prev) => prev.map((o) => (o.id === orderData.id ? updatedOrder : o)));
      showToast(`Order #${orderData.orderNumber || ''} updated`);
      return updatedOrder;
    } else {
      // New Order creation
      const nextOrderNum = ordersRef.current.length + 101;
      const newOrder: Order = {
        id: `ord-${Date.now()}`,
        orderNumber: nextOrderNum,
        sectionId: orderData.sectionId || activeSection.id,
        sectionName: sections.find((s) => s.id === (orderData.sectionId || activeSection.id))?.name || activeSection.name,
        tableId: orderData.tableId,
        tableName: orderData.tableName,
        mode: orderData.mode || 'dine_in',
        status: 'active',
        customerId: orderData.customerId,
        customerName: orderData.customerName,
        customerMobile: orderData.customerMobile,
        customerAddress: orderData.customerAddress,
        waiterId: orderData.waiterId,
        waiterName: orderData.waiterName,
        guestCount: orderData.guestCount || 1,
        items: orderData.items || [],
        subtotal: orderData.subtotal || 0,
        attachedDues: orderData.attachedDues || 0,
        appliedCredit: orderData.appliedCredit || 0,
        discountPercent: orderData.discountPercent || 0,
        discountAmount: orderData.discountAmount || 0,
        advanceDeposit: orderData.advanceDeposit || 0,
        finalTotal: orderData.finalTotal || 0,
        paidAmount: orderData.paidAmount || 0,
        paymentMode: orderData.paymentMode,
        createdAt: nowIso,
      };

      ordersRef.current = [newOrder, ...ordersRef.current];
      setOrders((prev) => [newOrder, ...prev]);

      // Lock table if Dine-In
      if (orderData.mode === 'dine_in' && orderData.tableId) {
        setTables((prev) =>
          prev.map((t) =>
            t.id === orderData.tableId
              ? { ...t, status: 'occupied', currentOrderId: newOrder.id, occupiedSince: nowIso }
              : t
          )
        );
      }

      showToast(`Order #${newOrder.orderNumber} created`);
      return newOrder;
    }
  };

  const generateKot = (
    orderIdOrObject: string | Order,
    providedOrder?: Order
  ): { order: Order; newItems: OrderItem[] } => {
    const orderId = typeof orderIdOrObject === 'string' ? orderIdOrObject : orderIdOrObject.id;
    const targetOrder =
      providedOrder ||
      (typeof orderIdOrObject === 'object' ? orderIdOrObject : undefined) ||
      ordersRef.current.find((o) => o.id === orderId) ||
      orders.find((o) => o.id === orderId);

    if (!targetOrder) {
      showToast('Order details not found for KOT', 'error');
      return {
        order: {
          id: orderId || 'unknown',
          orderNumber: 0,
          mode: 'dine_in',
          status: 'open',
          items: [],
          subtotal: 0,
          tax: 0,
          discountPercent: 0,
          discountAmount: 0,
          attachedDues: 0,
          appliedCredit: 0,
          finalTotal: 0,
          paidAmount: 0,
          sectionId: activeSection.id,
          sectionName: activeSection.name,
          createdAt: new Date().toISOString(),
        } as unknown as Order,
        newItems: [],
      };
    }

    // Filter items that need KOT print (kotPrint: true)
    // For existing orders, only items where kotPrinted is false or isNew is true!
    const newItems = targetOrder.items.filter((item) => item.kotPrint && (!item.kotPrinted || item.isNew));

    // Update order items: mark kotPrinted = true, isNew = false
    const updatedItems = targetOrder.items.map((item) => {
      if (item.kotPrint) {
        return { ...item, kotPrinted: true, isNew: false };
      }
      return item;
    });

    const updatedOrder: Order = {
      ...targetOrder,
      items: updatedItems,
      kotPrintedAt: new Date().toISOString(),
    };

    ordersRef.current = ordersRef.current.map((o) => (o.id === orderId ? updatedOrder : o));
    setOrders((prev) => prev.map((o) => (o.id === orderId ? updatedOrder : o)));
    showToast(`KOT generated for Order #${updatedOrder.orderNumber}`);

    return { order: updatedOrder, newItems };
  };

  const processBillPayment = (
    orderId: string,
    paymentData: {
      paidAmount: number;
      paymentMode: 'cash' | 'upi' | 'card' | 'split' | 'dues' | 'credit';
      splitDetails?: SplitPaymentDetail[];
      discountPercent?: number;
      shortfallHandling?: 'dues' | 'discount';
      excessHandling?: 'return' | 'credit' | 'tip';
      customerMobile?: string;
      customerName?: string;
    }
  ) => {
    const targetOrder = ordersRef.current.find((o) => o.id === orderId) || orders.find((o) => o.id === orderId);
    if (!targetOrder) {
      showToast('Order not found for billing', 'error');
      return;
    }

    // Auto-upsert customer if mobile provided
    let cust: Customer | undefined;
    if (paymentData.customerMobile) {
      cust = addCustomer({
        mobile: paymentData.customerMobile,
        name: paymentData.customerName || 'Customer',
        dues: 0,
        advance: 0,
      });
    } else if (targetOrder.customerId) {
      cust = customers.find((c) => c.id === targetOrder.customerId);
    }

    const finalBill = targetOrder.finalTotal;
    const paid = paymentData.paidAmount;

    // Handle Attached Dues / Applied Credit settling
    if (targetOrder.attachedDues > 0 && cust) {
      // Clear attached dues from customer account since it's added to this bill
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === cust!.id
            ? { ...c, dues: Math.max(0, c.dues - targetOrder.attachedDues) }
            : c
        )
      );
    }

    if (targetOrder.appliedCredit > 0 && cust) {
      // Deduct applied credit from customer account
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === cust!.id
            ? { ...c, advance: Math.max(0, c.advance - targetOrder.appliedCredit) }
            : c
        )
      );
    }

    // Handle Shortfall (Paid < FinalBill)
    if (paid < finalBill) {
      const remaining = finalBill - paid;
      if (paymentData.shortfallHandling === 'dues' && cust) {
        setCustomers((prev) =>
          prev.map((c) => (c.id === cust!.id ? { ...c, dues: c.dues + remaining } : c))
        );
        showToast(`Saved ₹${remaining} as pending dues for ${cust.name}`);
      }
    }

    // Handle Excess (Paid > FinalBill)
    if (paid > finalBill) {
      const extra = paid - finalBill;
      if (paymentData.excessHandling === 'credit' && cust) {
        setCustomers((prev) =>
          prev.map((c) => (c.id === cust!.id ? { ...c, advance: c.advance + extra } : c))
        );
        showToast(`Saved ₹${extra} as advance credit for ${cust.name}`);
      }
    }

    // Update customer order stats
    if (cust) {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === cust!.id
            ? {
                ...c,
                totalOrders: c.totalOrders + 1,
                totalSpent: c.totalSpent + (targetOrder.mode === 'free' ? 0 : finalBill),
                lastVisit: new Date().toISOString(),
              }
            : c
        )
      );
    }

    // Settled order update
    const settledOrder: Order = {
      ...targetOrder,
      status: 'settled',
      paidAmount: paid,
      paymentMode: paymentData.paymentMode,
      splitDetails: paymentData.splitDetails,
      shortfallHandling: paymentData.shortfallHandling,
      excessHandling: paymentData.excessHandling,
      paidAt: new Date().toISOString(),
    };

    ordersRef.current = ordersRef.current.map((o) => (o.id === orderId ? settledOrder : o));
    setOrders((prev) => prev.map((o) => (o.id === orderId ? settledOrder : o)));

    // Unlock table if Dine-In
    if (targetOrder.tableId) {
      setTables((prev) =>
        prev.map((t) =>
          t.id === targetOrder.tableId
            ? { ...t, status: 'empty', currentOrderId: undefined, occupiedSince: undefined }
            : t
        )
      );
    }

    showToast(`Order #${targetOrder.orderNumber} Settled & Paid!`);
  };

  const voidOrder = (orderId: string, reason: string, voidedByPin: string): boolean => {
    if (!verifyManagerPin(voidedByPin)) {
      showToast('Invalid Manager/Owner PIN', 'error');
      return false;
    }

    const targetOrder = ordersRef.current.find((o) => o.id === orderId) || orders.find((o) => o.id === orderId);
    if (!targetOrder) {
      showToast('Order not found', 'error');
      return false;
    }

    const voidedOrder: Order = {
      ...targetOrder,
      status: 'void',
      voidReason: reason,
      voidedBy: currentUser.name,
      voidedAt: new Date().toISOString(),
    };

    setOrders((prev) => prev.map((o) => (o.id === orderId ? voidedOrder : o)));

    // Unlock table
    if (targetOrder.tableId) {
      setTables((prev) =>
        prev.map((t) =>
          t.id === targetOrder.tableId
            ? { ...t, status: 'empty', currentOrderId: undefined, occupiedSince: undefined }
            : t
        )
      );
    }

    showToast(`Order #${targetOrder.orderNumber} Voided: ${reason}`, 'info');
    return true;
  };

  // Staff
  const addStaffAdvance = (staffId: string, amount: number, note: string) => {
    setStaff((prev) =>
      prev.map((s) => {
        if (s.id === staffId) {
          const newAdv = s.advanceTotal + amount;
          return {
            ...s,
            advanceTotal: newAdv,
            duesTotal: Math.max(0, s.salary - newAdv),
          };
        }
        return s;
      })
    );

    // Auto-record in expenses under Staff category
    addExpense({
      sectionId: activeSection.id,
      category: 'Staff',
      description: `Salary Advance to ${staff.find((s) => s.id === staffId)?.name || 'Staff'}: ${note}`,
      amount,
      mode: 'cash',
      date: new Date().toISOString().split('T')[0],
      staffId,
      createdBy: currentUser.name,
    });

    showToast(`Recorded ₹${amount} advance for staff`);
  };

  // Expenses
  const addExpense = (expenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}`,
    };
    setExpenses((prev) => [newExpense, ...prev]);
    showToast(`Recorded Expense: ₹${expenseData.amount} (${expenseData.category})`);
  };

  // Inventory
  const addInventoryStock = (
    inventoryId: string,
    quantity: number,
    cost: number,
    supplier: string
  ) => {
    setInventory((prev) =>
      prev.map((i) =>
        i.id === inventoryId
          ? {
              ...i,
              quantityIn: i.quantityIn + quantity,
              stock: i.stock + quantity,
            }
          : i
      )
    );

    const log: InventoryLog = {
      id: `invlog-${Date.now()}`,
      inventoryId,
      itemName: inventory.find((i) => i.id === inventoryId)?.itemName || '',
      type: 'in',
      quantity,
      cost,
      supplier,
      date: new Date().toISOString(),
    };

    setInventoryLogs((prev) => [log, ...prev]);
    showToast(`Added ${quantity} units stock to inventory`);
  };

  return (
    <AppContext.Provider
      value={{
        users,
        currentUser,
        setCurrentUser,
        verifyManagerPin,
        isLocked,
        lockTerminal,
        unlockTerminal,
        loginWithPin,
        verifyPin,
        exportDatabase,
        importDatabase,
        resetDatabase,
        sections,
        activeSection,
        setActiveSectionId,
        updateSectionUpi,
        daySessions,
        isDayOpen,
        openDaySession,
        closeDaySession,
        tables,
        menuItems,
        addMenuItem,
        updateMenuItem,
        toggleMenuItemActive,
        customers,
        searchCustomers,
        addCustomer,
        addWalkInAdvance,
        orders,
        activeOrders,
        getOrderForTable,
        saveOrder,
        generateKot,
        processBillPayment,
        voidOrder,
        staff,
        addStaffAdvance,
        expenses,
        addExpense,
        inventory,
        inventoryLogs,
        addInventoryStock,
        isOffline,
        setIsOffline,
        toasts,
        showToast,
        removeToast,
        getOrderMinutes,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
