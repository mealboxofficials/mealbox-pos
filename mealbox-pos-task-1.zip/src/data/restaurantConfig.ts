export const RESTAURANT_CONFIG = {
  name: 'MealBox Restaurant',
  tagline: '(A Glocal Restaurant)',
  shortName: 'MealBox',
  address: 'Cinema Chauk (Near Krishna Hospital), Patory Bazar, Samastipur- 848504 (Bihar)',
  contactPhone: '8877044088',
  deliveryMinOrder: 500,
  packagingCostPerBox: 10,
  jurisdiction: 'Samastipur',
  services: [
    'Home Delivery',
    'Hall / Room Booking',
    'Pre-Wedding Ceremony',
    'Birthday Party',
    'Reception',
    'Engagement',
    'Office Meetings',
    'All Other Occasions',
  ],
  termsAndConditions: [
    {
      en: 'Outside drinks/food strictly prohibited.',
      hi: 'बाहर से लाकर कोई भी चीज खाना या पीना पूर्णतः वर्जित है।',
    },
    {
      en: 'Smoking and drinking alcohol here is an offense.',
      hi: 'यहाँ सिगरेट/शराब पीना सख्त मना है।',
    },
    {
      en: "Order once prepared can't be changed/replaced. You can ask for replacement if you have issue with taste/portion. No discount will be given after having food/drink.",
      hi: 'एक बार ऑर्डर बन जाने के बाद उसमे बदलाव या कमी नहीं किया जा सकता है। अगर आपको खाने के स्वाद/मात्रा को लेकर कोई शिकायत है तो उसे बदलने के लिए कह सकते है।',
    },
    {
      en: 'Kindly keep your belongings with care. Management is not responsible for lost/damage.',
      hi: 'अपने साथ लाए चीजों की देखभाल खुद करे। कोई नुकसान के लिए रेस्टोरेंट जिम्मेदार नहीं होगा।',
    },
    {
      en: 'We love kids, however kindly do keep your children under reasonable control so that they do not annoy other guests. You will be accountable for any personal/material damage.',
      hi: 'कृपया साथ लाए बच्चों पर उचित ध्यान रखे ताकि अन्य ग्राहकों को परेशानी ना हो। अगर बच्चे द्वारा किसी तरह का नुकसान किया जाता है तो उसकी भरपाई देनी होगी।',
    },
    {
      en: 'Restaurant has the right to change the price without prior notice and to decide the price of an item not mentioned in the Menu card.',
      hi: 'रेस्टोरेंट के पास अधिकार है की बिना किसी पूर्व सूचना के दर मे बदलाव कर सके और जो आइटम मेनू मे नहीं है उसका दाम निर्धारित कर सके।',
    },
    {
      en: 'Restaurant has right to accept or deny an order or reserve the particular table/area.',
      hi: 'रेस्टोरेंट के पास अधिकार है की किसी ऑर्डर को लेने से मना कर सके और किसी खास टेबल/क्षेत्र को रिजर्व कर सके।',
    },
    {
      en: "Please don't spread Cakes, Snow Spray, Party Popper, Air Sparkle, etc during celebration. You will be accountable for additional charge.",
      hi: 'कृपया पार्टी के दौरान केक, फ़ोम स्प्रे व अन्य तरह की चीजें ना उड़ाये। ऐसा करने पर एक्स्ट्रा चार्ज देना होगा।',
    },
    {
      en: 'A service charge will be added if you occupied/engaged multiple tables during celebration/meeting.',
      hi: 'मीटिंग/सेलिब्रेशन के दौरान यदि एक से ज्यादा टेबल का उपयोग/बाधित करते है तो सर्विस चार्ज देना होगा।',
    },
    {
      en: 'Cooling/Storage/Serving charge will be added to any in packaged item. It will vary according to the size of packaging.',
      hi: 'पैक सामान पर कुलिंग/स्टोरेज/सर्विस चार्ज के रूप मे कुछ एक्स्ट्रा चार्ज लिया जाएगा जो की पैक सामान के साइज़ पर निर्भर करेगा।',
    },
    {
      en: 'For home delivery a minimum order value of 500 (Five Hundred) will be required. Delivery charges will be added according to the distance.',
      hi: 'होम डिलीवरी के लिए कम से कम 500 का ऑर्डर करना होगा। डिलीवरी चार्ज दूरी के अनुसार लिया जाएगा।',
    },
    {
      en: 'Packaging cost rupees 10 per box/container will be charged for parcel.',
      hi: 'पार्सल लेने पर 10 रुपया प्रति प्लेट पैकिंग/डब्बे का चार्ज लिया जाएगा।',
    },
    {
      en: 'Price mentioned in the Menu excluded all taxation. Service tax is applicable as per government norms.',
      hi: 'मेनू मे शामिल सभी दरें बिना टैक्स के है। जीएसटी/सर्विस टैक्स सरकार के नियमानुसार लगाया जा सकता है।',
    },
    {
      en: 'All dispute are subject to Samastipur jurisdiction only.',
      hi: 'सभी प्रकार का विवाद केवल समस्तीपुर न्यायालय के क्षेत्राधिकार के अधीन में होगा।',
    },
  ],
};
