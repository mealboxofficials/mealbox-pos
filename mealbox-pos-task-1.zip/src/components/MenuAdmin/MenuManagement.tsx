import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MenuItem } from '../../types';
import { RESTAURANT_CONFIG } from '../../data/restaurantConfig';
import { MealBoxLogo } from '../MealBoxLogo';
import QRCode from 'qrcode';
import {
  BookOpen,
  Plus,
  QrCode,
  Check,
  X,
  Edit2,
  Printer,
  Percent,
  ToggleLeft,
  ToggleRight,
  Store,
  FileText,
  Info,
} from 'lucide-react';

export const MenuManagement: React.FC = () => {
  const {
    menuItems,
    sections,
    activeSection,
    addMenuItem,
    updateMenuItem,
    toggleMenuItemActive,
    updateSectionUpi,
    showToast,
  } = useApp();

  const [selectedSection, setSelectedSection] = useState<string>(activeSection.id);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDigitalMenuQrModal, setShowDigitalMenuQrModal] = useState(false);
  const [menuQrDataUrl, setMenuQrDataUrl] = useState('');

  // Edit Section UPI
  const [editingUpiId, setEditingUpiId] = useState(sections.find((s) => s.id === selectedSection)?.upiId || '');

  // Form State for new item
  const [nameEn, setNameEn] = useState('');
  const [nameHi, setNameHi] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('Main Course');
  const [kotPrint, setKotPrint] = useState(true);
  const [discountable, setDiscountable] = useState(true);

  const handleCreateMenuItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameEn || !price) return;

    const basePrice = Number(price) || 0;

    addMenuItem({
      nameEn,
      nameHi: nameHi || nameEn,
      price: basePrice,
      sectionPrices: {
        [selectedSection]: basePrice,
      },
      category,
      kotPrint,
      discountable,
      active: true,
    });

    setNameEn('');
    setNameHi('');
    setPrice('');
    setShowAddModal(false);
  };

  const handleUpdateSectionPrice = (itemId: string, newPrice: number) => {
    const item = menuItems.find((m) => m.id === itemId);
    if (!item) return;

    const updatedSectionPrices = {
      ...item.sectionPrices,
      [selectedSection]: newPrice,
    };

    updateMenuItem(itemId, { sectionPrices: updatedSectionPrices });
  };

  const handleGenerateDigitalMenuQr = () => {
    const menuUrl = window.location.origin + `?menuSection=${selectedSection}`;
    QRCode.toDataURL(menuUrl, { width: 260, margin: 1 })
      .then((url) => {
        setMenuQrDataUrl(url);
        setShowDigitalMenuQrModal(true);
      })
      .catch((err) => console.error('Menu QR error', err));
  };

  const handleSaveUpi = () => {
    updateSectionUpi(selectedSection, editingUpiId);
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-105px)] text-slate-100 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Section Menu & Price Configuration</h2>
            <p className="text-xs text-slate-400">
              Set section-specific pricing, KOT printing flags, discount eligibility, and digital menu QR
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateDigitalMenuQr}
            className="bg-slate-800 hover:bg-slate-750 text-amber-400 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 border border-slate-700"
          >
            <QrCode className="w-4 h-4" />
            <span>Digital Menu QR</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 shadow-lg"
          >
            <Plus className="w-4 h-4" />
            <span>Add Menu Item</span>
          </button>
        </div>
      </div>

      {/* Section Switcher & Section UPI Config Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Select Active Section to Configure Rates
          </label>
        </div>

        <div className="flex flex-wrap gap-2">
          {sections.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                setSelectedSection(s.id);
                setEditingUpiId(s.upiId);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                selectedSection === s.id
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <Store className="w-4 h-4" />
              <span>{s.name} Rates</span>
            </button>
          ))}
        </div>

        <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center gap-3 text-xs">
          <span className="font-bold text-slate-300">Section UPI ID for Bill QR Code:</span>
          <input
            type="text"
            value={editingUpiId}
            onChange={(e) => setEditingUpiId(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-amber-400 font-mono w-64"
          />
          <button
            onClick={handleSaveUpi}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-3 py-1.5 rounded-lg border border-slate-700"
          >
            Save UPI ID
          </button>
        </div>
      </div>

      {/* Menu Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">Item Name (English / Hindi)</th>
                <th className="p-4">Category</th>
                <th className="p-4">{sections.find((s) => s.id === selectedSection)?.name} Price (₹)</th>
                <th className="p-4">KOT Print?</th>
                <th className="p-4">Discount Eligible?</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {menuItems.map((item) => {
                const currentPrice = item.sectionPrices[selectedSection] || item.price;

                return (
                  <tr key={item.id} className="hover:bg-slate-800/50 transition">
                    <td className="p-4">
                      <div className="font-extrabold text-slate-100">{item.nameEn}</div>
                      <div className="text-slate-400 text-[11px] font-semibold">{item.nameHi}</div>
                    </td>
                    <td className="p-4 font-semibold text-slate-300">{item.category}</td>

                    {/* Section Price Editor */}
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-amber-400 text-sm">₹</span>
                        <input
                          type="number"
                          value={currentPrice}
                          onChange={(e) =>
                            handleUpdateSectionPrice(item.id, Number(e.target.value) || 0)
                          }
                          className="w-20 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 font-bold text-amber-400 text-sm"
                        />
                      </div>
                    </td>

                    {/* KOT Print Flag */}
                    <td className="p-4">
                      <button
                        onClick={() =>
                          updateMenuItem(item.id, { kotPrint: !item.kotPrint })
                        }
                        className={`px-2.5 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1.5 ${
                          item.kotPrint
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>{item.kotPrint ? 'Prints on KOT' : 'NO KOT (Bill only)'}</span>
                      </button>
                    </td>

                    {/* Discountable Flag */}
                    <td className="p-4">
                      <button
                        onClick={() =>
                          updateMenuItem(item.id, { discountable: !item.discountable })
                        }
                        className={`px-2.5 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1.5 ${
                          item.discountable
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        <Percent className="w-3.5 h-3.5" />
                        <span>{item.discountable ? 'Discountable' : 'No Discount'}</span>
                      </button>
                    </td>

                    {/* Active / Inactive Toggle */}
                    <td className="p-4">
                      <button
                        onClick={() => toggleMenuItemActive(item.id)}
                        className={`px-2.5 py-1 rounded-lg font-bold text-[11px] ${
                          item.active
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {item.active ? 'ACTIVE' : 'INACTIVE'}
                      </button>
                    </td>

                    <td className="p-4 text-right">
                      <span className="text-[10px] text-slate-500">Auto-saved</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Restaurant Information & Terms & Conditions Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <MealBoxLogo size="md" showSubtitle={true} />
            <div>
              <p className="text-xs text-slate-300 font-medium">{RESTAURANT_CONFIG.address}</p>
              <p className="text-xs font-bold text-amber-400">Phone: {RESTAURANT_CONFIG.contactPhone}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Info className="w-4 h-4 text-amber-400" />
            <span>Official Menu Terms & Regulations</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
          {RESTAURANT_CONFIG.termsAndConditions.map((term, idx) => (
            <div key={idx} className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 space-y-1">
              <div className="font-semibold text-slate-100 flex items-start gap-2">
                <span className="text-amber-400 font-extrabold">{idx + 1}.</span>
                <span>{term.en}</span>
              </div>
              <div className="text-[11px] text-slate-400 pl-4">{term.hi}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Menu Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateMenuItem}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-base">Add New Menu Item</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">English Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Masala Dosa"
                  value={nameEn}
                  onChange={(e) => setNameEn(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Hindi Name (हिंदी नाम)</label>
                <input
                  type="text"
                  placeholder="e.g. मसाला डोसा"
                  value={nameHi}
                  onChange={(e) => setNameHi(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Default Price (₹) *</label>
                  <input
                    type="number"
                    required
                    placeholder="e.g. 70"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold text-amber-400"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                  >
                    <option value="Veg Starter">Veg Starter</option>
                    <option value="Non-Veg Starter">Non-Veg Starter</option>
                    <option value="Veg Main Course">Veg Main Course</option>
                    <option value="Non-Veg Main Course">Non-Veg Main Course</option>
                    <option value="Bread">Bread</option>
                    <option value="Daal">Daal</option>
                    <option value="Rice">Rice</option>
                    <option value="Noodles/Chowmin">Noodles/Chowmin</option>
                    <option value="Chinese Rice">Chinese Rice</option>
                    <option value="Soup">Soup</option>
                    <option value="Miscellaneous">Miscellaneous</option>
                    <option value="Desserts">Desserts</option>
                    <option value="Tea/Coffee">Tea/Coffee</option>
                    <option value="Mocktail">Mocktail</option>
                    <option value="Shake">Shake</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="font-bold text-slate-300">Prints on KOT?</label>
                <input
                  type="checkbox"
                  checked={kotPrint}
                  onChange={(e) => setKotPrint(e.target.checked)}
                  className="w-4 h-4 accent-amber-500"
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-300">Eligible for Discount?</label>
                <input
                  type="checkbox"
                  checked={discountable}
                  onChange={(e) => setDiscountable(e.target.checked)}
                  className="w-4 h-4 accent-amber-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Create Item
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Digital Menu QR Modal */}
      {showDigitalMenuQrModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-slate-100 text-base">Digital Menu QR Code</h3>
              <button
                onClick={() => setShowDigitalMenuQrModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Customers can scan this QR code on any smartphone to view the digital menu for{' '}
              <strong>{sections.find((s) => s.id === selectedSection)?.name}</strong>.
            </p>

            {menuQrDataUrl && (
              <div className="bg-white p-3 rounded-2xl shadow-xl inline-block mx-auto">
                <img src={menuQrDataUrl} alt="Menu QR" className="w-48 h-48" />
              </div>
            )}

            <button
              onClick={() => setShowDigitalMenuQrModal(false)}
              className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
