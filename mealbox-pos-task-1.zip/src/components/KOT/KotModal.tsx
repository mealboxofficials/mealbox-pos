import React from 'react';
import { Order, OrderItem } from '../../types';
import { RESTAURANT_CONFIG } from '../../data/restaurantConfig';
import { MealBoxLogo } from '../MealBoxLogo';
import { Printer, X, Check, Utensils, AlertTriangle } from 'lucide-react';

interface KotModalProps {
  order: Order;
  newItemsOnly?: OrderItem[];
  onClose: () => void;
  onPrintComplete: () => void;
}

export const KotModal: React.FC<KotModalProps> = ({
  order,
  newItemsOnly,
  onClose,
  onPrintComplete,
}) => {
  // Determine which items to show on KOT ticket:
  // Must be kotPrint === true
  // If newItemsOnly passed and has length > 0, show those; otherwise show all kotPrint items
  const displayItems = (newItemsOnly && newItemsOnly.length > 0
    ? newItemsOnly
    : order.items
  ).filter((item) => item.kotPrint);

  const isEditOrderNewItems = newItemsOnly && newItemsOnly.length > 0;

  const printContainerRef = React.useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    if (printContainerRef.current) {
      const content = printContainerRef.current.innerHTML;
      const printWin = window.open('', '_blank', 'width=450,height=600');
      if (printWin) {
        printWin.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>KOT Ticket #${order.orderNumber}</title>
              <style>
                @page { size: auto; margin: 0; }
                body {
                  font-family: monospace, sans-serif;
                  margin: 0;
                  padding: 12px;
                  width: 80mm;
                  background: #fff;
                  color: #000;
                  font-size: 12px;
                  line-height: 1.3;
                }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .font-bold { font-weight: bold; }
                .font-extrabold { font-weight: 800; }
                .uppercase { text-transform: uppercase; }
                .flex { display: flex; }
                .justify-between { justify-content: space-between; }
                .items-center { align-items: center; }
                .border-b-2 { border-bottom: 2px dashed #000; }
                .border-t-2 { border-top: 2px dashed #000; }
                .border-t { border-top: 1px solid #000; }
                .border-b { border-bottom: 1px solid #000; }
                .py-1 { padding-top: 4px; padding-bottom: 4px; }
                .py-2 { padding-top: 6px; padding-bottom: 6px; }
                .my-2 { margin-top: 8px; margin-bottom: 8px; }
                .mt-4 { margin-top: 16px; }
              </style>
            </head>
            <body>
              ${content}
              <script>
                window.onload = function() {
                  window.print();
                  setTimeout(function() { window.close(); }, 300);
                };
              </script>
            </body>
          </html>
        `);
        printWin.document.close();
      } else {
        // Fallback for popup blocker
        window.print();
      }
    } else {
      window.print();
    }
    onPrintComplete();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-slate-100 text-lg">
              Kitchen Order Ticket (KOT)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Edit Notice Badge */}
        {isEditOrderNewItems && (
          <div className="bg-amber-500/20 border-b border-amber-500/40 p-2.5 px-4 flex items-center gap-2 text-xs font-bold text-amber-300">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>EDITED ORDER: Printing ONLY newly added items!</span>
          </div>
        )}

        {/* Printable ESC/POS Ticket Preview Area */}
        <div ref={printContainerRef} className="p-6 overflow-y-auto bg-amber-50 text-slate-950 font-mono text-sm shadow-inner rounded-b-xl my-2 mx-4 border border-amber-200">
          {/* Ticket Header */}
          <div className="text-center border-b-2 border-dashed border-slate-400 pb-3 mb-3 space-y-1">
            <div className="flex justify-center">
              <MealBoxLogo size="sm" showSubtitle={true} />
            </div>
            <p className="text-[10px] text-slate-700 font-bold">
              {RESTAURANT_CONFIG.address}
            </p>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-800 pt-1">
              {order.sectionName} Section • KOT Ticket #{order.orderNumber}
            </p>
            <p className="text-[10px] text-slate-500">
              Date: {new Date().toLocaleDateString()} Time: {new Date().toLocaleTimeString()}
            </p>
          </div>

          {/* Table / Order Meta */}
          <div className="flex justify-between items-center bg-amber-100 p-2 rounded mb-3 border border-amber-300 font-bold text-xs text-slate-900">
            <div>
              {order.mode === 'dine_in' ? (
                <span>TABLE: <strong className="text-sm font-black">{order.tableName}</strong></span>
              ) : (
                <span className="uppercase font-black text-xs text-amber-900">
                  MODE: {order.mode.replace('_', ' ')}
                </span>
              )}
            </div>
            {order.guestCount && <div>Guests: {order.guestCount}</div>}
          </div>

          <div className="text-xs space-y-0.5 mb-3 text-slate-800">
            {order.waiterName && <div>Waiter: <strong>{order.waiterName}</strong></div>}
            {order.customerName && <div>Customer: {order.customerName}</div>}
          </div>

          {/* Items Header */}
          <div className="border-t border-b border-slate-400 py-1 font-bold text-xs uppercase flex justify-between text-slate-900">
            <span className="w-8/12">Item (सामग्री)</span>
            <span className="w-4/12 text-right">Qty</span>
          </div>

          {/* Items List */}
          <div className="divide-y divide-dashed divide-slate-300 my-2">
            {displayItems.length === 0 ? (
              <div className="py-4 text-center text-xs text-slate-500 italic">
                No new KOT-eligible items to print.
              </div>
            ) : (
              displayItems.map((item, idx) => (
                <div key={idx} className="py-2">
                  <div className="flex justify-between items-start">
                    <div className="w-9/12">
                      <div className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                        <span>{item.nameHi || item.nameEn}</span>
                        {(item.isNew || isEditOrderNewItems) && (
                          <span className="bg-amber-300 text-slate-950 font-black text-[10px] px-1 py-0.2 rounded border border-amber-500">
                            NEW
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-600 font-medium">
                        {item.nameEn}
                      </div>
                      {item.note && (
                        <div className="text-[11px] text-rose-700 font-bold italic mt-0.5">
                          * Note: {item.note}
                        </div>
                      )}
                    </div>
                    <div className="w-3/12 text-right font-black text-base text-slate-900">
                      ×{item.quantity}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Ticket Footer */}
          <div className="border-t-2 border-dashed border-slate-400 pt-2 mt-4 text-center text-[10px] text-slate-600 uppercase tracking-widest font-bold">
            *** KITCHEN COPY ***
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 bg-slate-800 border-t border-slate-700 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-700"
          >
            Cancel
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm shadow-lg transition"
          >
            <Printer className="w-4 h-4" />
            <span>Print KOT Ticket</span>
          </button>
        </div>
      </div>
    </div>
  );
};
