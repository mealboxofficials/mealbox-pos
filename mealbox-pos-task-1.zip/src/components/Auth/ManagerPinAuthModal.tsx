import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldAlert, KeyRound, X, CheckCircle2 } from 'lucide-react';

interface ManagerPinAuthModalProps {
  title?: string;
  description?: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export const ManagerPinAuthModal: React.FC<ManagerPinAuthModalProps> = ({
  title = 'Manager Authorization Required',
  description = 'Please enter a Manager or Owner PIN code to approve this action.',
  onSuccess,
  onCancel,
}) => {
  const { verifyPin, showToast } = useApp();
  const [pin, setPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin) {
      setErrorMsg('PIN required');
      return;
    }

    if (verifyPin(pin)) {
      showToast('Manager authorization granted', 'success');
      onSuccess();
    } else {
      setErrorMsg('Invalid Manager/Owner PIN');
      setPin('');
    }
  };

  const handleKeyPress = (digit: string) => {
    if (pin.length < 6) {
      const next = pin + digit;
      setPin(next);
      setErrorMsg('');
      if (next.length === 4 && verifyPin(next)) {
        showToast('Manager authorization granted', 'success');
        onSuccess();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl relative">
        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/15 border border-amber-500/30 text-amber-400 rounded-xl">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">{title}</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">{description}</p>
            </div>
          </div>
          <button onClick={onCancel} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex justify-center gap-2 py-1">
            {[0, 1, 2, 3].map((idx) => {
              const isFilled = pin.length > idx;
              return (
                <div
                  key={idx}
                  className={`w-10 h-10 rounded-xl border-2 flex items-center justify-center transition-all ${
                    isFilled
                      ? 'border-amber-400 bg-amber-500/20 text-amber-400 font-bold text-lg'
                      : 'border-slate-800 bg-slate-950'
                  }`}
                >
                  {isFilled ? '●' : ''}
                </div>
              );
            })}
          </div>

          {errorMsg && (
            <div className="text-center text-xs font-bold text-rose-400 bg-rose-500/10 border border-rose-500/20 py-1 rounded-lg">
              {errorMsg}
            </div>
          )}

          {/* Touch Pad */}
          <div className="grid grid-cols-3 gap-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => handleKeyPress(num)}
                className="bg-slate-800 hover:bg-slate-700 py-2.5 rounded-xl text-base font-bold text-slate-100 border border-slate-700"
              >
                {num}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setPin('')}
              className="bg-slate-950 hover:bg-rose-500/20 text-rose-400 border border-slate-800 py-2.5 rounded-xl text-xs font-bold uppercase"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={() => handleKeyPress('0')}
              className="bg-slate-800 hover:bg-slate-700 py-2.5 rounded-xl text-base font-bold text-slate-100 border border-slate-700"
            >
              0
            </button>
            <button
              type="button"
              onClick={() => setPin((prev) => prev.slice(0, -1))}
              className="bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 py-2.5 rounded-xl text-xs font-bold"
            >
              ⌫
            </button>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="w-1/2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="w-1/2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Authorize</span>
            </button>
          </div>
        </form>

        <div className="text-[10px] text-center text-slate-500 flex items-center justify-center gap-1">
          <KeyRound className="w-3 h-3 text-amber-500" />
          <span>Demo Owner PIN: 1234 | Manager PIN: 9999</span>
        </div>
      </div>
    </div>
  );
};
