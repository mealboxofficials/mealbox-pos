import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Delete, KeyRound, Lock, UserCheck } from 'lucide-react';
import { UserRole } from '../../types';

interface PinLockModalProps {
  onClose?: () => void;
  isSwitchUserOnly?: boolean;
}

export const PinLockModal: React.FC<PinLockModalProps> = ({
  onClose,
  isSwitchUserOnly = false,
}) => {
  const { users, currentUser, loginWithPin, unlockTerminal, showToast } = useApp();

  const [selectedUserId, setSelectedUserId] = useState<string>(currentUser.id);
  const [pin, setPin] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  const selectedUser = users.find((u) => u.id === selectedUserId) || users[0];

  useEffect(() => {
    // Reset PIN entry when selected user changes
    setPin('');
    setErrorMsg('');
  }, [selectedUserId]);

  const handleKeyPress = (num: string) => {
    if (pin.length < 6) {
      const nextPin = pin + num;
      setPin(nextPin);
      setErrorMsg('');

      // Auto submit if 4 digits entered and matches
      if (nextPin.length === 4) {
        attemptLogin(nextPin);
      }
    }
  };

  const handleClear = () => {
    setPin('');
    setErrorMsg('');
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const attemptLogin = (pinToTest: string) => {
    let success = false;
    if (isSwitchUserOnly) {
      success = loginWithPin(selectedUserId, pinToTest);
    } else {
      success = unlockTerminal(pinToTest);
    }

    if (success) {
      setPin('');
      if (onClose) onClose();
    } else {
      setErrorMsg('Incorrect PIN code. Please try again.');
      setPin('');
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length >= 4) {
      attemptLogin(pin);
    } else {
      setErrorMsg('Please enter a 4-digit PIN');
    }
  };

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'owner':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'manager':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'cashier':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'waiter':
        return 'bg-sky-500/20 text-sky-400 border-sky-500/30';
      case 'kitchen':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
      default:
        return 'bg-slate-700 text-slate-300';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-6 shadow-2xl relative overflow-hidden">
        {/* Top Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex p-3 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-2xl mb-1 shadow-inner">
            <Lock className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-black text-slate-100 tracking-tight">
            {isSwitchUserOnly ? 'Switch Staff Account' : 'Terminal Security Locked'}
          </h2>
          <p className="text-xs text-slate-400">
            Select profile & enter 4-digit security PIN to access MealBox POS
          </p>
        </div>

        {/* User Selection Pills Grid */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Select Account Profile:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-40 overflow-y-auto scrollbar-thin p-1">
            {users.map((u) => {
              const isSelected = u.id === selectedUserId;
              return (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => setSelectedUserId(u.id)}
                  className={`p-2.5 rounded-xl border text-left transition flex flex-col justify-between ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500 text-amber-300 font-bold shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold truncate">{u.name}</span>
                    {isSelected && <UserCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                  </div>
                  <span
                    className={`mt-1 text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded border inline-block w-fit ${getRoleBadgeColor(
                      u.role
                    )}`}
                  >
                    {u.role}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected User Header */}
        <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center font-bold text-amber-400 border border-slate-700 text-sm">
              {selectedUser.name.charAt(0)}
            </div>
            <div>
              <div className="text-sm font-bold text-slate-100">{selectedUser.name}</div>
              <div className="text-[10px] text-slate-400">Mobile: {selectedUser.mobile}</div>
            </div>
          </div>
          <span
            className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${getRoleBadgeColor(
              selectedUser.role
            )}`}
          >
            {selectedUser.role}
          </span>
        </div>

        {/* PIN Entry Display Dots */}
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div className="flex justify-center items-center gap-3 py-2">
            {[0, 1, 2, 3].map((idx) => {
              const isFilled = pin.length > idx;
              return (
                <div
                  key={idx}
                  className={`w-12 h-12 rounded-2xl border-2 flex items-center justify-center transition-all ${
                    isFilled
                      ? 'border-amber-400 bg-amber-500/20 text-amber-400 text-xl font-bold shadow-lg scale-105'
                      : 'border-slate-800 bg-slate-950 text-slate-600'
                  }`}
                >
                  {isFilled ? '●' : ''}
                </div>
              );
            })}
          </div>

          {errorMsg && (
            <div className="text-center text-xs font-bold text-rose-400 bg-rose-500/10 border border-rose-500/20 py-1.5 rounded-xl animate-shake">
              {errorMsg}
            </div>
          )}

          {/* Keypad 0-9 */}
          <div className="grid grid-cols-3 gap-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => handleKeyPress(num)}
                className="bg-slate-800/80 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 border border-slate-700/80 rounded-2xl py-3 text-lg font-bold text-slate-100 transition shadow"
              >
                {num}
              </button>
            ))}
            <button
              type="button"
              onClick={handleClear}
              className="bg-slate-950 hover:bg-rose-500/20 text-rose-400 border border-slate-800 rounded-2xl py-3 text-xs font-bold uppercase transition"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={() => handleKeyPress('0')}
              className="bg-slate-800/80 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 border border-slate-700/80 rounded-2xl py-3 text-lg font-bold text-slate-100 transition shadow"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleBackspace}
              className="bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-2xl py-3 flex items-center justify-center transition"
            >
              <Delete className="w-5 h-5" />
            </button>
          </div>

          <div className="flex gap-2 pt-1">
            {isSwitchUserOnly && onClose && (
              <button
                type="button"
                onClick={onClose}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl text-xs transition"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold py-3 rounded-xl text-sm shadow-xl flex items-center justify-center gap-2 transition"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Unlock & Access POS</span>
            </button>
          </div>
        </form>

        {/* Demo Credentials Help Banner */}
        <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
          <div className="flex items-center gap-1 font-bold text-amber-400">
            <KeyRound className="w-3.5 h-3.5" />
            <span>Default Demo PIN Codes:</span>
          </div>
          <div className="grid grid-cols-2 gap-x-2 text-[10px] font-mono text-slate-300">
            <div>👑 Owner: <span className="text-amber-400 font-bold">1234</span></div>
            <div>👔 Manager: <span className="text-amber-400 font-bold">9999</span></div>
            <div>💳 Cashier: <span className="text-amber-400 font-bold">1111</span></div>
            <div>🍽️ Waiter: <span className="text-amber-400 font-bold">2222</span></div>
            <div>👨‍🍳 Kitchen: <span className="text-amber-400 font-bold">3333</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};
