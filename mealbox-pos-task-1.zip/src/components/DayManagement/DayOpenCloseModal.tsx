import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Denominations } from '../../types';
import { Sun, Moon, DollarSign, AlertCircle, X, CheckCircle2 } from 'lucide-react';

interface DayOpenCloseModalProps {
  onClose: () => void;
}

export const DayOpenCloseModal: React.FC<DayOpenCloseModalProps> = ({ onClose }) => {
  const {
    activeSection,
    daySessions,
    isDayOpen,
    openDaySession,
    closeDaySession,
    orders,
    expenses,
  } = useApp();

  const currentSession = daySessions[activeSection.id];

  const [denominations, setDenominations] = useState<Denominations>({
    c500: 0,
    c200: 0,
    c100: 0,
    c50: 0,
    c20: 0,
    c10: 0,
    coins: 0,
  });

  const calculatedTotalCash =
    denominations.c500 * 500 +
    denominations.c200 * 200 +
    denominations.c100 * 100 +
    denominations.c50 * 50 +
    denominations.c20 * 20 +
    denominations.c10 * 10 +
    denominations.coins;

  // Calculate expected cash on day close
  const cashSales = orders
    .filter(
      (o) =>
        o.sectionId === activeSection.id &&
        o.status === 'settled' &&
        o.paymentMode === 'cash'
    )
    .reduce((sum, o) => sum + o.paidAmount, 0);

  const cashExpenses = expenses
    .filter((e) => e.sectionId === activeSection.id && e.mode === 'cash')
    .reduce((sum, e) => sum + e.amount, 0);

  const expectedCash = (currentSession?.openingCash || 0) + cashSales - cashExpenses;
  const discrepancy = calculatedTotalCash - expectedCash;

  const handleOpenDay = () => {
    openDaySession(activeSection.id, calculatedTotalCash, denominations);
    onClose();
  };

  const handleCloseDay = () => {
    closeDaySession(activeSection.id, calculatedTotalCash, denominations, expectedCash);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            {isDayOpen ? (
              <Moon className="w-5 h-5 text-rose-400" />
            ) : (
              <Sun className="w-5 h-5 text-amber-400" />
            )}
            <h3 className="font-bold text-slate-100 text-lg">
              {isDayOpen ? `Close Day — ${activeSection.name}` : `Open Day — ${activeSection.name}`}
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Currency Denominations Calculator */}
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-300 uppercase block">
            Currency Denomination Breakdown
          </label>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="font-bold text-slate-300">₹500 ×</span>
              <input
                type="number"
                min="0"
                value={denominations.c500 || ''}
                onChange={(e) =>
                  setDenominations({ ...denominations, c500: Number(e.target.value) || 0 })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-amber-400"
              />
            </div>

            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="font-bold text-slate-300">₹200 ×</span>
              <input
                type="number"
                min="0"
                value={denominations.c200 || ''}
                onChange={(e) =>
                  setDenominations({ ...denominations, c200: Number(e.target.value) || 0 })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-amber-400"
              />
            </div>

            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="font-bold text-slate-300">₹100 ×</span>
              <input
                type="number"
                min="0"
                value={denominations.c100 || ''}
                onChange={(e) =>
                  setDenominations({ ...denominations, c100: Number(e.target.value) || 0 })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-amber-400"
              />
            </div>

            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="font-bold text-slate-300">₹50 ×</span>
              <input
                type="number"
                min="0"
                value={denominations.c50 || ''}
                onChange={(e) =>
                  setDenominations({ ...denominations, c50: Number(e.target.value) || 0 })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-amber-400"
              />
            </div>

            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="font-bold text-slate-300">₹20 ×</span>
              <input
                type="number"
                min="0"
                value={denominations.c20 || ''}
                onChange={(e) =>
                  setDenominations({ ...denominations, c20: Number(e.target.value) || 0 })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-amber-400"
              />
            </div>

            <div className="flex items-center justify-between bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="font-bold text-slate-300">₹10 / Coins</span>
              <input
                type="number"
                min="0"
                value={denominations.coins || ''}
                onChange={(e) =>
                  setDenominations({ ...denominations, coins: Number(e.target.value) || 0 })
                }
                className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-bold text-amber-400"
              />
            </div>
          </div>

          <div className="bg-slate-800 border border-slate-700 rounded-xl p-3 flex justify-between items-center">
            <span className="text-xs font-bold text-slate-300">Counted Total Cash:</span>
            <span className="text-xl font-black text-amber-400">₹{calculatedTotalCash}</span>
          </div>
        </div>

        {/* Day Close Expected vs Actual Summary */}
        {isDayOpen && (
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Opening Cash:</span>
              <span>₹{currentSession?.openingCash || 0}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>+ Cash Sales Today:</span>
              <span>+ ₹{cashSales}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>− Cash Expenses Today:</span>
              <span>− ₹{cashExpenses}</span>
            </div>
            <div className="flex justify-between font-bold text-slate-200 pt-1 border-t border-slate-800">
              <span>Expected Cash Balance:</span>
              <span>₹{expectedCash}</span>
            </div>

            {discrepancy !== 0 && (
              <div
                className={`p-2 rounded-lg font-bold flex items-center gap-1.5 mt-2 ${
                  discrepancy < 0 ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                }`}
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>
                  Discrepancy: {discrepancy >= 0 ? '+' : ''}₹{discrepancy}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
          >
            Cancel
          </button>

          {!isDayOpen ? (
            <button
              onClick={handleOpenDay}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-6 py-2.5 rounded-xl text-xs shadow-lg"
            >
              OPEN DAY SESSION
            </button>
          ) : (
            <button
              onClick={handleCloseDay}
              className="bg-rose-500 hover:bg-rose-400 text-white font-black px-6 py-2.5 rounded-xl text-xs shadow-lg"
            >
              CLOSE DAY SESSION
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
