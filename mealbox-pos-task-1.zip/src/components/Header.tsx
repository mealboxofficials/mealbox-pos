import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MealBoxLogo } from './MealBoxLogo';
import { RESTAURANT_CONFIG } from '../data/restaurantConfig';
import { PinLockModal } from './Auth/PinLockModal';
import { ManagerPinAuthModal } from './Auth/ManagerPinAuthModal';
import { DatabaseBackupModal } from './Database/DatabaseBackupModal';
import {
  UtensilsCrossed,
  Store,
  ChefHat,
  History,
  Users,
  UserCheck,
  Package,
  BookOpen,
  BarChart3,
  DollarSign,
  Wifi,
  WifiOff,
  Clock,
  ChevronDown,
  MapPin,
  PhoneCall,
  Lock,
  LockKeyhole,
  Database,
  LogOut,
  KeyRound,
} from 'lucide-react';
import { UserRole } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenDayModal: () => void;
  onOpenWalkInAdvanceModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenDayModal,
  onOpenWalkInAdvanceModal,
}) => {
  const {
    sections,
    activeSection,
    setActiveSectionId,
    users,
    currentUser,
    setCurrentUser,
    lockTerminal,
    isDayOpen,
    isOffline,
    setIsOffline,
    activeOrders,
  } = useApp();

  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showSectionDropdown, setShowSectionDropdown] = useState(false);
  const [showSwitchUserModal, setShowSwitchUserModal] = useState(false);
  const [showDatabaseModal, setShowDatabaseModal] = useState(false);

  // Tab authorization state
  const [pendingTab, setPendingTab] = useState<string | null>(null);

  // Count active orders for badge
  const pendingOrdersCount = activeOrders.length;

  // Role permissions matrix
  const isTabAllowedForRole = (tab: string, role: UserRole): boolean => {
    if (role === 'owner' || role === 'manager') return true;
    switch (role) {
      case 'cashier':
        return ['pos', 'kitchen', 'history', 'crm', 'inventory'].includes(tab);
      case 'waiter':
        return ['pos', 'history'].includes(tab);
      case 'kitchen':
        return ['kitchen', 'pos'].includes(tab);
      default:
        return false;
    }
  };

  const handleTabClick = (tabId: string) => {
    if (isTabAllowedForRole(tabId, currentUser.role)) {
      setActiveTab(tabId);
    } else {
      setPendingTab(tabId);
    }
  };

  const handleManagerAuthSuccess = () => {
    if (pendingTab) {
      setActiveTab(pendingTab);
      setPendingTab(null);
    }
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-40 shadow-xl">
      {/* Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Section Selector */}
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <MealBoxLogo size="md" showSubtitle={true} />
          </div>

          <div className="hidden lg:flex flex-col text-xs text-slate-400 border-l border-slate-800 pl-3">
            <div className="flex items-center gap-1 text-slate-300 font-medium">
              <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{RESTAURANT_CONFIG.address}</span>
            </div>
            <div className="flex items-center gap-1 text-amber-400 font-bold mt-0.5">
              <PhoneCall className="w-3.5 h-3.5 shrink-0" />
              <span>Contact / Orders: {RESTAURANT_CONFIG.contactPhone}</span>
            </div>
          </div>

          {/* Section Selector */}
          <div className="relative">
            <button
              onClick={() => setShowSectionDropdown(!showSectionDropdown)}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-750 px-3 py-1.5 rounded-lg text-sm font-semibold border border-slate-700 text-amber-400 transition"
            >
              <Store className="w-4 h-4 text-amber-400" />
              <span>{activeSection.name}</span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </button>

            {showSectionDropdown && (
              <div className="absolute left-0 mt-2 w-56 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl z-50 py-1 overflow-hidden">
                <div className="px-3 py-1.5 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Select Restaurant Section
                </div>
                {sections.map((sec) => (
                  <button
                    key={sec.id}
                    onClick={() => {
                      setActiveSectionId(sec.id);
                      setShowSectionDropdown(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 text-sm font-medium flex items-center justify-between hover:bg-slate-700 transition ${
                      sec.id === activeSection.id ? 'bg-amber-500/10 text-amber-400 font-bold' : 'text-slate-200'
                    }`}
                  >
                    <span>{sec.name}</span>
                    <span className="text-xs text-slate-400">({sec.tableCount} tables)</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Utility Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Day Open/Closed Status */}
          <button
            onClick={onOpenDayModal}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition shadow ${
              isDayOpen
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25'
                : 'bg-rose-500/15 text-rose-400 border border-rose-500/30 hover:bg-rose-500/25'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{isDayOpen ? 'DAY OPEN' : 'DAY CLOSED'}</span>
          </button>

          {/* Database Backup & Restore Modal */}
          <button
            onClick={() => setShowDatabaseModal(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-400 border border-slate-700 rounded-lg text-xs font-bold transition shadow"
            title="Database Backup, Restore & Persistence"
          >
            <Database className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Database</span>
          </button>

          {/* Offline Toggle */}
          <button
            onClick={() => setIsOffline(!isOffline)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition ${
              isOffline
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300 animate-pulse'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
            }`}
            title="Toggle offline mode simulation"
          >
            {isOffline ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{isOffline ? 'OFFLINE' : 'ONLINE'}</span>
          </button>

          {/* Lock Terminal Security Button */}
          <button
            onClick={lockTerminal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 rounded-lg text-xs font-bold transition"
            title="Lock POS Terminal"
          >
            <Lock className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Lock</span>
          </button>

          {/* Active User / Role Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowRoleDropdown(!showRoleDropdown)}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-700 text-slate-200"
            >
              <UserCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>{currentUser.name}</span>
              <span className="bg-slate-700 text-amber-400 px-1.5 py-0.5 rounded text-[10px] uppercase font-bold">
                {currentUser.role}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showRoleDropdown && (
              <div className="absolute right-0 mt-2 w-56 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl z-50 py-1 divide-y divide-slate-700/50">
                <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase flex items-center justify-between">
                  <span>Switch Staff Account</span>
                  <KeyRound className="w-3 h-3 text-amber-400" />
                </div>
                <div className="py-1">
                  {users.map((u) => (
                    <button
                      key={u.id}
                      onClick={() => {
                        setShowRoleDropdown(false);
                        setShowSwitchUserModal(true);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-xs font-medium flex items-center justify-between hover:bg-slate-700 ${
                        u.id === currentUser.id ? 'text-amber-400 font-bold bg-slate-750' : 'text-slate-300'
                      }`}
                    >
                      <span>{u.name}</span>
                      <span className="text-[10px] uppercase bg-slate-900 px-1.5 py-0.5 rounded text-slate-400">
                        {u.role}
                      </span>
                    </button>
                  ))}
                </div>
                <div className="p-1">
                  <button
                    onClick={() => {
                      setShowRoleDropdown(false);
                      setShowSwitchUserModal(true);
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs font-bold text-amber-400 hover:bg-slate-700 rounded-lg flex items-center gap-1.5"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>PIN Login / Switch User</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 overflow-x-auto scrollbar-none border-t border-slate-800">
        <nav className="flex space-x-1 py-1.5 min-w-max">
          {[
            { id: 'pos', label: 'POS Billing', icon: UtensilsCrossed },
            { id: 'kitchen', label: 'Kitchen Display', icon: ChefHat, badge: pendingOrdersCount },
            { id: 'history', label: 'Order History', icon: History },
            { id: 'crm', label: 'Customers CRM', icon: Users },
            { id: 'reports', label: 'Reports & P&L', icon: BarChart3 },
            { id: 'expenses', label: 'Expenses', icon: DollarSign },
            { id: 'staff', label: 'Staff & Payroll', icon: UserCheck },
            { id: 'inventory', label: 'Inventory', icon: Package },
            { id: 'menu', label: 'Menu & Pricing', icon: BookOpen },
          ].map((tab) => {
            const Icon = tab.icon;
            const isAllowed = isTabAllowedForRole(tab.id, currentUser.role);
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => handleTabClick(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition relative ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : isAllowed
                    ? 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    : 'text-slate-500 hover:bg-slate-800/60 hover:text-slate-400'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>

                {!isAllowed && (
                  <LockKeyhole className="w-3 h-3 text-amber-400/80 shrink-0" title="Manager PIN Required" />
                )}

                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="bg-rose-500 text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Modals */}
      {showSwitchUserModal && (
        <PinLockModal isSwitchUserOnly={true} onClose={() => setShowSwitchUserModal(false)} />
      )}

      {showDatabaseModal && (
        <DatabaseBackupModal onClose={() => setShowDatabaseModal(false)} />
      )}

      {pendingTab && (
        <ManagerPinAuthModal
          title={`Manager PIN Required for ${pendingTab.toUpperCase()}`}
          description={`Your active role (${currentUser.role.toUpperCase()}) requires Manager approval to open ${pendingTab}.`}
          onSuccess={handleManagerAuthSuccess}
          onCancel={() => setPendingTab(null)}
        />
      )}
    </header>
  );
};
