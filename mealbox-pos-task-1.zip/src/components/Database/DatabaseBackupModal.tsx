import React, { useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Database, Download, Upload, RotateCcw, X, ShieldAlert, CheckCircle } from 'lucide-react';

interface DatabaseBackupModalProps {
  onClose: () => void;
}

export const DatabaseBackupModal: React.FC<DatabaseBackupModalProps> = ({ onClose }) => {
  const {
    exportDatabase,
    importDatabase,
    resetDatabase,
    orders,
    customers,
    menuItems,
    staff,
    inventory,
    showToast,
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importDatabase(content);
        if (success) {
          onClose();
        }
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmReset = () => {
    resetDatabase();
    setConfirmReset(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 space-y-6 shadow-2xl relative">
        {/* Top Title */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/15 border border-amber-500/30 text-amber-400 rounded-2xl">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-base">Local Database & Persistence Engine</h3>
              <p className="text-xs text-slate-400">
                Backup, restore, and maintain local restaurant records
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Local Storage Database Health Overview */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Current Database Inventory Status
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Total Orders</div>
              <div className="text-base font-extrabold text-amber-400">{orders.length}</div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Menu Items</div>
              <div className="text-base font-extrabold text-amber-400">{menuItems.length}</div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Customers</div>
              <div className="text-base font-extrabold text-amber-400">{customers.length}</div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Staff Members</div>
              <div className="text-base font-extrabold text-amber-400">{staff.length}</div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Inventory Items</div>
              <div className="text-base font-extrabold text-amber-400">{inventory.length}</div>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Storage Mode</div>
              <div className="text-xs font-extrabold text-emerald-400">Offline JSON</div>
            </div>
          </div>
        </div>

        {/* Database Actions */}
        <div className="space-y-3">
          {/* Export JSON Backup */}
          <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/80 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Download className="w-4 h-4 text-emerald-400" />
                <span>Export Data Backup (JSON)</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Download full data dump of orders, menu, customers, staff & inventory.
              </p>
            </div>
            <button
              onClick={exportDatabase}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs shadow-md transition shrink-0"
            >
              Export JSON
            </button>
          </div>

          {/* Import JSON Restore */}
          <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/80 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Upload className="w-4 h-4 text-sky-400" />
                <span>Restore Data from Backup</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Upload a previously saved .json backup file to restore database.
              </p>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs shadow-md transition shrink-0"
            >
              Restore JSON
            </button>
          </div>

          {/* Reset Factory Settings */}
          <div className="bg-rose-500/10 p-3.5 rounded-2xl border border-rose-500/30 flex items-center justify-between">
            <div>
              <div className="text-sm font-bold text-rose-300 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-rose-400" />
                <span>Reset to Factory Default</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Clear all active records and reset menu, staff, and settings to original defaults.
              </p>
            </div>
            <button
              onClick={() => setConfirmReset(true)}
              className="bg-rose-500 hover:bg-rose-400 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-md transition shrink-0"
            >
              Reset All
            </button>
          </div>
        </div>

        {/* Reset Confirmation Prompt */}
        {confirmReset && (
          <div className="bg-rose-950/80 border border-rose-600/60 p-4 rounded-2xl space-y-3 animate-shake">
            <div className="flex items-center gap-2 text-rose-300 font-bold text-xs">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
              <span>Are you sure you want to erase all current data and reset?</span>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button
                onClick={() => setConfirmReset(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReset}
                className="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-600 text-white hover:bg-rose-500 shadow"
              >
                Yes, Reset Everything
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
