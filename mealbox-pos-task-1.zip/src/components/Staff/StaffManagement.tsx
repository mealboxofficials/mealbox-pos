import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Staff, UserRole } from '../../types';
import { UserCheck, DollarSign, Plus, Phone, Calendar, Shield, X, KeyRound, UserPlus } from 'lucide-react';

export const StaffManagement: React.FC = () => {
  const { staff, users, addStaffAdvance, addStaffMember, showToast } = useApp();

  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [advanceAmount, setAdvanceAmount] = useState('');
  const [advanceNote, setAdvanceNote] = useState('');

  // Add staff modal state
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<UserRole>('waiter');
  const [newStaffMobile, setNewStaffMobile] = useState('');
  const [newStaffSalary, setNewStaffSalary] = useState('');
  const [newStaffPin, setNewStaffPin] = useState('');

  const handleRecordAdvance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaff || !advanceAmount) return;

    addStaffAdvance(selectedStaff.id, Number(advanceAmount) || 0, advanceNote);

    setSelectedStaff(null);
    setAdvanceAmount('');
    setAdvanceNote('');
  };

  const handleAddStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffName || !newStaffMobile || !newStaffSalary || !newStaffPin) {
      showToast('Please fill all required fields', 'error');
      return;
    }

    if (newStaffPin.length < 4) {
      showToast('PIN must be at least 4 digits', 'error');
      return;
    }

    addStaffMember({
      name: newStaffName,
      role: newStaffRole,
      mobile: newStaffMobile,
      salary: Number(newStaffSalary) || 0,
      pin: newStaffPin,
      joinDate: new Date().toISOString().split('T')[0],
      assignedSections: ['sec-mealbox', 'sec-ac-hall', 'sec-garden', 'sec-swiggy'],
    });

    setNewStaffName('');
    setNewStaffMobile('');
    setNewStaffSalary('');
    setNewStaffPin('');
    setShowAddStaffModal(false);
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-105px)] text-slate-100 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Staff Management & Payroll</h2>
            <p className="text-xs text-slate-400">
              Salary advances, per-day salary calculation (Monthly ÷ 30), and PIN-secured access
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddStaffModal(true)}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg transition"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add Staff Member & PIN</span>
        </button>
      </div>

      {/* Staff Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {staff.map((st) => {
          const perDaySalary = Math.round(st.salary / 30);
          const matchedUser = users.find((u) => u.name === st.name || u.mobile === st.mobile);

          return (
            <div
              key={st.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-lg flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-base text-slate-100">{st.name}</h3>
                    <span className="text-[10px] uppercase font-bold bg-slate-800 text-amber-400 px-2 py-0.5 rounded">
                      {st.role}
                    </span>
                  </div>
                  {matchedUser && (
                    <span
                      className="text-[10px] font-mono font-bold bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded border border-amber-500/20 flex items-center gap-1"
                      title="Assigned POS Security PIN"
                    >
                      <KeyRound className="w-3 h-3" />
                      <span>PIN: {matchedUser.pin}</span>
                    </span>
                  )}
                </div>

                <div className="text-xs text-slate-400 mt-2 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span>{st.mobile}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>Joined: {st.joinDate}</span>
                  </div>
                </div>

                {/* Salary Financial Ledger */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 my-3 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span>Monthly Salary:</span>
                    <span className="font-bold text-slate-100">₹{st.salary}</span>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Per-Day Salary (÷30):</span>
                    <span className="font-semibold text-amber-400">₹{perDaySalary}/day</span>
                  </div>
                  <div className="flex justify-between text-rose-400 pt-1 border-t border-slate-800">
                    <span>Advance Given:</span>
                    <span className="font-bold">₹{st.advanceTotal}</span>
                  </div>
                  <div className="flex justify-between text-emerald-400 font-bold">
                    <span>Remaining Balance:</span>
                    <span>₹{st.duesTotal}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setSelectedStaff(st)}
                className="w-full bg-slate-800 hover:bg-slate-750 text-amber-400 font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition"
              >
                <DollarSign className="w-4 h-4" />
                <span>Give Salary Advance</span>
              </button>
            </div>
          );
        })}
      </div>

      {/* Give Advance Modal */}
      {selectedStaff && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleRecordAdvance}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-slate-100 text-sm">
                Record Salary Advance — {selectedStaff.name}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedStaff(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Advance Amount (₹) *</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 1000"
                  value={advanceAmount}
                  onChange={(e) => setAdvanceAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold text-base text-amber-400"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Reason / Note</label>
                <input
                  type="text"
                  placeholder="e.g. Festival advance"
                  value={advanceNote}
                  onChange={(e) => setAdvanceNote(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedStaff(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Save Advance
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Staff Modal */}
      {showAddStaffModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleAddStaffSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-slate-100 text-base">Add New Staff & System Access</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddStaffModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Staff Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Sharma"
                  value={newStaffName}
                  onChange={(e) => setNewStaffName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">System Role *</label>
                  <select
                    value={newStaffRole}
                    onChange={(e) => setNewStaffRole(e.target.value as UserRole)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-semibold"
                  >
                    <option value="waiter">Waiter / Captain</option>
                    <option value="cashier">Billing Cashier</option>
                    <option value="kitchen">Kitchen Staff</option>
                    <option value="manager">Restaurant Manager</option>
                    <option value="owner">Restaurant Owner</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Mobile Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 9876543210"
                    value={newStaffMobile}
                    onChange={(e) => setNewStaffMobile(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-300 block mb-1">Monthly Salary (₹) *</label>
                  <input
                    type="number"
                    required
                    placeholder="e.g. 18000"
                    value={newStaffSalary}
                    onChange={(e) => setNewStaffSalary(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold text-amber-400"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-300 block mb-1">Security PIN (4 digits) *</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    placeholder="e.g. 5555"
                    value={newStaffPin}
                    onChange={(e) => setNewStaffPin(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-mono font-bold text-amber-400"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddStaffModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-xs shadow-lg"
              >
                Save & Grant Access
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
