import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Customer } from '../../types';
import {
  Users,
  Search,
  Plus,
  Phone,
  MessageSquare,
  MapPin,
  Clock,
  ArrowDownCircle,
  ArrowUpCircle,
  PlusCircle,
  X,
  CreditCard,
  DollarSign,
} from 'lucide-react';

export const CustomerManagement: React.FC = () => {
  const { customers, addCustomer, addWalkInAdvance, showToast } = useApp();
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [showWalkInModal, setShowWalkInModal] = useState(false);

  // Add Customer Form
  const [newCustName, setNewCustName] = useState('');
  const [newCustMobile, setNewCustMobile] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');

  // Walk-in Advance Form
  const [advMobile, setAdvMobile] = useState('');
  const [advName, setAdvName] = useState('');
  const [advAmount, setAdvAmount] = useState('');

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.mobile.includes(searchQuery)
  );

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustMobile) {
      showToast('Mobile number is required', 'error');
      return;
    }

    addCustomer({
      name: newCustName || 'Customer',
      mobile: newCustMobile,
      whatsapp: newCustMobile,
      address: newCustAddress,
      dues: 0,
      advance: 0,
    });

    setNewCustName('');
    setNewCustMobile('');
    setNewCustAddress('');
    setShowAddCustomerModal(false);
  };

  const handleSaveWalkInAdvance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!advMobile || !advAmount) {
      showToast('Mobile and Amount are required', 'error');
      return;
    }

    addWalkInAdvance(advMobile, advName, Number(advAmount) || 0);

    setAdvMobile('');
    setAdvName('');
    setAdvAmount('');
    setShowWalkInModal(false);
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-105px)] text-slate-100 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Customer CRM & Ledger</h2>
            <p className="text-xs text-slate-400">
              Track customer dues, advance credit balances, and order histories
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowWalkInModal(true)}
            className="bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2"
          >
            <DollarSign className="w-4 h-4" />
            <span>Walk-in Advance Payment</span>
          </button>

          <button
            onClick={() => setShowAddCustomerModal(true)}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 shadow-lg"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Customer</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="text"
          placeholder="Search customer by name or mobile number..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
        />
      </div>

      {/* Customer List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">Customer</th>
                <th className="p-4">Contact & Address</th>
                <th className="p-4">Pending Dues</th>
                <th className="p-4">Advance Credit</th>
                <th className="p-4">Total Orders</th>
                <th className="p-4">Total Spent</th>
                <th className="p-4">Last Visit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500">
                    No matching customers found
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-800/50 transition">
                    <td className="p-4 font-bold text-slate-100">{c.name}</td>
                    <td className="p-4 space-y-0.5">
                      <div className="flex items-center gap-1.5 text-slate-300">
                        <Phone className="w-3 h-3 text-amber-400" />
                        <span>{c.mobile}</span>
                      </div>
                      {c.address && (
                        <div className="flex items-center gap-1 text-[11px] text-slate-400">
                          <MapPin className="w-3 h-3 text-slate-500" />
                          <span>{c.address}</span>
                        </div>
                      )}
                    </td>

                    {/* Pending Dues */}
                    <td className="p-4 font-bold">
                      {c.dues > 0 ? (
                        <span className="text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-lg border border-rose-500/20">
                          ₹{c.dues}
                        </span>
                      ) : (
                        <span className="text-slate-500">₹0</span>
                      )}
                    </td>

                    {/* Advance Credit */}
                    <td className="p-4 font-bold">
                      {c.advance > 0 ? (
                        <span className="text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                          ₹{c.advance}
                        </span>
                      ) : (
                        <span className="text-slate-500">₹0</span>
                      )}
                    </td>

                    <td className="p-4 font-semibold">{c.totalOrders} orders</td>
                    <td className="p-4 font-bold text-amber-400">₹{c.totalSpent}</td>
                    <td className="p-4 text-slate-400 text-[11px]">
                      {new Date(c.lastVisit).toLocaleDateString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddCustomerModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateCustomer}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-base">Add New Customer</h3>
              <button
                type="button"
                onClick={() => setShowAddCustomerModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Customer Mobile *</label>
                <input
                  type="text"
                  required
                  placeholder="10-digit mobile number"
                  value={newCustMobile}
                  onChange={(e) => setNewCustMobile(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. Rajesh Kumar"
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Address</label>
                <textarea
                  placeholder="Delivery or street address"
                  value={newCustAddress}
                  onChange={(e) => setNewCustAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 h-20"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddCustomerModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Save Customer
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Walk-in Advance Payment Modal */}
      {showWalkInModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveWalkInAdvance}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-base">Record Walk-in Advance Credit</h3>
              <button
                type="button"
                onClick={() => setShowWalkInModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Customer Mobile *</label>
                <input
                  type="text"
                  required
                  placeholder="10-digit mobile"
                  value={advMobile}
                  onChange={(e) => setAdvMobile(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Customer Name</label>
                <input
                  type="text"
                  placeholder="Full name"
                  value={advName}
                  onChange={(e) => setAdvName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Advance Amount Received (₹) *</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 500"
                  value={advAmount}
                  onChange={(e) => setAdvAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 text-lg font-bold text-emerald-400"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowWalkInModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Save Advance Credit
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
