import React from 'react';

interface MealBoxLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  className?: string;
}

export const MealBoxLogo: React.FC<MealBoxLogoProps> = ({
  size = 'md',
  showSubtitle = false,
  className = '',
}) => {
  const dimensionMap = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-20 h-20',
    xl: 'w-32 h-32',
  };

  const textMap = {
    sm: 'text-base font-black',
    md: 'text-xl font-black',
    lg: 'text-2xl font-black',
    xl: 'text-4xl font-black',
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Golden Badge Logo Container */}
      <div className={`relative flex items-center justify-center shrink-0 ${dimensionMap[size]}`}>
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full drop-shadow-md"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="50%" stopColor="#FBBF24" />
              <stop offset="100%" stopColor="#D97706" />
            </linearGradient>
            <linearGradient id="goldCircleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FCD34D" />
              <stop offset="100%" stopColor="#B45309" />
            </linearGradient>
          </defs>

          {/* Outer Decorative Circle Ring */}
          <circle
            cx="100"
            cy="100"
            r="90"
            stroke="url(#goldCircleGrad)"
            strokeWidth="5"
            fill="none"
          />

          {/* Bottom Left Swirl Ornament */}
          <path
            d="M 25 145 C 5 180, 45 195, 65 170 C 80 150, 45 125, 20 145"
            stroke="url(#goldCircleGrad)"
            strokeWidth="6"
            strokeLinecap="round"
            fill="none"
          />

          {/* Steam Rising Lines */}
          <path
            d="M 80 50 C 75 40, 85 30, 80 20"
            stroke="url(#goldGrad)"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M 100 45 C 95 32, 105 22, 100 12"
            stroke="url(#goldGrad)"
            strokeWidth="5"
            strokeLinecap="round"
          />
          <path
            d="M 120 50 C 115 40, 125 30, 120 20"
            stroke="url(#goldGrad)"
            strokeWidth="4"
            strokeLinecap="round"
          />

          {/* Cooking Pot / Vessel */}
          {/* Lid Handle */}
          <rect x="92" y="52" width="16" height="8" rx="2" fill="url(#goldGrad)" />
          {/* Lid */}
          <path
            d="M 60 75 C 60 58, 140 58, 140 75 Z"
            fill="url(#goldGrad)"
          />
          {/* Main Pot Body */}
          <path
            d="M 55 80 H 145 V 120 C 145 132, 135 142, 122 142 H 78 C 65 142, 55 132, 55 120 Z"
            fill="url(#goldGrad)"
          />
          {/* Pot Handles */}
          <rect x="45" y="90" width="10" height="12" rx="3" fill="url(#goldGrad)" />
          <rect x="145" y="90" width="10" height="12" rx="3" fill="url(#goldGrad)" />

          {/* Brand Text Inside Pot/Circle */}
          <text
            x="100"
            y="168"
            textAnchor="middle"
            fill="url(#goldCircleGrad)"
            fontSize="22"
            fontWeight="900"
            fontFamily="sans-serif"
            letterSpacing="1"
          >
            MealBox
          </text>
        </svg>
      </div>

      {/* Brand Text Side */}
      <div>
        <div className={`tracking-wider text-amber-400 font-black ${textMap[size]}`}>
          MealBox Restaurant
        </div>
        {showSubtitle && (
          <div className="text-[11px] font-semibold text-amber-300/80 tracking-wide italic">
            (A Glocal Restaurant)
          </div>
        )}
      </div>
    </div>
  );
};
