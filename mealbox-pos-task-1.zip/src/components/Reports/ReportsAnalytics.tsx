import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Order, OrderItem, MenuItem } from '../../types';
import { BillModal } from '../Billing/BillModal';
import { KotModal } from '../KOT/KotModal';
import { RESTAURANT_CONFIG } from '../../data/restaurantConfig';
import { MealBoxLogo } from '../MealBoxLogo';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  CreditCard,
  QrCode,
  Gift,
  ShieldAlert,
  Calendar,
  Filter,
  Download,
  Search,
  CheckCircle2,
  Clock,
  XCircle,
  Plus,
  Edit3,
  Printer,
  Eye,
  X,
  Utensils,
  User,
  Tag,
  Lock,
  ChevronRight,
  AlertTriangle,
  Receipt,
  RotateCcw,
} from 'lucide-react';

export const ReportsAnalytics: React.FC = () => {
  const {
    orders,
    expenses,
    activeSection,
    sections,
    menuItems,
    staff,
    saveOrder,
    voidOrder,
    generateKot,
    showToast,
  } = useApp();

  const [dateFilter, setDateFilter] = useState<'today' | 'yesterday' | 'week' | 'month' | 'custom_date' | 'all'>('today');
  const [customDate, setCustomDate] = useState<string>('');
  const [customMonth, setCustomMonth] = useState<string>('');
  const [selectedSectionFilter, setSelectedSectionFilter] = useState<string>('all');
  const [historySearchQuery, setHistorySearchQuery] = useState('');
  const [historyTab, setHistoryTab] = useState<'all' | 'active' | 'settled' | 'running' | 'pending' | 'void' | 'credit' | 'free'>('all');

  // Modals state
  const [selectedOrderForPay, setSelectedOrderForPay] = useState<Order | null>(null);
  const [selectedOrderForEdit, setSelectedOrderForEdit] = useState<Order | null>(null);
  const [selectedOrderForView, setSelectedOrderForView] = useState<Order | null>(null);
  const [selectedOrderForVoid, setSelectedOrderForVoid] = useState<Order | null>(null);
  const [showKotModalOrder, setShowKotModalOrder] = useState<{ order: Order; newItems: OrderItem[] } | null>(null);

  // Void modal inputs
  const [voidReason, setVoidReason] = useState('');
  const [voidPin, setVoidPin] = useState('');

  // Date filtering logic
  const now = new Date();
  const filterOrders = orders.filter((o) => {
    if (selectedSectionFilter !== 'all' && o.sectionId !== selectedSectionFilter) return false;

    const orderDate = new Date(o.createdAt);
    if (dateFilter === 'today') {
      return orderDate.toDateString() === now.toDateString();
    }
    if (dateFilter === 'yesterday') {
      const yest = new Date(now);
      yest.setDate(now.getDate() - 1);
      return orderDate.toDateString() === yest.toDateString();
    }
    if (dateFilter === 'week') {
      const weekAgo = new Date(now);
      weekAgo.setDate(now.getDate() - 7);
      return orderDate >= weekAgo;
    }
    if (dateFilter === 'month') {
      return (
        orderDate.getMonth() === now.getMonth() &&
        orderDate.getFullYear() === now.getFullYear()
      );
    }
    if (dateFilter === 'custom_date') {
      if (customDate) {
        const yyyy = orderDate.getFullYear();
        const mm = String(orderDate.getMonth() + 1).padStart(2, '0');
        const dd = String(orderDate.getDate()).padStart(2, '0');
        const dateStr = `${yyyy}-${mm}-${dd}`;
        if (dateStr !== customDate) return false;
      }
      if (customMonth) {
        const yyyy = orderDate.getFullYear();
        const mm = String(orderDate.getMonth() + 1).padStart(2, '0');
        const monthStr = `${yyyy}-${mm}`;
        if (monthStr !== customMonth) return false;
      }
      return true;
    }
    if (dateFilter === 'all') {
      return true;
    }
    return true;
  });

  const filterExpenses = expenses.filter((e) => {
    if (selectedSectionFilter !== 'all' && e.sectionId !== selectedSectionFilter) return false;
    return true;
  });

  // Calculate Tab Metrics
  const settledPaidOrders = filterOrders.filter((o) => o.status === 'settled' && o.mode !== 'free' && o.mode !== 'due');
  const activeOrdersList = filterOrders.filter((o) => o.status === 'active');
  const runningOrdersList = filterOrders.filter((o) => o.status === 'active' && !o.advanceDeposit && (!o.paidAmount || o.paidAmount === 0));
  const pendingOrdersList = filterOrders.filter((o) => o.status === 'active' && ((o.advanceDeposit && o.advanceDeposit > 0) || (o.paidAmount && o.paidAmount > 0) || o.discountAmount > 0));
  const voidOrdersList = filterOrders.filter((o) => o.status === 'void');
  const creditOrdersList = filterOrders.filter((o) => o.mode === 'due' || (o.attachedDues && o.attachedDues > 0));
  const freeOrdersList = filterOrders.filter((o) => o.mode === 'free' || o.discountPercent === 100);

  const totalSale = settledPaidOrders.reduce((sum, o) => sum + o.finalTotal, 0);

  const cashCollected = settledPaidOrders
    .filter((o) => o.paymentMode === 'cash')
    .reduce((sum, o) => sum + o.finalTotal, 0);

  const upiOnline = settledPaidOrders
    .filter((o) => o.paymentMode === 'upi' || o.paymentMode === 'card')
    .reduce((sum, o) => sum + o.finalTotal, 0);

  const splitPayTotal = settledPaidOrders
    .filter((o) => o.paymentMode === 'split')
    .reduce((sum, o) => sum + o.finalTotal, 0);

  const freeOrderValue = freeOrdersList.reduce((sum, o) => sum + o.subtotal, 0);
  const totalExpenses = filterExpenses.reduce((sum, e) => sum + e.amount, 0);
  const netPnl = totalSale - totalExpenses;

  // Item-wise sales aggregation
  const itemSalesMap: Record<string, { nameEn: string; qty: number; revenue: number }> = {};
  settledPaidOrders.forEach((o) => {
    o.items.forEach((it) => {
      if (!itemSalesMap[it.nameEn]) {
        itemSalesMap[it.nameEn] = { nameEn: it.nameEn, qty: 0, revenue: 0 };
      }
      itemSalesMap[it.nameEn].qty += it.quantity;
      itemSalesMap[it.nameEn].revenue += it.price * it.quantity;
    });
  });

  const topSellingItems = Object.values(itemSalesMap)
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  // Waiter performance breakdown
  const waiterMap: Record<string, { count: number; revenue: number }> = {};
  settledPaidOrders.forEach((o) => {
    const waiter = o.waiterName || 'Unassigned';
    if (!waiterMap[waiter]) {
      waiterMap[waiter] = { count: 0, revenue: 0 };
    }
    waiterMap[waiter].count += 1;
    waiterMap[waiter].revenue += o.finalTotal;
  });

  // History Tab filtering
  const historyOrders = filterOrders.filter((o) => {
    if (historyTab === 'active') {
      if (o.status !== 'active') return false;
    } else if (historyTab === 'settled') {
      if (o.status !== 'settled' || o.mode === 'free' || o.mode === 'due') return false;
    } else if (historyTab === 'running') {
      if (o.status !== 'active') return false;
      if ((o.advanceDeposit && o.advanceDeposit > 0) || (o.paidAmount && o.paidAmount > 0)) return false;
    } else if (historyTab === 'pending') {
      if (o.status !== 'active') return false;
      if (!((o.advanceDeposit && o.advanceDeposit > 0) || (o.paidAmount && o.paidAmount > 0) || o.discountAmount > 0)) return false;
    } else if (historyTab === 'void') {
      if (o.status !== 'void') return false;
    } else if (historyTab === 'credit') {
      if (o.mode !== 'due' && (!o.attachedDues || o.attachedDues <= 0)) return false;
    } else if (historyTab === 'free') {
      if (o.mode !== 'free' && o.discountPercent !== 100) return false;
    }

    if (historySearchQuery.trim()) {
      const q = historySearchQuery.toLowerCase();
      return (
        o.orderNumber.toString().includes(q) ||
        (o.customerName && o.customerName.toLowerCase().includes(q)) ||
        (o.customerMobile && o.customerMobile.includes(q)) ||
        (o.tableName && o.tableName.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const exportReportCsv = () => {
    showToast('Exported Financial Report to CSV/Excel format', 'success');
  };

  const handleConfirmVoid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrderForVoid) return;
    if (!voidReason.trim()) {
      showToast('Please enter a void reason', 'error');
      return;
    }
    const success = voidOrder(selectedOrderForVoid.id, voidReason, voidPin);
    if (success) {
      setSelectedOrderForVoid(null);
      setVoidReason('');
      setVoidPin('');
    }
  };

  return (
    <div className="p-4 sm:p-6 bg-slate-950 min-h-[calc(100vh-105px)] text-slate-100 space-y-6">
      {/* ORDER HISTORY CONTAINER */}
      <div className="bg-slate-900 border-2 border-amber-500/40 rounded-2xl p-5 space-y-5 shadow-2xl">
        {/* Top Header */}
        <div className="space-y-3 border-b border-slate-800 pb-3">
          <div className="flex items-center justify-center gap-2">
            <div className="p-2 bg-amber-500 text-slate-950 rounded-xl font-black">
              <Receipt className="w-6 h-6" />
            </div>
            <h2 className="text-2xl font-black text-amber-400 tracking-wide text-center">
              Order History
            </h2>
          </div>

          <div className="relative flex items-center justify-center gap-3">
            {/* Search Box Centered */}
            <div className="relative w-full max-w-md">
              <Search className="w-3.5 h-3.5 text-amber-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search Order #, Name, Mobile, Table..."
                value={historySearchQuery}
                onChange={(e) => setHistorySearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 text-center"
              />
            </div>

            {/* Export CSV Button */}
            <button
              onClick={exportReportCsv}
              className="sm:absolute sm:right-0 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 shadow transition shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* ROW 1 FILTERS: Today | Yesterday | This Week | This Month | Custom Date | Section */}
        {/* ========================================================================= */}
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setDateFilter('today')}
            className={`py-2 px-3 rounded-lg text-center transition ${
              dateFilter === 'today' ? 'bg-amber-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            Today
          </button>
          <button
            onClick={() => setDateFilter('yesterday')}
            className={`py-2 px-3 rounded-lg text-center transition ${
              dateFilter === 'yesterday' ? 'bg-amber-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            Yesterday
          </button>
          <button
            onClick={() => setDateFilter('week')}
            className={`py-2 px-3 rounded-lg text-center transition ${
              dateFilter === 'week' ? 'bg-amber-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            This Week
          </button>
          <button
            onClick={() => setDateFilter('month')}
            className={`py-2 px-3 rounded-lg text-center transition ${
              dateFilter === 'month' ? 'bg-amber-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setDateFilter('custom_date')}
            className={`py-2 px-3 rounded-lg text-center transition flex items-center justify-center gap-1 ${
              dateFilter === 'custom_date' ? 'bg-amber-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <span>Custom Date</span>
          </button>

          {/* Section Filter Dropdown */}
          <select
            value={selectedSectionFilter}
            onChange={(e) => setSelectedSectionFilter(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-amber-400 rounded-lg px-2 py-2 text-xs font-black focus:outline-none cursor-pointer text-center"
          >
            <option value="all">Section</option>
            {sections.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>

        {/* Custom Date Pickers Inline when Custom Date is selected */}
        {dateFilter === 'custom_date' && (
          <div className="flex flex-wrap items-center gap-4 bg-slate-950/90 p-3 rounded-xl border border-amber-500/50 text-xs font-bold">
            <div className="flex items-center gap-2">
              <span className="text-amber-400">📅 Select Date:</span>
              <input
                type="date"
                value={customDate}
                onChange={(e) => {
                  setCustomDate(e.target.value);
                  setCustomMonth('');
                }}
                className="bg-slate-900 border border-slate-700 text-amber-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-amber-400"
              />
            </div>
            <span className="text-slate-500 font-normal">OR</span>
            <div className="flex items-center gap-2">
              <span className="text-amber-400">🗓️ Select Month:</span>
              <input
                type="month"
                value={customMonth}
                onChange={(e) => {
                  setCustomMonth(e.target.value);
                  setCustomDate('');
                }}
                className="bg-slate-900 border border-slate-700 text-amber-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-amber-400"
              />
            </div>
            {(customDate || customMonth) && (
              <button
                onClick={() => {
                  setCustomDate('');
                  setCustomMonth('');
                }}
                className="text-xs text-rose-400 hover:underline ml-auto"
              >
                Clear Date Filter
              </button>
            )}
          </div>
        )}

        {/* ============================================================================================== */}
        {/* ROW 2 TABS: All | Active | Settled | Running | Pending (Bill Generate...) | Void | Credit | Free/No Bill */}
        {/* ============================================================================================== */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-1.5 bg-slate-950 p-2 rounded-xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setHistoryTab('all')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'all' ? 'bg-amber-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>All</span>
            <span className="text-[10px] opacity-80">({filterOrders.length})</span>
          </button>

          <button
            onClick={() => setHistoryTab('active')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'active' ? 'bg-amber-400 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Active</span>
            <span className="text-[10px] opacity-80">({activeOrdersList.length})</span>
          </button>

          <button
            onClick={() => setHistoryTab('settled')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'settled' ? 'bg-emerald-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Settled</span>
            <span className="text-[10px] opacity-80">({settledPaidOrders.length})</span>
          </button>

          <button
            onClick={() => setHistoryTab('running')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'running' ? 'bg-sky-500 text-slate-950 font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Running</span>
            <span className="text-[10px] opacity-80">({runningOrdersList.length})</span>
          </button>

          <button
            onClick={() => setHistoryTab('pending')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'pending' ? 'bg-amber-600 text-white font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Pending</span>
            <span className="text-[10px] opacity-80">({pendingOrdersList.length})</span>
          </button>

          <button
            onClick={() => setHistoryTab('void')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'void' ? 'bg-rose-500 text-white font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Void</span>
            <span className="text-[10px] opacity-80">({voidOrdersList.length})</span>
          </button>

          <button
            onClick={() => setHistoryTab('credit')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'credit' ? 'bg-purple-500 text-white font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Credit</span>
            <span className="text-[10px] opacity-80">({creditOrdersList.length})</span>
          </button>

          <button
            onClick={() => setHistoryTab('free')}
            className={`p-2 rounded-lg text-center transition flex flex-col items-center justify-center ${
              historyTab === 'free' ? 'bg-indigo-500 text-white font-black shadow' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            <span>Free/No Bill</span>
            <span className="text-[10px] opacity-80">({freeOrdersList.length})</span>
          </button>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-amber-400 font-extrabold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3">Order #</th>
                <th className="p-3">Section & Table / Mode</th>
                <th className="p-3">Customer / Waiter</th>
                <th className="p-3">Items Summary</th>
                <th className="p-3 text-right">Amount</th>
                <th className="p-3 text-center">Payment</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-center">Select / Open</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200 font-medium">
              {historyOrders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500 font-bold">
                    No orders found matching the selected filter ({historyTab.toUpperCase()})
                  </td>
                </tr>
              ) : (
                historyOrders.map((ord) => (
                  <tr
                    key={ord.id}
                    onClick={() => setSelectedOrderForView(ord)}
                    className="hover:bg-slate-800/80 cursor-pointer transition group"
                  >
                    {/* Order Number & Time */}
                    <td className="p-3">
                      <div className="font-black text-amber-400 text-sm group-hover:underline flex items-center gap-1">
                        #{ord.orderNumber}
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </td>

                    {/* Section & Table */}
                    <td className="p-3">
                      <div className="font-bold text-slate-100">{ord.sectionName}</div>
                      <div className="text-[11px] text-amber-300 font-semibold uppercase">
                        {ord.tableName ? `Table: ${ord.tableName}` : ord.mode.replace('_', ' ')}
                      </div>
                    </td>

                    {/* Customer / Waiter */}
                    <td className="p-3">
                      <div className="font-semibold text-slate-200">{ord.customerName || 'Walk-in Guest'}</div>
                      {ord.customerMobile && (
                        <div className="text-[10px] text-slate-400">Mob: {ord.customerMobile}</div>
                      )}
                      {ord.waiterName && (
                        <div className="text-[10px] text-amber-400 font-medium mt-0.5">
                          Waiter: {ord.waiterName}
                        </div>
                      )}
                    </td>

                    {/* Items Summary */}
                    <td className="p-3">
                      <div className="font-bold text-slate-200">{ord.items.length} Items</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-xs">
                        {ord.items.map((it) => `${it.nameEn} (x${it.quantity})`).join(', ')}
                      </div>
                    </td>

                    {/* Final Amount */}
                    <td className="p-3 text-right">
                      <div className="font-black text-sm text-slate-100">₹{ord.finalTotal}</div>
                      {ord.discountAmount > 0 && (
                        <div className="text-[10px] text-emerald-400">Disc: -₹{ord.discountAmount}</div>
                      )}
                    </td>

                    {/* Payment Mode */}
                    <td className="p-3 text-center uppercase">
                      {ord.paymentMode ? (
                        <span className="bg-slate-800 text-amber-300 px-2 py-1 rounded-md text-[10px] font-black border border-slate-700">
                          {ord.paymentMode}
                        </span>
                      ) : (
                        <span className="text-amber-500 font-bold text-[11px]">UNPAID</span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="p-3 text-center">
                      {ord.status === 'settled' && (
                        <span className="bg-emerald-500/20 text-emerald-400 font-black text-[10px] px-2.5 py-1 rounded-full border border-emerald-500/40 uppercase">
                          SETTLED
                        </span>
                      )}
                      {ord.status === 'active' && (
                        <span className="bg-amber-500/20 text-amber-400 font-black text-[10px] px-2.5 py-1 rounded-full border border-amber-500/40 uppercase animate-pulse">
                          ACTIVE / RUNNING
                        </span>
                      )}
                      {ord.status === 'void' && (
                        <span className="bg-rose-500/20 text-rose-400 font-black text-[10px] px-2.5 py-1 rounded-full border border-rose-500/40 uppercase">
                          VOID
                        </span>
                      )}
                    </td>

                    {/* SELECT ORDER BUTTON */}
                    <td className="p-3 text-center">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedOrderForView(ord);
                        }}
                        className="bg-amber-500/10 hover:bg-amber-500 text-amber-300 hover:text-slate-950 font-black px-3 py-1.5 rounded-lg border border-amber-500/30 transition text-xs inline-flex items-center gap-1 shadow-sm"
                      >
                        <span>Open Order</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================== */}
      {/* 2. P&L METRICS SUMMARY CARDS GRID */}
      {/* ========================================================== */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Total Sales</div>
          <div className="text-xl font-black text-amber-400 mt-1">₹{totalSale}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{settledPaidOrders.length} paid bills</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Cash Collected</div>
          <div className="text-xl font-black text-emerald-400 mt-1">₹{cashCollected}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Physical cash</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl">
          <div className="text-[11px] font-bold text-slate-400 uppercase">UPI / Online</div>
          <div className="text-xl font-black text-sky-400 mt-1">₹{upiOnline}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">QR & Card</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Split Pay</div>
          <div className="text-xl font-black text-purple-400 mt-1">₹{splitPayTotal}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Multiple modes</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Free Orders</div>
          <div className="text-xl font-black text-slate-300 mt-1">₹{freeOrderValue}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{freeOrdersList.length} free bills</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Total Expenses</div>
          <div className="text-xl font-black text-rose-400 mt-1">₹{totalExpenses}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Goods, Rent, Staff</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl col-span-2">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Net P&L Profit / Loss</div>
          <div className={`text-2xl font-black mt-1 ${netPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {netPnl >= 0 ? `+₹${netPnl}` : `-₹${Math.abs(netPnl)}`}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Sales minus Expenses</div>
        </div>
      </div>

      {/* Analytics Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Selling Items */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-lg">
          <h3 className="font-bold text-sm text-amber-400 uppercase tracking-wider">
            Top Selling Items by Volume
          </h3>
          <div className="divide-y divide-slate-800">
            {topSellingItems.map((it, idx) => (
              <div key={idx} className="py-2.5 flex justify-between items-center text-xs">
                <div>
                  <span className="font-bold text-slate-200">{idx + 1}. {it.nameEn}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-bold">
                    ×{it.qty} sold
                  </span>
                  <span className="font-black text-amber-400">₹{it.revenue}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Waiter Performance Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-lg">
          <h3 className="font-bold text-sm text-amber-400 uppercase tracking-wider">
            Staff / Waiter Revenue Performance
          </h3>
          <div className="divide-y divide-slate-800">
            {Object.entries(waiterMap).map(([waiter, stats], idx) => (
              <div key={idx} className="py-2.5 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-200">{waiter}</span>
                <div className="flex items-center gap-4">
                  <span className="text-slate-400 font-semibold">{stats.count} orders</span>
                  <span className="font-black text-emerald-400">₹{stats.revenue}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ========================================================== */}
      {/* EDIT ORDER / ADD ITEMS MODAL */}
      {/* ========================================================== */}
      {selectedOrderForEdit && (
        <EditOrderModal
          order={selectedOrderForEdit}
          menuItems={menuItems}
          staff={staff}
          onClose={() => setSelectedOrderForEdit(null)}
          onSave={(updatedOrder) => {
            saveOrder(updatedOrder);
            setSelectedOrderForEdit(null);
          }}
          onGenerateKot={(ordId) => {
            const result = generateKot(ordId);
            setShowKotModalOrder(result);
          }}
        />
      )}

      {/* ========================================================== */}
      {/* PAY / SETTLE BILL MODAL */}
      {/* ========================================================== */}
      {selectedOrderForPay && (
        <BillModal
          order={selectedOrderForPay}
          onClose={() => setSelectedOrderForPay(null)}
          onPaymentSuccess={() => {
            setSelectedOrderForPay(null);
          }}
        />
      )}

      {/* ========================================================== */}
      {/* VIEW ORDER DETAILS & PRINT MODAL */}
      {/* ========================================================== */}
      {selectedOrderForView && (
        <ViewOrderModal
          order={selectedOrderForView}
          onClose={() => setSelectedOrderForView(null)}
          onOpenPay={() => {
            const ord = selectedOrderForView;
            setSelectedOrderForView(null);
            setSelectedOrderForPay(ord);
          }}
          onOpenEdit={() => {
            const ord = selectedOrderForView;
            setSelectedOrderForView(null);
            setSelectedOrderForEdit(ord);
          }}
          onOpenVoid={() => {
            const ord = selectedOrderForView;
            setSelectedOrderForView(null);
            setSelectedOrderForVoid(ord);
            setVoidReason('');
            setVoidPin('');
          }}
          onGenerateKot={() => {
            const ord = selectedOrderForView;
            const result = generateKot(ord.id);
            setShowKotModalOrder(result);
          }}
        />
      )}

      {/* ========================================================== */}
      {/* VOID ORDER CONFIRMATION MODAL */}
      {/* ========================================================== */}
      {selectedOrderForVoid && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleConfirmVoid}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-rose-400 font-bold">
                <AlertTriangle className="w-5 h-5" />
                <h3 className="text-slate-100 text-base">Void Order #{selectedOrderForVoid.orderNumber}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrderForVoid(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Voiding an order will mark it as cancelled and remove its revenue from daily sales metrics.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Reason for Voiding *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Guest cancelled / Wrong order / Payment issue"
                  value={voidReason}
                  onChange={(e) => setVoidReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Manager/Owner PIN *</label>
                <input
                  type="password"
                  required
                  placeholder="Enter PIN (1234 or 9999)"
                  value={voidPin}
                  onChange={(e) => setVoidPin(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-mono tracking-widest text-center"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedOrderForVoid(null)}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-rose-600 hover:bg-rose-500 text-white font-bold py-2.5 rounded-xl text-xs shadow-lg"
              >
                Confirm Void
              </button>
            </div>
          </form>
        </div>
      )}

      {/* KOT Modal Output */}
      {showKotModalOrder && (
        <KotModal
          order={showKotModalOrder.order}
          newItems={showKotModalOrder.newItems}
          onClose={() => setShowKotModalOrder(null)}
        />
      )}
    </div>
  );
};

// ====================================================================
// SUB-COMPONENT: EDIT ORDER & ADD ITEMS MODAL
// ====================================================================
interface EditOrderModalProps {
  order: Order;
  menuItems: MenuItem[];
  staff: any[];
  onClose: () => void;
  onSave: (updatedOrder: Order) => void;
  onGenerateKot: (orderId: string) => void;
}

const EditOrderModal: React.FC<EditOrderModalProps> = ({
  order,
  menuItems,
  staff,
  onClose,
  onSave,
  onGenerateKot,
}) => {
  const [items, setItems] = useState<OrderItem[]>(order.items || []);
  const [discountPercent, setDiscountPercent] = useState<number>(order.discountPercent || 0);
  const [waiterName, setWaiterName] = useState<string>(order.waiterName || '');
  const [customerName, setCustomerName] = useState<string>(order.customerName || '');
  const [customerMobile, setCustomerMobile] = useState<string>(order.customerMobile || '');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Categories
  const categories = ['ALL', ...Array.from(new Set(menuItems.map((m) => m.category)))];

  const filteredMenuItems = menuItems.filter((m) => {
    if (!m.active) return false;
    if (selectedCategory !== 'ALL' && m.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return m.nameEn.toLowerCase().includes(q) || (m.nameHi && m.nameHi.includes(q));
    }
    return true;
  });

  const handleAddItem = (menuItem: MenuItem) => {
    // Check if price varies by section
    const secPrice = menuItem.sectionPrices?.[order.sectionId] || menuItem.price;

    setItems((prev) => {
      const existingIdx = prev.findIndex((i) => i.id === menuItem.id);
      if (existingIdx >= 0) {
        return prev.map((it, idx) =>
          idx === existingIdx ? { ...it, quantity: it.quantity + 1, isNew: true } : it
        );
      }
      return [
        ...prev,
        {
          id: menuItem.id,
          nameEn: menuItem.nameEn,
          nameHi: menuItem.nameHi,
          price: secPrice,
          quantity: 1,
          category: menuItem.category,
          kotPrint: menuItem.kotPrint,
          kotPrinted: false,
          discountable: menuItem.discountable,
          isNew: true,
        },
      ];
    });
  };

  const handleUpdateQty = (itemId: string, delta: number) => {
    setItems((prev) =>
      prev
        .map((it) => {
          if (it.id === itemId) {
            const newQty = it.quantity + delta;
            if (newQty <= 0) return null;
            return { ...it, quantity: newQty };
          }
          return it;
        })
        .filter(Boolean) as OrderItem[]
    );
  };

  const subtotal = items.reduce((sum, it) => sum + it.price * it.quantity, 0);
  const discountableSubtotal = items
    .filter((it) => it.discountable !== false)
    .reduce((sum, it) => sum + it.price * it.quantity, 0);

  const discountAmount = Math.round((discountableSubtotal * discountPercent) / 100);
  const finalTotal = subtotal - discountAmount + (order.attachedDues || 0) - (order.appliedCredit || 0);

  const handleSave = () => {
    const updatedOrder: Order = {
      ...order,
      items,
      subtotal,
      discountPercent,
      discountAmount,
      finalTotal,
      waiterName,
      customerName,
      customerMobile,
    };
    onSave(updatedOrder);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl my-auto">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-xl">
              <Edit3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-slate-100 font-extrabold text-base">
                Edit Order #{order.orderNumber} ({order.sectionName} - {order.tableName || order.mode.toUpperCase()})
              </h3>
              <p className="text-xs text-slate-400">Add or remove items, adjust discount, and update order details</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Body Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 overflow-y-auto flex-1">
          {/* LEFT: Current Items & Order Modifiers */}
          <div className="space-y-4 flex flex-col justify-between bg-slate-950/50 p-3.5 rounded-xl border border-slate-800">
            <div>
              <h4 className="font-bold text-xs uppercase tracking-wider text-amber-400 mb-2.5">
                Current Order Items ({items.length})
              </h4>

              <div className="space-y-2 max-h-64 overflow-y-auto pr-1 divide-y divide-slate-800/60">
                {items.length === 0 ? (
                  <p className="text-xs text-slate-500 text-center py-6">No items in order. Select items from menu on right.</p>
                ) : (
                  items.map((it) => (
                    <div key={it.id} className="pt-2 flex items-center justify-between text-xs">
                      <div className="flex-1 pr-2">
                        <div className="font-bold text-slate-100 flex items-center gap-1.5">
                          <span>{it.nameEn}</span>
                          {it.isNew && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-400 px-1 rounded font-extrabold">NEW</span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400">₹{it.price} each</div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleUpdateQty(it.id, -1)}
                          className="w-6 h-6 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-bold flex items-center justify-center text-xs"
                        >
                          -
                        </button>
                        <span className="font-black text-amber-400 text-sm w-4 text-center">{it.quantity}</span>
                        <button
                          type="button"
                          onClick={() => handleUpdateQty(it.id, 1)}
                          className="w-6 h-6 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-bold flex items-center justify-center text-xs"
                        >
                          +
                        </button>
                        <div className="w-14 text-right font-black text-slate-200">₹{it.price * it.quantity}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Modifiers (Waiter, Customer, Discount) */}
            <div className="pt-3 border-t border-slate-800 space-y-2.5 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-1">Customer Name</label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Guest Name"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-1">Mobile Number</label>
                  <input
                    type="text"
                    value={customerMobile}
                    onChange={(e) => setCustomerMobile(e.target.value)}
                    placeholder="Mobile"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-1">Assigned Waiter</label>
                  <select
                    value={waiterName}
                    onChange={(e) => setWaiterName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-xs"
                  >
                    <option value="">Select Waiter</option>
                    {staff
                      .filter((s) => s.role === 'waiter')
                      .map((s) => (
                        <option key={s.id} value={s.name}>
                          {s.name}
                        </option>
                      ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-1">Discount %</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(Math.max(0, Number(e.target.value) || 0))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-xs font-bold"
                  />
                </div>
              </div>

              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 space-y-1 font-bold text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span>₹{subtotal}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount ({discountPercent}%):</span>
                    <span>-₹{discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between text-amber-400 text-sm font-black pt-1 border-t border-slate-800">
                  <span>Final Bill Total:</span>
                  <span>₹{finalTotal}</span>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: Menu Picker to Add Items */}
          <div className="space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs uppercase tracking-wider text-amber-400">
                  Add Items from Menu
                </h4>
                <span className="text-[10px] text-slate-400">{filteredMenuItems.length} items available</span>
              </div>

              {/* Search & Categories */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Search item name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500"
                />
              </div>

              {/* Categories scroll horizontal */}
              <div className="flex gap-1 overflow-x-auto pb-1 text-[11px] font-bold">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg shrink-0 transition ${
                      selectedCategory === cat ? 'bg-amber-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Menu Items List Grid */}
            <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
              {filteredMenuItems.map((item) => {
                const secPrice = item.sectionPrices?.[order.sectionId] || item.price;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleAddItem(item)}
                    className="p-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-xl text-left transition flex flex-col justify-between group"
                  >
                    <div>
                      <div className="font-bold text-slate-200 text-xs group-hover:text-amber-300 line-clamp-1">
                        {item.nameEn}
                      </div>
                      {item.nameHi && (
                        <div className="text-[10px] text-slate-400 line-clamp-1">{item.nameHi}</div>
                      )}
                    </div>
                    <div className="flex items-center justify-between mt-1 pt-1 border-t border-slate-800/60">
                      <span className="font-black text-amber-400 text-xs">₹{secPrice}</span>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 group-hover:bg-amber-500 group-hover:text-slate-950 px-1.5 py-0.5 rounded font-black transition">
                        + Add
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between gap-3 bg-slate-950/50 rounded-b-2xl">
          <button
            type="button"
            onClick={() => onGenerateKot(order.id)}
            className="bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 border border-amber-500/30"
          >
            <Printer className="w-4 h-4" />
            <span>Print KOT Ticket</span>
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2.5 rounded-xl text-xs"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-6 py-2.5 rounded-xl text-xs shadow-lg"
            >
              Save Order Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ====================================================================
// SUB-COMPONENT: VIEW ORDER DETAILS MODAL
// ====================================================================
interface ViewOrderModalProps {
  order: Order;
  onClose: () => void;
  onOpenPay: () => void;
  onOpenEdit: () => void;
  onOpenVoid: () => void;
  onGenerateKot: () => void;
}

const ViewOrderModal: React.FC<ViewOrderModalProps> = ({
  order,
  onClose,
  onOpenPay,
  onOpenEdit,
  onOpenVoid,
  onGenerateKot,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border-2 border-amber-500/40 rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <MealBoxLogo size="sm" showSubtitle={true} />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-slate-100 font-black text-base">Order #{order.orderNumber}</h3>
                {order.status === 'settled' && (
                  <span className="bg-emerald-500/20 text-emerald-400 font-black text-[10px] px-2.5 py-0.5 rounded-full border border-emerald-500/40 uppercase">
                    SETTLED
                  </span>
                )}
                {order.status === 'active' && (
                  <span className="bg-amber-500/20 text-amber-400 font-black text-[10px] px-2.5 py-0.5 rounded-full border border-amber-500/40 uppercase">
                    ACTIVE
                  </span>
                )}
                {order.status === 'void' && (
                  <span className="bg-rose-500/20 text-rose-400 font-black text-[10px] px-2.5 py-0.5 rounded-full border border-rose-500/40 uppercase">
                    VOID
                  </span>
                )}
              </div>
              <p className="text-xs text-amber-400 font-bold mt-0.5">
                Section: {order.sectionName} • {order.tableName ? `Table: ${order.tableName}` : order.mode.toUpperCase()}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Metadata */}
        <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800">
          <div>
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Customer Name</span>
            <span className="font-bold text-slate-200">{order.customerName || 'Walk-in Guest'}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Mobile Number</span>
            <span className="font-bold text-slate-200">{order.customerMobile || 'N/A'}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Waiter</span>
            <span className="font-bold text-amber-400">{order.waiterName || 'Unassigned'}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Created At / Mode</span>
            <span className="font-bold text-slate-200">
              {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} •{' '}
              <span className="text-amber-400">{order.paymentMode ? order.paymentMode.toUpperCase() : 'UNPAID'}</span>
            </span>
          </div>
        </div>

        {/* Items List */}
        <div>
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Order Items ({order.items.length})</h4>
          <div className="space-y-1.5 max-h-40 overflow-y-auto text-xs divide-y divide-slate-800 bg-slate-950 p-3 rounded-xl border border-slate-800">
            {order.items.map((it, idx) => (
              <div key={idx} className="pt-1.5 first:pt-0 flex justify-between items-center">
                <div>
                  <span className="font-bold text-slate-200">{it.nameEn}</span>
                  {it.nameHi && <span className="text-[10px] text-slate-400 ml-1">({it.nameHi})</span>}
                </div>
                <div className="text-slate-300 font-semibold">
                  {it.quantity} × ₹{it.price} = <span className="font-black text-amber-400">₹{it.price * it.quantity}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Totals */}
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-bold text-xs space-y-1 text-right">
          <div className="flex justify-between text-slate-400">
            <span>Subtotal:</span>
            <span>₹{order.subtotal}</span>
          </div>
          {order.discountAmount > 0 && (
            <div className="flex justify-between text-emerald-400">
              <span>Discount:</span>
              <span>-₹{order.discountAmount}</span>
            </div>
          )}
          <div className="flex justify-between text-sm font-black text-amber-400 pt-1 border-t border-slate-800">
            <span>Final Bill Total:</span>
            <span>₹{order.finalTotal}</span>
          </div>
        </div>

        {/* Action Controls Grid */}
        <div>
          <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">Perform Order Action</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {/* 1. Edit / Add Item */}
            <button
              onClick={onOpenEdit}
              className="bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 font-bold p-2.5 rounded-xl transition flex flex-col items-center justify-center gap-1 border border-amber-500/40 text-xs shadow cursor-pointer"
              title="Edit order items & waiter"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit / + Item</span>
            </button>

            {/* 2. Print KOT */}
            <button
              onClick={onGenerateKot}
              className="bg-sky-500/20 hover:bg-sky-500 text-sky-300 hover:text-slate-950 font-bold p-2.5 rounded-xl transition flex flex-col items-center justify-center gap-1 border border-sky-500/40 text-xs shadow cursor-pointer"
              title="Print Kitchen Order Ticket"
            >
              <Printer className="w-4 h-4" />
              <span>Print KOT Ticket</span>
            </button>

            {/* 3. Pay / Bill Generate */}
            {order.status === 'active' ? (
              <button
                onClick={onOpenPay}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black p-2.5 rounded-xl transition flex flex-col items-center justify-center gap-1 shadow-lg text-xs cursor-pointer"
                title="Settle & Pay Bill"
              >
                <DollarSign className="w-4 h-4" />
                <span>Pay / Bill Generate</span>
              </button>
            ) : (
              <button
                onClick={onOpenPay}
                className="bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 font-bold p-2.5 rounded-xl transition flex flex-col items-center justify-center gap-1 border border-emerald-500/40 text-xs shadow cursor-pointer"
                title="Print Receipt / View Payment"
              >
                <Receipt className="w-4 h-4" />
                <span>Bill Receipt</span>
              </button>
            )}

            {/* 4. Void Order */}
            {order.status !== 'void' ? (
              <button
                onClick={onOpenVoid}
                className="bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white font-bold p-2.5 rounded-xl transition flex flex-col items-center justify-center gap-1 border border-rose-500/40 text-xs shadow cursor-pointer"
                title="Cancel or void this order"
              >
                <XCircle className="w-4 h-4" />
                <span>Void Order</span>
              </button>
            ) : (
              <div className="bg-slate-800 text-rose-400 font-bold p-2.5 rounded-xl flex flex-col items-center justify-center gap-1 text-xs border border-slate-700 opacity-60">
                <XCircle className="w-4 h-4" />
                <span>Already Void</span>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-1">
          <button
            onClick={onClose}
            className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2.5 rounded-xl text-xs transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
