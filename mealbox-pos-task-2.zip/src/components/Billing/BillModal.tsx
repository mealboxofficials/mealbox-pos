import React, { useState, useEffect, useRef } from 'react';
import { Order, SplitPaymentDetail, Customer } from '../../types';
import { useApp } from '../../context/AppContext';
import { RESTAURANT_CONFIG } from '../../data/restaurantConfig';
import { MealBoxLogo } from '../MealBoxLogo';
import QRCode from 'qrcode';
import {
  CreditCard,
  QrCode,
  Banknote,
  Percent,
  UserPlus,
  ArrowRight,
  Printer,
  X,
  CheckCircle2,
  AlertCircle,
  DollarSign,
  Save,
} from 'lucide-react';

interface BillModalProps {
  order: Order;
  onClose: () => void;
  onPaymentSuccess: () => void;
}

export const BillModal: React.FC<BillModalProps> = ({
  order,
  onClose,
  onPaymentSuccess,
}) => {
  const {
    activeSection,
    customers,
    searchCustomers,
    processBillPayment,
    saveOrder,
    showToast,
  } = useApp();

  const handleSaveBillOnly = () => {
    const enteredAmount = Number(paidAmountInput) || 0;
    saveOrder({
      ...order,
      discountPercent,
      discountAmount,
      advanceDeposit: enteredAmount > 0 ? enteredAmount : order.advanceDeposit,
      paidAmount: enteredAmount > 0 ? enteredAmount : order.paidAmount,
      paymentMode,
      customerMobile: customerMobile || order.customerMobile,
      customerName: customerName || order.customerName,
    });
    showToast(`Bill saved with amount ₹${enteredAmount || finalBillAmount} for Order #${order.orderNumber}`, 'success');
    onClose();
  };

  const [paymentMode, setPaymentMode] = useState<'cash' | 'upi' | 'card' | 'split'>('cash');
  const [discountPercent, setDiscountPercent] = useState<number>(order.discountPercent || 0);
  const [paidAmountInput, setPaidAmountInput] = useState<string>('');
  
  // Shortfall & Excess handlers
  const [shortfallHandling, setShortfallHandling] = useState<'dues' | 'discount'>('dues');
  const [excessHandling, setExcessHandling] = useState<'return' | 'credit' | 'tip'>('return');

  // Customer search & mobile for dues/credit
  const [customerMobile, setCustomerMobile] = useState<string>(order.customerMobile || '');
  const [customerName, setCustomerName] = useState<string>(order.customerName || '');
  const [autoSuggestedCustomers, setAutoSuggestedCustomers] = useState<Customer[]>([]);

  // Split details
  const [splitDetails, setSplitDetails] = useState<SplitPaymentDetail[]>([
    { method: 'cash', amount: 0 },
    { method: 'upi', amount: 0 },
  ]);

  // UPI QR Code
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [isVerifyingUpi, setIsVerifyingUpi] = useState(false);
  const [upiVerified, setUpiVerified] = useState(false);

  // Bill print view toggle
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [includeQrOnPrint, setIncludeQrOnPrint] = useState(true);

  const billPrintRef = useRef<HTMLDivElement>(null);

  const handlePrintBillWindow = () => {
    if (billPrintRef.current) {
      const content = billPrintRef.current.innerHTML;
      const printWin = window.open('', '_blank', 'width=450,height=650');
      if (printWin) {
        printWin.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Bill Invoice #${order.orderNumber}</title>
              <style>
                @page { size: auto; margin: 0; }
                body {
                  font-family: monospace, sans-serif;
                  margin: 0;
                  padding: 12px;
                  width: 80mm;
                  background: #fff;
                  color: #000;
                  font-size: 11px;
                  line-height: 1.3;
                }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .font-bold { font-weight: bold; }
                .font-black { font-weight: 900; }
                .uppercase { text-transform: uppercase; }
                .flex { display: flex; }
                .justify-between { justify-content: space-between; }
                .border-b-2 { border-bottom: 2px dashed #000; }
                .border-t-2 { border-top: 2px dashed #000; }
                .border-t { border-top: 1px solid #000; }
                .border-b { border-bottom: 1px solid #000; }
                .py-1 { padding-top: 4px; padding-bottom: 4px; }
                .my-2 { margin-top: 8px; margin-bottom: 8px; }
                img { max-width: 100%; height: auto; }
              </style>
            </head>
            <body>
              ${content}
              <script>
                window.onload = function() {
                  window.print();
                  setTimeout(function() { window.close(); }, 300);
                };
              </script>
            </body>
          </html>
        `);
        printWin.document.close();
      } else {
        window.print();
      }
    } else {
      setShowPrintPreview(true);
      setTimeout(() => window.print(), 300);
    }
  };

  // Discountable subtotal calculation
  const discountableSubtotal = order.items
    .filter((i) => i.discountable !== false)
    .reduce((sum, item) => sum + item.price * item.quantity, 0);

  const discountAmount = Math.round((discountableSubtotal * discountPercent) / 100);

  const advanceDeposit = order.advanceDeposit || 0;

  const finalBillAmount = Math.max(
    0,
    order.subtotal + order.attachedDues - order.appliedCredit - discountAmount - advanceDeposit
  );

  useEffect(() => {
    if (!paidAmountInput) {
      setPaidAmountInput(finalBillAmount.toString());
    }
  }, [finalBillAmount]);

  // Generate UPI QR Code URL
  useEffect(() => {
    const upiUri = `upi://pay?pa=${encodeURIComponent(
      activeSection.upiId
    )}&pn=${encodeURIComponent('Mealbox Restaurant')}&am=${finalBillAmount}&cu=INR&tn=${encodeURIComponent(
      `Order #${order.orderNumber}`
    )}`;

    QRCode.toDataURL(upiUri, { width: 220, margin: 1 })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error('QR code generation error', err));
  }, [activeSection.upiId, finalBillAmount, order.orderNumber]);

  // Auto suggest customer typing
  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setCustomerMobile(val);
    if (val.length >= 3) {
      const results = searchCustomers(val);
      setAutoSuggestedCustomers(results);
    } else {
      setAutoSuggestedCustomers([]);
    }
  };

  const selectSuggestedCustomer = (c: Customer) => {
    setCustomerMobile(c.mobile);
    setCustomerName(c.name);
    setAutoSuggestedCustomers([]);
  };

  const calculatedPaidAmount =
    paymentMode === 'split'
      ? splitDetails.reduce((sum, d) => sum + (Number(d.amount) || 0), 0)
      : Number(paidAmountInput) || 0;

  const diff = calculatedPaidAmount - finalBillAmount;
  const isShortfall = diff < 0;
  const isExcess = diff > 0;

  const upiTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (upiTimerRef.current) {
        clearTimeout(upiTimerRef.current);
      }
    };
  }, []);

  // Verification simulation for UPI
  const verifyUpiStatus = () => {
    setIsVerifyingUpi(true);
    if (upiTimerRef.current) clearTimeout(upiTimerRef.current);
    upiTimerRef.current = setTimeout(() => {
      setIsVerifyingUpi(false);
      setUpiVerified(true);
      showToast('UPI Payment Verified Successfully!', 'success');
    }, 1500);
  };

  const handleSettleAndPay = () => {
    // If shortfall and "dues" chosen or excess and "credit" chosen -> mandatory mobile required!
    if (isShortfall && shortfallHandling === 'dues' && !customerMobile) {
      showToast('Mobile number is mandatory to add pending dues!', 'error');
      return;
    }
    if (isExcess && excessHandling === 'credit' && !customerMobile) {
      showToast('Mobile number is mandatory to save advance credit!', 'error');
      return;
    }

    processBillPayment(order.id, {
      paidAmount: calculatedPaidAmount,
      paymentMode,
      splitDetails: paymentMode === 'split' ? splitDetails : undefined,
      discountPercent,
      shortfallHandling: isShortfall ? shortfallHandling : undefined,
      excessHandling: isExcess ? excessHandling : undefined,
      customerMobile: customerMobile || undefined,
      customerName: customerName || undefined,
    });

    onPaymentSuccess();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-slate-800 border-b border-slate-700 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-100 text-lg flex items-center gap-2">
              <Banknote className="w-5 h-5 text-amber-400" />
              <span>Billing & Settlement — Order #{order.orderNumber}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {order.sectionName} Section • {order.tableName || order.mode.toUpperCase()}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Bill Calculation Summary Card */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-4 space-y-2.5 text-sm">
            <div className="flex justify-between text-slate-300">
              <span>Items Subtotal:</span>
              <span className="font-semibold text-slate-100">₹{order.subtotal}</span>
            </div>

            {order.attachedDues > 0 && (
              <div className="flex justify-between text-amber-400 font-medium">
                <span>+ Attached Customer Dues:</span>
                <span>+ ₹{order.attachedDues}</span>
              </div>
            )}

            {order.appliedCredit > 0 && (
              <div className="flex justify-between text-emerald-400 font-medium">
                <span>− Applied Customer Credit:</span>
                <span>− ₹{order.appliedCredit}</span>
              </div>
            )}

            {advanceDeposit > 0 && (
              <div className="flex justify-between text-cyan-400 font-medium">
                <span>− Advance / Deposit Paid:</span>
                <span>− ₹{advanceDeposit}</span>
              </div>
            )}

            {/* Discount Selector */}
            <div className="flex items-center justify-between pt-1 border-t border-slate-700">
              <div className="flex items-center gap-2 text-slate-300">
                <Percent className="w-4 h-4 text-amber-400" />
                <span>Discount (%):</span>
              </div>
              <div className="flex items-center gap-2">
                {[0, 5, 10, 15, 20].map((pct) => (
                  <button
                    key={pct}
                    onClick={() => setDiscountPercent(pct)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                      discountPercent === pct
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            {discountAmount > 0 && (
              <div className="flex justify-between text-rose-400 font-medium text-xs">
                <span>Discount Amount ({discountPercent}% on eligible items):</span>
                <span>− ₹{discountAmount}</span>
              </div>
            )}

            {/* Final Total Header */}
            <div className="flex justify-between items-center pt-2.5 border-t border-slate-700 font-black text-lg text-amber-400">
              <span>FINAL BILL AMOUNT:</span>
              <span className="text-2xl">₹{finalBillAmount}</span>
            </div>
          </div>

          {/* Customer Identification Bar */}
          <div className="bg-slate-800/50 border border-slate-700/80 rounded-xl p-3.5 space-y-2 relative">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Customer Details (Optional for Dues / Credit tracking)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <input
                  type="text"
                  placeholder="Mobile Number (10 digits)"
                  value={customerMobile}
                  onChange={handleMobileChange}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                {autoSuggestedCustomers.length > 0 && (
                  <div className="absolute left-3 right-3 mt-1 bg-slate-800 border border-slate-700 rounded-lg shadow-2xl z-30 divide-y divide-slate-700 max-h-40 overflow-y-auto">
                    {autoSuggestedCustomers.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => selectSuggestedCustomer(c)}
                        className="w-full text-left p-2.5 hover:bg-slate-700 text-xs flex justify-between items-center"
                      >
                        <div>
                          <div className="font-bold text-slate-200">{c.name}</div>
                          <div className="text-slate-400">{c.mobile}</div>
                        </div>
                        <div className="text-right">
                          {c.dues > 0 && (
                            <span className="text-rose-400 font-semibold block">Dues: ₹{c.dues}</span>
                          )}
                          {c.advance > 0 && (
                            <span className="text-emerald-400 font-semibold block">Credit: ₹{c.advance}</span>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Customer Name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Payment Mode Selection */}
          <div>
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
              Select Payment Mode
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <button
                onClick={() => setPaymentMode('cash')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition gap-1.5 ${
                  paymentMode === 'cash'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <Banknote className="w-5 h-5" />
                <span>CASH</span>
              </button>

              <button
                onClick={() => setPaymentMode('upi')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition gap-1.5 ${
                  paymentMode === 'upi'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <QrCode className="w-5 h-5" />
                <span>UPI / QR</span>
              </button>

              <button
                onClick={() => setPaymentMode('card')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition gap-1.5 ${
                  paymentMode === 'card'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <CreditCard className="w-5 h-5" />
                <span>CARD</span>
              </button>

              <button
                onClick={() => setPaymentMode('split')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition gap-1.5 ${
                  paymentMode === 'split'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <DollarSign className="w-5 h-5" />
                <span>SPLIT PAY</span>
              </button>
            </div>
          </div>

          {/* UPI QR Display if UPI selected */}
          {paymentMode === 'upi' && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center gap-4 text-slate-100">
              {qrDataUrl && (
                <div className="bg-white p-2.5 rounded-xl shadow-lg shrink-0">
                  <img src={qrDataUrl} alt="UPI QR Code" className="w-36 h-36" />
                </div>
              )}
              <div className="space-y-2 text-center sm:text-left flex-1">
                <div className="font-extrabold text-amber-400 text-base">Scan to Pay ₹{finalBillAmount}</div>
                <div className="text-xs text-slate-400 font-mono">
                  UPI ID: <span className="text-slate-200">{activeSection.upiId}</span>
                </div>
                <div className="pt-2 flex flex-wrap gap-2 justify-center sm:justify-start">
                  <button
                    onClick={verifyUpiStatus}
                    disabled={isVerifyingUpi || upiVerified}
                    className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition"
                  >
                    {isVerifyingUpi ? (
                      <span>Checking Status...</span>
                    ) : upiVerified ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                        <span>Payment Verified!</span>
                      </>
                    ) : (
                      <span>Check Payment Status</span>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Split Payment Form */}
          {paymentMode === 'split' && (
            <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4 space-y-3">
              <label className="text-xs font-bold text-slate-300 uppercase block">
                Split Amount Breakdown
              </label>
              {splitDetails.map((detail, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <select
                    value={detail.method}
                    onChange={(e) => {
                      const method = e.target.value as any;
                      setSplitDetails((prev) =>
                        prev.map((d, i) => (i === idx ? { ...d, method } : d))
                      );
                    }}
                    className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200"
                  >
                    <option value="cash">Cash</option>
                    <option value="upi">UPI</option>
                    <option value="card">Card</option>
                  </select>
                  <input
                    type="number"
                    placeholder="Amount (₹)"
                    value={detail.amount || ''}
                    onChange={(e) => {
                      const amount = Number(e.target.value) || 0;
                      setSplitDetails((prev) =>
                        prev.map((d, i) => (i === idx ? { ...d, amount } : d))
                      );
                    }}
                    className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 w-36"
                  />
                  {splitDetails.length > 1 && (
                    <button
                      type="button"
                      onClick={() => setSplitDetails((prev) => prev.filter((_, i) => i !== idx))}
                      className="text-rose-400 hover:text-rose-300 text-xs font-bold px-2 py-1"
                    >
                      Remove
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => setSplitDetails((prev) => [...prev, { method: 'upi', amount: 0 }])}
                className="text-xs text-amber-400 font-bold hover:underline block pt-1"
              >
                + Add Another Payment Method
              </button>
            </div>
          )}

          {/* Paid Amount Input for Single Mode */}
          {paymentMode !== 'split' && (
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase block mb-1">
                Received / Tendered Amount (₹)
              </label>
              <input
                type="number"
                placeholder={`Enter amount (e.g. ${finalBillAmount})`}
                value={paidAmountInput}
                onChange={(e) => setPaidAmountInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-xl font-bold text-amber-400 focus:outline-none focus:border-amber-500 placeholder-slate-600"
              />
              <div className="flex flex-wrap gap-1.5 mt-2">
                <button
                  type="button"
                  onClick={() => setPaidAmountInput(finalBillAmount.toString())}
                  className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-xs font-extrabold border border-amber-500/40"
                >
                  Exact Bill (₹{finalBillAmount})
                </button>
                <button
                  type="button"
                  onClick={() => setPaidAmountInput('200')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-700"
                >
                  ₹200
                </button>
                <button
                  type="button"
                  onClick={() => setPaidAmountInput('500')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-700"
                >
                  ₹500
                </button>
                <button
                  type="button"
                  onClick={() => setPaidAmountInput('1000')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-700"
                >
                  ₹1000
                </button>
                <button
                  type="button"
                  onClick={() => setPaidAmountInput('2000')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-700"
                >
                  ₹2000
                </button>
              </div>
            </div>
          )}

          {/* Shortfall Handling Modal Prompt (Paid < Bill) */}
          {isShortfall && (
            <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>Shortfall Alert: Customer is paying ₹{Math.abs(diff)} LESS than bill!</span>
              </div>
              <div className="text-xs text-slate-300">How would you like to resolve the remaining balance?</div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setShortfallHandling('dues')}
                  className={`p-3 rounded-xl border text-xs font-bold transition text-left ${
                    shortfallHandling === 'dues'
                      ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="font-bold">Add to Dues</div>
                  <div className="text-[10px] text-slate-400 font-normal">
                    Save ₹{Math.abs(diff)} as pending dues (Mobile Required)
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setShortfallHandling('discount')}
                  className={`p-3 rounded-xl border text-xs font-bold transition text-left ${
                    shortfallHandling === 'discount'
                      ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="font-bold">Discount / Waive It</div>
                  <div className="text-[10px] text-slate-400 font-normal">
                    Waive ₹{Math.abs(diff)} remaining balance
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* Excess Handling Modal Prompt (Paid > Bill) */}
          {isExcess && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>Excess Alert: Customer is paying ₹{diff} MORE than bill!</span>
              </div>
              <div className="text-xs text-slate-300">How would you like to handle the extra amount?</div>
              <div className="grid grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => setExcessHandling('return')}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition text-center ${
                    excessHandling === 'return'
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  <div>Return Cash</div>
                  <div className="text-[10px] text-slate-400 font-normal">Change ₹{diff}</div>
                </button>

                <button
                  type="button"
                  onClick={() => setExcessHandling('credit')}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition text-center ${
                    excessHandling === 'credit'
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  <div>Save Credit</div>
                  <div className="text-[10px] text-slate-400 font-normal">Advance (Mobile req)</div>
                </button>

                <button
                  type="button"
                  onClick={() => setExcessHandling('tip')}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition text-center ${
                    excessHandling === 'tip'
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                      : 'bg-slate-800 border-slate-700 text-slate-400'
                  }`}
                >
                  <div>Tip for Waiter</div>
                  <div className="text-[10px] text-slate-400 font-normal">Tip ₹{diff}</div>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Actions Footer */}
        <div className="p-4 bg-slate-800 border-t border-slate-700 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowPrintPreview(!showPrintPreview)}
              className="px-3.5 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>{showPrintPreview ? 'Hide Bill Preview' : 'Preview Bill'}</span>
            </button>
            <button
              type="button"
              onClick={handlePrintBillWindow}
              className="px-3.5 py-2 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40 rounded-xl text-xs font-bold flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Print Thermal Bill</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveBillOnly}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg transition"
            >
              <Save className="w-4 h-4" />
              <span>SAVE BILL</span>
            </button>
            <button
              onClick={handleSettleAndPay}
              className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-5 py-2.5 rounded-xl text-xs shadow-xl transition"
            >
              <span>SETTLE & PAID</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Thermal Bill Print Preview Overlay */}
        {showPrintPreview && (
          <div ref={billPrintRef} className="p-6 bg-amber-50 text-slate-950 font-mono text-xs border-t border-amber-300 max-h-96 overflow-y-auto">
            <div className="text-center pb-3 border-b-2 border-dashed border-slate-400 space-y-1">
              <div className="flex justify-center mb-1">
                <MealBoxLogo size="md" showSubtitle={true} />
              </div>
              <p className="text-[11px] text-slate-700 font-bold max-w-xs mx-auto leading-tight">
                {RESTAURANT_CONFIG.address}
              </p>
              <p className="text-[11px] font-extrabold text-amber-900">
                Mob: {RESTAURANT_CONFIG.contactPhone}
              </p>
              <div className="pt-1 text-[10px] uppercase tracking-wider font-extrabold text-slate-800">
                {order.sectionName} SECTION • INVOICE #{order.orderNumber}
              </div>
              <p className="text-[10px] text-slate-500">
                Date: {new Date().toLocaleDateString()} Time: {new Date().toLocaleTimeString()}
              </p>
            </div>

            <div className="py-2.5 text-xs divide-y divide-slate-300">
              <div className="flex justify-between font-bold py-1 border-b border-slate-400">
                <span>Item</span>
                <span>Qty × Rate</span>
                <span>Amount</span>
              </div>
              {order.items.map((it, idx) => (
                <div key={idx} className="flex justify-between py-1 text-[11px]">
                  <span className="w-6/12 font-medium">{it.nameEn} ({it.nameHi || ''})</span>
                  <span className="w-3/12 text-center">{it.quantity} × ₹{it.price}</span>
                  <span className="w-3/12 text-right font-bold">₹{it.price * it.quantity}</span>
                </div>
              ))}
            </div>

            <div className="border-t-2 border-slate-400 pt-2 font-bold text-xs text-right space-y-1">
              <div>Subtotal: ₹{order.subtotal}</div>
              {discountAmount > 0 && <div>Discount ({discountPercent}%): -₹{discountAmount}</div>}
              {order.attachedDues > 0 && <div>Attached Dues: +₹{order.attachedDues}</div>}
              {order.appliedCredit > 0 && <div>Applied Credit: -₹{order.appliedCredit}</div>}
              {advanceDeposit > 0 && <div>Advance Deposit Paid: -₹{advanceDeposit}</div>}
              <div className="text-sm font-black pt-1.5 text-slate-900 border-t border-slate-300 flex justify-between">
                <span>TOTAL AMOUNT:</span>
                <span>₹{finalBillAmount}</span>
              </div>
            </div>

            {includeQrOnPrint && qrDataUrl && (
              <div className="mt-3 py-2 border-t border-dashed border-slate-400 flex flex-col items-center">
                <img src={qrDataUrl} alt="UPI QR" className="w-28 h-28" />
                <span className="text-[10px] font-bold text-slate-700 mt-1">Scan QR to pay via UPI</span>
                <span className="text-[9px] text-slate-500">UPI ID: {activeSection.upiId}</span>
              </div>
            )}

            <div className="mt-3 pt-2 border-t border-dashed border-slate-400 text-center text-[9px] text-slate-600 space-y-1">
              <p className="font-bold">Minimum order value for Home Delivery: ₹500</p>
              <p>Packaging Charge: ₹10 per container for parcel</p>
              <p className="italic mt-1 font-bold">"Thank You! Visit Again to MealBox Restaurant"</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
