import React from 'react';
import { useApp } from '../../context/AppContext';
import { ChefHat, Clock } from 'lucide-react';

export const KitchenDisplay: React.FC = () => {
  const { activeSection, activeOrders, getOrderMinutes } = useApp();

  // Aggregate active orders grouped by item name
  // Map: itemName -> { nameEn, nameHi, totalQty, isNewAddition, tableBreakdown: { tableNameOrMode: string, qty: number, isNew: boolean }[] }
  const aggregatedItems: Record<
    string,
    {
      nameEn: string;
      nameHi: string;
      totalQty: number;
      hasNewAdditions: boolean;
      tableBreakdown: { label: string; qty: number; isNew: boolean }[];
    }
  > = {};

  activeOrders.forEach((order) => {
    order.items.forEach((item) => {
      // Only show KOT-eligible items
      if (!item.kotPrint) return;

      const key = item.nameEn;
      if (!aggregatedItems[key]) {
        aggregatedItems[key] = {
          nameEn: item.nameEn,
          nameHi: item.nameHi,
          totalQty: 0,
          hasNewAdditions: false,
          tableBreakdown: [],
        };
      }

      aggregatedItems[key].totalQty += item.quantity;
      if (item.isNew || !item.kotPrinted) {
        aggregatedItems[key].hasNewAdditions = true;
      }

      const label =
        order.mode === 'dine_in'
          ? order.tableName || 'Dine-In'
          : order.mode.toUpperCase().replace('_', ' ');

      aggregatedItems[key].tableBreakdown.push({
        label,
        qty: item.quantity,
        isNew: !!item.isNew || !item.kotPrinted,
      });
    });
  });

  const itemList = Object.values(aggregatedItems);

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-105px)] text-slate-100 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <ChefHat className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">
              Kitchen Display — {activeSection.name}
            </h2>
            <p className="text-xs text-slate-400">
              Live aggregated item totals for active kitchen orders
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="bg-slate-800 border border-slate-700 text-amber-400 text-xs font-bold px-3 py-1.5 rounded-xl">
            {activeOrders.length} Active Orders
          </span>
        </div>
      </div>

      {/* Main Grid: Aggregated Items View */}
      {itemList.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-500 space-y-3">
          <ChefHat className="w-12 h-12 mx-auto text-slate-600 animate-bounce" />
          <div className="text-lg font-bold text-slate-400">No Pending Kitchen Orders</div>
          <p className="text-xs">New KOT orders will appear here automatically in real time</p>
        </div>
      ) : (
        <div className="space-y-4">
          <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">
            Live Item Preparation Summary
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {itemList.map((item, idx) => (
              <div
                key={idx}
                className={`bg-slate-900 rounded-2xl p-4 border transition shadow-xl ${
                  item.hasNewAdditions
                    ? 'border-rose-500/60 ring-1 ring-rose-500/40'
                    : 'border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between pb-3 border-b border-slate-800">
                  <div>
                    <div className="font-black text-lg text-slate-100 flex items-center gap-2">
                      <span>{item.nameEn}</span>
                      {item.hasNewAdditions && (
                        <span className="bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">
                          NEW ADDITIONS
                        </span>
                      )}
                    </div>
                    <div className="text-sm font-semibold text-amber-400">{item.nameHi}</div>
                  </div>
                  <div className="text-2xl font-black text-amber-400 bg-amber-500/10 px-3 py-1 rounded-xl border border-amber-500/20">
                    ×{item.totalQty}
                  </div>
                </div>

                {/* Table breakdown list */}
                <div className="pt-3 space-y-2">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Order Location Breakdown
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {item.tableBreakdown.map((tb, i) => (
                      <div
                        key={i}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1.5 ${
                          tb.isNew
                            ? 'bg-rose-500/20 border-rose-500/50 text-rose-300'
                            : 'bg-slate-800 border-slate-700 text-slate-200'
                        }`}
                      >
                        <span>[ {tb.label}:</span>
                        <span className="text-amber-400">×{tb.qty}</span>
                        <span>]</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Active Orders Quick Cards below */}
          <div className="pt-6">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-3">
              Active Orders Ticket Grid
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {activeOrders.map((ord) => {
                const mins = getOrderMinutes(ord);
                return (
                  <div
                    key={ord.id}
                    className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2 shadow-lg"
                  >
                    <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                      <span className="font-black text-sm text-amber-400">
                        {ord.tableName || ord.mode.toUpperCase()}
                      </span>
                      <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {mins}m ago
                      </span>
                    </div>

                    <div className="text-xs space-y-1 py-1">
                      {ord.items
                        .filter((i) => i.kotPrint)
                        .map((it, i) => (
                          <div key={i} className="flex justify-between text-slate-300 font-medium">
                            <span>{it.nameEn}</span>
                            <span className="font-bold text-amber-400">×{it.quantity}</span>
                          </div>
                        ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
