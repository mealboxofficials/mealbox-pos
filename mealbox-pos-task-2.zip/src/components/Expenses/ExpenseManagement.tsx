import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Expense } from '../../types';
import { DollarSign, Plus, X } from 'lucide-react';

export const ExpenseManagement: React.FC = () => {
  const { expenses, addExpense, activeSection, currentUser } = useApp();

  const [showAddModal, setShowAddModal] = useState(false);
  const [category, setCategory] = useState<Expense['category']>('Goods');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [mode, setMode] = useState<'cash' | 'online'>('cash');

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description) return;

    addExpense({
      sectionId: activeSection.id,
      category,
      description,
      amount: Number(amount) || 0,
      mode,
      date: new Date().toISOString().split('T')[0],
      createdBy: currentUser.name,
    });

    setDescription('');
    setAmount('');
    setShowAddModal(false);
  };

  const totalCashExpense = expenses
    .filter((e) => e.mode === 'cash')
    .reduce((sum, e) => sum + e.amount, 0);

  const totalOnlineExpense = expenses
    .filter((e) => e.mode === 'online')
    .reduce((sum, e) => sum + e.amount, 0);

  const grandTotalExpense = totalCashExpense + totalOnlineExpense;

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-105px)] text-slate-100 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Restaurant Expense Register</h2>
            <p className="text-xs text-slate-400">
              Track raw materials, vendor payouts, staff advances, electricity, and rent
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg"
        >
          <Plus className="w-4 h-4" />
          <span>Record New Expense</span>
        </button>
      </div>

      {/* Running Totals Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <div className="text-xs font-bold text-slate-400 uppercase">Total Cash Expenses</div>
          <div className="text-2xl font-black text-rose-400 mt-1">₹{totalCashExpense}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <div className="text-xs font-bold text-slate-400 uppercase">Total Online Expenses</div>
          <div className="text-2xl font-black text-sky-400 mt-1">₹{totalOnlineExpense}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <div className="text-xs font-bold text-slate-400 uppercase">Grand Total Expenditure</div>
          <div className="text-2xl font-black text-amber-400 mt-1">₹{grandTotalExpense}</div>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">Date</th>
                <th className="p-4">Category</th>
                <th className="p-4">Description</th>
                <th className="p-4">Amount</th>
                <th className="p-4">Mode</th>
                <th className="p-4">Recorded By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {expenses.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">
                    No expenses recorded yet
                  </td>
                </tr>
              ) : (
                expenses.map((e) => (
                  <tr key={e.id} className="hover:bg-slate-800/50 transition">
                    <td className="p-4 font-semibold text-slate-400">{e.date}</td>
                    <td className="p-4">
                      <span className="bg-slate-800 text-amber-400 px-2.5 py-1 rounded-lg font-bold border border-slate-700">
                        {e.category}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-slate-100">{e.description}</td>
                    <td className="p-4 font-black text-sm text-rose-400">₹{e.amount}</td>
                    <td className="p-4 font-bold uppercase text-slate-300">
                      {e.mode === 'cash' ? (
                        <span className="text-emerald-400">CASH</span>
                      ) : (
                        <span className="text-sky-400">ONLINE</span>
                      )}
                    </td>
                    <td className="p-4 text-slate-400">{e.createdBy}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Expense Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateExpense}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-base">Record Expense</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">Expense Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                >
                  <option value="Goods">Goods (vegetables, raw materials)</option>
                  <option value="Vendor">Vendor (supplier payments)</option>
                  <option value="Staff">Staff (salaries, advances)</option>
                  <option value="Rent">Rent</option>
                  <option value="Electricity">Electricity</option>
                  <option value="Other">Other (custom entry)</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Description *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Purchased 20kg Paneer from Dairy"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Amount (₹) *</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 1500"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 text-lg font-bold text-amber-400"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Payment Mode</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setMode('cash')}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition ${
                      mode === 'cash'
                        ? 'bg-amber-500 text-slate-950 border-amber-400'
                        : 'bg-slate-950 border-slate-700 text-slate-300'
                    }`}
                  >
                    CASH
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode('online')}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition ${
                      mode === 'online'
                        ? 'bg-amber-500 text-slate-950 border-amber-400'
                        : 'bg-slate-950 border-slate-700 text-slate-300'
                    }`}
                  >
                    ONLINE / UPI
                  </button>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Save Expense
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
