import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { InventoryItem } from '../../types';
import { Package, AlertTriangle, X } from 'lucide-react';

export const InventoryManagement: React.FC = () => {
  const { inventory, addInventoryStock } = useApp();

  const [selectedInv, setSelectedInv] = useState<InventoryItem | null>(null);
  const [addQty, setAddQty] = useState('');
  const [costPrice, setCostPrice] = useState('');
  const [supplierName, setSupplierName] = useState('');

  const handleAddStockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInv || !addQty) return;

    addInventoryStock(
      selectedInv.id,
      Number(addQty) || 0,
      Number(costPrice) || selectedInv.costPrice,
      supplierName
    );

    setSelectedInv(null);
    setAddQty('');
    setCostPrice('');
    setSupplierName('');
  };

  return (
    <div className="p-6 bg-slate-950 min-h-[calc(100vh-105px)] text-slate-100 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-100">Fast-Moving Packaged Inventory</h2>
            <p className="text-xs text-slate-400">
              Track opening stock, stock in/out (auto-deducted on POS order), cost vs sell profit
            </p>
          </div>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-4">Item Name</th>
                <th className="p-4">Opening Stock</th>
                <th className="p-4">Stock In</th>
                <th className="p-4">Stock Out (Sold)</th>
                <th className="p-4">Closing Stock</th>
                <th className="p-4">Cost Price</th>
                <th className="p-4">Sell Price</th>
                <th className="p-4">Est. Profit/Unit</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {inventory.map((item) => {
                const profitPerUnit = item.sellPrice - item.costPrice;
                const isLowStock = item.stock <= item.lowStockThreshold;

                return (
                  <tr key={item.id} className="hover:bg-slate-800/50 transition">
                    <td className="p-4 font-extrabold text-slate-100 flex items-center gap-2">
                      <span>{item.itemName}</span>
                      {isLowStock && (
                        <span className="bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-black px-2 py-0.5 rounded flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          LOW STOCK
                        </span>
                      )}
                    </td>
                    <td className="p-4 font-semibold text-slate-400">
                      {item.openingStock} {item.unit}
                    </td>
                    <td className="p-4 font-bold text-emerald-400">+{item.quantityIn}</td>
                    <td className="p-4 font-bold text-rose-400">−{item.quantityOut}</td>
                    <td className="p-4 font-black text-sm text-slate-100">
                      {item.stock} {item.unit}
                    </td>
                    <td className="p-4 text-slate-400">₹{item.costPrice}</td>
                    <td className="p-4 font-bold text-amber-400">₹{item.sellPrice}</td>
                    <td className="p-4 font-bold text-emerald-400">₹{profitPerUnit}</td>
                    <td className="p-4 text-right">
                      <button
                        onClick={() => setSelectedInv(item)}
                        className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs"
                      >
                        + Add Stock
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Stock Modal */}
      {selectedInv && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleAddStockSubmit}
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-slate-100 text-sm">
                Receive New Stock — {selectedInv.itemName}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedInv(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-300 block mb-1">
                  Quantity Received ({selectedInv.unit}) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  placeholder="e.g. 50"
                  value={addQty}
                  onChange={(e) => setAddQty(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold text-base text-amber-400"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Unit Cost Price (₹)</label>
                <input
                  type="number"
                  placeholder={selectedInv.costPrice.toString()}
                  value={costPrice}
                  onChange={(e) => setCostPrice(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div>
                <label className="font-bold text-slate-300 block mb-1">Supplier / Vendor Name</label>
                <input
                  type="text"
                  placeholder="e.g. Samastipur Traders"
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedInv(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl text-xs"
              >
                Update Stock
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
